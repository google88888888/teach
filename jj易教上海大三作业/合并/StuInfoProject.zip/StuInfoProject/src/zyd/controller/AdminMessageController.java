package zyd.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Date;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import zyd.service.MessageService;
import zyd.service.StudentService;
import zyd.bean.Student;

public class AdminMessageController extends HttpServlet {

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html");
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		String action = request.getParameter("action");

		if ("new".equals(action)) {
			doAdd(request, response);
		}
		if ("delete".equals(action)) {
			doDelete(request, response);
		}

	}

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doPost(request, response);
	}

	public void doAdd(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html");
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		PrintWriter out = response.getWriter();

	
		String id = request.getParameter("id");
		String content = request.getParameter("content");
//		String date = new Date().toString();
		String date = new Date(System.currentTimeMillis()).toString(); 
		String name=null;

		MessageService ms = new MessageService();
		StudentService ss = new StudentService();
		try {
			if(id.equals("1")){
				ms.InsertMassage(id, "admin", content, date);
			}else{
			name=ss.SelectBySid(id);			
			ms.InsertMassage(id,name,content,date);
			}
			out.print ("���ӳɹ���2����Զ���ת�����Խ��棬����δ��ת������<a href=\"admin_lyb_view.jsp\">�鿴����</a>");
			response.addHeader("refresh","2;admin_lyb_view.jsp");
		} catch (Exception e) {
			out.print ("����ʧ�ܣ�2����Զ���ת�����Խ��棬����δ��ת������<a href=\"admin_lyb_view.jsp\">�鿴����</a>");
			response.addHeader("refresh","2;admin_lyb_view.jsp");
		}

	}

	public void doDelete(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		PrintWriter out = response.getWriter();

		String rmid = request.getParameter("mid");
		int mid=Integer.parseInt(rmid);
		MessageService ms=new MessageService();
		try {
			ms.DeletebyMid(mid);
			out.print ("ɾ���ɹ���2����Զ���ת�����Խ��棬����δ��ת������<a href=\"admin_lyb_view.jsp\">�鿴����</a>");
			response.addHeader("refresh","2;admin_lyb_view.jsp");
		} catch (Exception e) {
			out.print ("ɾ���ɹ���2����Զ���ת�����Խ��棬����δ��ת������<a href=\"admin_lyb_view.jsp\">�鿴����</a>");
			response.addHeader("refresh","2;admin_lyb_view.jsp");
		}

	}
	
}
