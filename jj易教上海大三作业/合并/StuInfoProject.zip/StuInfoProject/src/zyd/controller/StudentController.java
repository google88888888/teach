package zyd.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import zyd.bean.Course;
import zyd.bean.Student;
import zyd.service.CourseService;
import zyd.service.StudentService;


public class StudentController extends HttpServlet {

	/**
		 * Constructor of the object.
		 */
	public StudentController() {
		super();
	}

	/**
		 * Destruction of the servlet. <br>
		 */
	public void destroy() {
		super.destroy(); // Just puts "destroy" string in log
		// Put your code here
	}

	/**
		 * The doGet method of the servlet. <br>
		 *
		 * This method is called when a form has its tag value method equals to get.
		 * 
		 * @param request the request send by the client to the server
		 * @param response the response send by the server to the client
		 * @throws ServletException if an error occurred
		 * @throws IOException if an error occurred
		 */
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	/**
		 * The doPost method of the servlet. <br>
		 *
		 * This method is called when a form has its tag value method equals to post.
		 * 
		 * @param request the request send by the client to the server
		 * @param response the response send by the server to the client
		 * @throws ServletException if an error occurred
		 * @throws IOException if an error occurred
		 */
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		
		String action = request.getParameter("action");
		String path = request.getContextPath();		
		HttpSession session = request.getSession();
		PrintWriter out = response.getWriter();
		
		
		if ("delete".equals(action)) {
			// ɾ��ѧ����ĳһ�ſγ�  ������ɼ��򲻿���ɾ��  �������ɾ��
			StudentService ss = new StudentService();
			Student student = (Student)session.getAttribute("student");
	    	int cid = Integer.parseInt(request.getParameter("cid"));
	    	if (ss.deleteCourse(student, cid)) {
	    		// ɾ���ɹ�
	    		out.print ("ɾ���ɹ���2����Զ���ת��ѡ�ν��棬����δ��ת������<a href=\"../studentSelected.jsp\">��ѡ�γ�</a>");
				response.addHeader("refresh","2;../studentSelected.jsp");
	    	} else {
	    		// ɾ��ʧ��
	    		out.print ("ɾ��ʧ�ܣ�2����Զ���ת��ѡ�ν��棬����δ��ת������<a href=\"../studentSelected.jsp\">��ѡ�γ�</a>");
				response.addHeader("refresh","2;../studentSelected.jsp");
	    	}
		}
		
		else if ("lookup".equals(action)) {
			String courseName = "";
			if (request.getParameter("course") != null) {
				courseName = request.getParameter("course");
			}
			courseName = courseName.trim();
			ArrayList<Course> list = new ArrayList<Course>();
			CourseService cs = new CourseService();
			if ("".equals(courseName)) {
				list = cs.getAllCourse();
			} else {
				list = cs.getCourseByName(courseName);
			}
			request.setAttribute("courseList", list);
			request.setAttribute("course", courseName);
			request.getRequestDispatcher("../studentSearchCourse.jsp").forward(request, response);
		}
		
		else if ("select".equals(action)) {
		 	
			int cid = Integer.parseInt(request.getParameter("cid"));
	  		Student student = (Student)session.getAttribute("student");
	  		StudentService ss = new StudentService();
	  		if (ss.addCourse(student, cid)) {
	  			// �����ͬѧû��ѡ�����ſ� ѡ�γɹ�
	  		// ��������ҳ  ѡ��֮����Ȼ�ص���ҳ 
	  			String param = "";
		  		if (request.getParameter("cutpage") != null) param = "&cutpage=" + request.getParameter("cutpage");
	  			out.print ("ѡ�γɹ���2����Զ���ת��ѡ�ν��棬����δ��ת������<a href=\"" + path +  "/servlet/StudentController?action=lookup" + param + "\">��ѡ�γ�</a>");
				response.addHeader("refresh","2;\"" + path +  "/servlet/StudentController?action=lookup" + param + "\"");
	  		} else {
	  			// ѡ��ʧ��
	  			String param = "";
		  		if (request.getParameter("cutpage") != null) param = "&cutpage=" + request.getParameter("cutpage");
	  			out.print ("ѡ��ʧ�ܣ������ظ�ѡ��2����Զ���ת��ѡ�ν��棬����δ��ת������<a href=\"" + path +  "/servlet/StudentController?action=lookup" + param + "\">��ѡ�γ�</a>");
				response.addHeader("refresh","2;\"" + path +  "/servlet/StudentController?action=lookup" + param + "\"");
	  		}
	  		 		
		}
	}

	/**
		 * Initialization of the servlet. <br>
		 *
		 * @throws ServletException if an error occurs
		 */
	public void init() throws ServletException {
		// Put your code here
	}

}
