package zyd.controller;

import java.io.IOException;

import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import zyd.bean.Student;
import zyd.service.StudentService;


public class ActionController extends HttpServlet {

	/**
		 * Constructor of the object.
		 */
	public ActionController() {
		super();
	}

	/**
		 * Destruction of the servlet. <br>
		 */
	public void destroy() {
		super.destroy(); // Just puts "destroy" string in log
		// Put your code here
	}

	/**
		 * The doGet method of the servlet. <br>
		 *
		 * This method is called when a form has its tag value method equals to get.
		 * 
		 * @param request the request send by the client to the server
		 * @param response the response send by the server to the client
		 * @throws ServletException if an error occurred
		 * @throws IOException if an error occurred
		 */
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	/**
		 * The doPost method of the servlet. <br>
		 *
		 * This method is called when a form has its tag value method equals to post.
		 * 
		 * @param request the request send by the client to the server
		 * @param response the response send by the server to the client
		 * @throws ServletException if an error occurred
		 * @throws IOException if an error occurred
		 */
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("text/html;charset=utf-8");
		
		HttpSession session = request.getSession();
		String path = request.getContextPath();
		String action = request.getParameter("action");

		if ("login".equals(action)) {
			String username = request.getParameter("username");
			String pwd = request.getParameter("pwd");
			String identity = request.getParameter("identity");
			String[] isUserCookies = request.getParameterValues("isUseCookie");
			
			if ("student".equals(identity)) {
				// �����¼����ѧ��
				StudentService ss = new StudentService();
				Student student = new Student();
				try {
					student.setSid(Integer.parseInt(username));
				} catch (Exception ex) {
					response.sendRedirect(path + "/failure.jsp");
					return ;
				}
				
				student.setSpwd(pwd);
				if (ss.isValid(student)) {
					// �˺�����Ϸ�
					session.setAttribute("student", student);
					if (isUserCookies != null && isUserCookies.length > 0) {
						saveCookie(username, pwd, response);
					} else {
						notSaveCookie(username, pwd, request, response);
					}		  		
					response.sendRedirect(path + "/student.jsp");
				} else {
					// ���Ϸ�
					response.sendRedirect(path + "/failure.jsp");
				}
				
			} else if ("admin".equals(identity)) {
				// �����¼���ǹ���Ա
				if ("zyd".equals(username) && "123".equals(pwd)) {
					// �˺�����Ϸ�
					session.setAttribute("admin", "����Ա");
		  			if (isUserCookies != null && isUserCookies.length > 0) {
						saveCookie(username, pwd, response);
					} else {
						notSaveCookie(username, pwd, request, response);
					}
		  			response.sendRedirect(path + "/navigation.jsp");
				} else {
					// ���Ϸ�
					response.sendRedirect(path + "/failure.jsp");
				}
			} 
		} 
		
	} 
	
	// ��ס�˺�����
	public void saveCookie(String username, String pwd, HttpServletResponse response) {
		Cookie usernameCookie = new Cookie("username", username);
		Cookie pwdCookie = new Cookie("pwd", pwd);
		// ����Cookie�洢·��  ����index��ȡ��������
		usernameCookie.setPath("/");
		pwdCookie.setPath("/");
		usernameCookie.setMaxAge(864000);	// 10 days
		pwdCookie.setMaxAge(864000);
		response.addCookie(usernameCookie);
		response.addCookie(pwdCookie);
	}
	
	// ����ס�˺�����
	public void notSaveCookie(String username, String pwd, 
			HttpServletRequest request, HttpServletResponse response) {
		Cookie[] cookies  = request.getCookies();
		for (Cookie cookie: cookies) {
			if (cookie.getName().equals("username") || cookie.getName().equals("pwd")) {
				cookie.setMaxAge(0);
				response.addCookie(cookie);
			}
		}
	}

	/**
		 * Initialization of the servlet. <br>
		 *
		 * @throws ServletException if an error occurs
		 */
	public void init() throws ServletException {
		// Put your code here
	}

}
