package zyd.util;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
public class DataBaseConnection {
	   String DBDirverName = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
	   String DBUrl = "jdbc:sqlserver://localhost:1433;DatabaseName=stu2";
	   String DBUser = "sa";
	   String DBPwd = "123456";
	private static Connection connection=null ;

	
	public Connection getConnection() {
		try {
			 Class . forName (DBDirverName);
			 connection = DriverManager. getConnection(DBUrl, DBUser, DBPwd); 
		} catch (Exception e) {
			System.out.println("vv"+e.getMessage());
		}
		return connection ;
	}

	public void close() {
		try {
			this.connection.close() ;
		}
		catch (Exception e) {
		}
	}
	

}
