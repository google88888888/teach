package zyd.util;

import java.sql.*;

public class DBHelp {
	
	public static Connection getConn(){
		
/*		String DBDirverName = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
		String DBUrl = "jdbc:sqlserver://localhost:1433;DatabaseName=stu;characterEncoding=UTF-8";
		String DBUser = "sa";
		String DBPwd = "123456";*/
		
		String DBUrl = "jdbc:mysql://localhost:3306/stu?useUnicode=true&characterEncoding=UTF8&useSSL=false";
		String DBUser = "root";
		String DBPwd = "sqa981128";
		String DBDirverName = "com.mysql.jdbc.Driver";
		
		Connection connection = null;
		try {
			   Class . forName (DBDirverName);
			   connection = DriverManager. getConnection(DBUrl, DBUser, DBPwd); 
			   } catch(ClassNotFoundException e) {
			   // TODO Auto-generated catch block
			   System.out.println ("SQLServerDriverû���ҵ�����������������");
			   e.printStackTrace();
			   } catch(SQLException e) {
			   // TODO Auto-generated catch block 
			   System.out.println("���ݿ����ӳ���������");
			   e.printStackTrace();
			   }
			   return connection;
			 }
			   
			public static void  closeDBResource(ResultSet rs, Statement stm, Connection con) {   /*   �ر����ݿ�*/
			try{
				  if (rs != null) { 
			       rs. close ();   /* �رս����*/
			       rs = null;
			      }
			      if (stm != null) { 
			        stm. close (); 
			        stm = null;
			      }
			    }catch(SQLException e) {
				   // TODO Auto-generated catch block 
				   System.out.println("���ݿ����ӳ���������");
				   e.printStackTrace();
				   }
			    
			    }
			 }