package zyd.service;

import java.sql.*;
import java.util.Vector;

import zyd.util.DataBaseConnection;
import zyd.bean.Message;

import zyd.util.DBHelp;
import zyd.bean.*;

public class MessageService {

	public void InsertMassage(String id,String name,String content,String date) throws Exception{
		String sql = "INSERT INTO record (id,name,content,date) VALUES ('"+id+"','"+name+"','"+content+"','"+date+"');";
		Statement stmt = null;
		DataBaseConnection dbc=null;
		dbc=new DataBaseConnection();
		try{
			stmt=dbc.getConnection().createStatement();
			stmt.executeUpdate(sql);
			stmt.close();			
		}catch (Exception e) {
			throw new Exception("�����г���������");
		}finally{
		dbc.close();
		}
	}
	
	public Vector SearchMassage()throws Exception{
		Vector all=new Vector();
		String sql="SELECT * FROM record ORDER BY mid desc";		
		Statement stmt=null;
		DataBaseConnection dbc=null;
		dbc=new DataBaseConnection();
		
		try {
			stmt=dbc.getConnection().createStatement();
			ResultSet rs=stmt.executeQuery(sql);
				while (rs.next()) {
					Message msg=new Message();
					msg.setMid(rs.getInt("mid"));
					msg.setId(rs.getString("id"));
					msg.setName(rs.getString("name"));
					msg.setContent(rs.getString("content"));
					msg.setDate(rs.getString("date"));
					all.addElement(msg);
				}
    			rs.close();
    			stmt.close();
		} catch (Exception e) {
			throw new Exception("��ѯ�г��ִ��󣡣���");
		}finally{
		dbc.close();
		}
		return all;
	}
	public void DeletebyMid(int mid) throws Exception{
		String sql="DELETE FROM record WHERE mid="+mid+";";
		Statement stmt=null;
		DataBaseConnection dbc=null;
		dbc=new DataBaseConnection();
		try{
			stmt=dbc.getConnection().createStatement();
			stmt.executeUpdate(sql);
			stmt.close();
		}catch (Exception e){
			throw new Exception("ɾ���г��ִ��󣡣���");
		}finally {
			dbc.close();
			
		}
	}
}

