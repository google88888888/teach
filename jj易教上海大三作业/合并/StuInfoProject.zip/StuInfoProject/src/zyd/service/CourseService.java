package zyd.service;

import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import zyd.bean.Course;
import zyd.util.DBHelp;


public class CourseService {
	
	public ArrayList<Course> getAllCourse() {
		
		ArrayList<Course> list = new ArrayList<Course>();
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		
		try {
			conn = DBHelp.getConn();
			String sql = "select * from course";
			ps = conn.prepareStatement(sql);
			rs = ps.executeQuery();
			while (rs != null && rs.next()) {
				Course course = new Course();
				course.setCid(rs.getInt(1));
				course.setCname(rs.getString(2));
				course.setCredit(rs.getInt(3));
				list.add(course);
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
		} finally {
			if (ps != null) {
				try {
					ps.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		
		return list;
	}
	
	// ͨ���γ�����ѯ    ģ����ѯ
	public ArrayList<Course> getCourseByName(String cname) {
		
		ArrayList<Course> list = new ArrayList<Course>();
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		
		try {
			conn = DBHelp.getConn();
			String sql = "select * from course where cname like ?";
			ps = conn.prepareStatement(sql);
			ps.setString(1, "%"+cname+"%");
			rs = ps.executeQuery();
			while (rs != null && rs.next()) {
				Course course = new Course();
				course.setCid(rs.getInt(1));
				course.setCname(rs.getString(2));
				course.setCredit(rs.getInt(3));
				list.add(course);
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
		} finally {
			if (ps != null) {
				try {
					ps.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		
		return list;
	}
	
	public Course getCourseById(int cid) {

		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		
		try {
			conn = DBHelp.getConn();
			String sql = "select * from course where cid = ?";
			ps = conn.prepareStatement(sql);
			ps.setInt(1, cid);
			rs = ps.executeQuery();
			if (rs != null && rs.next()) {
				Course course = new Course();
				course.setCid(rs.getInt(1));
				course.setCname(rs.getString(2));
				course.setCredit(rs.getInt(3));
				return course;
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
		} finally {
			if (ps != null) {
				try {
					ps.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		
		return null;
	}
	
	public void addCourse(Course course) {
		Connection conn = null;
		PreparedStatement ps = null;
		
		try {
			conn = DBHelp.getConn();
			String sql = "insert into course(cname, credit) values(?,?)";
			ps = conn.prepareStatement(sql);
			ps.setString(1, course.getCname());
			ps.setInt(2, course.getCredit());
			ps.executeUpdate();
		} catch (SQLException ex) {
			ex.printStackTrace();
		} finally {
			if (ps != null) {
				try {
					ps.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
	}
	
	public void updateCourse(Course course) {
		Connection conn = null;
		PreparedStatement ps = null;
		
		try {
			conn = DBHelp.getConn();
			String sql = "update course set cname=?,credit=? where cid=?";
			ps = conn.prepareStatement(sql);
			ps.setString(1, course.getCname());
			ps.setInt(2, course.getCredit());
			ps.setInt(3, course.getCid());
			ps.executeUpdate();
		} catch (SQLException ex) {
			ex.printStackTrace();
		} finally {
			if (ps != null) {
				try {
					ps.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
	}
	
	public void deleteCourseById(int cid) {
		Connection conn = null;
		PreparedStatement ps = null;
		
		try {
			conn = DBHelp.getConn();
			String sql = "delete from course where cid=?";
			ps = conn.prepareStatement(sql);
			ps.setInt(1, cid);
			ps.executeUpdate();
		} catch (SQLException ex) {
			ex.printStackTrace();
		} finally {
			if (ps != null) {
				try {
					ps.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
	}

}
