drop table users
create table users
(
id nvarchar(10) primary key,
name nvarchar(20),
code nvarchar(20),
kind nvarchar(15)
);

drop table record
create table record
(mid int identity(1,1) primary key,
id nvarchar(10),
name nvarchar(20),
content nvarchar(1000),
date nvarchar(50)
);
drop table student
create table student
(
sid nvarchar(10)  primary key,
sname nvarchar(20),
smajor nvarchar(20),
sclass nvarchar(30),
tcredit nvarchar(10),
tcreditjd nvarchar(10),
ocredit nvarchar(10),
acredit nvarchar(10),
egrade nvarchar(10),
majorpm int,
classpm int,
scode nvarchar(9)
);

insert into users(id,name,code,kind) values('1','admin','1','admin');
insert into users(id,name,code,kind) values('2','zyd','2','student');
insert into users(id,name,code,kind) values('3','sqa','3','student');
insert into users(id,name,code,kind) values('4','jzr','4','student');
insert into record(id,name,content,date) values('2','zyd','����1','2020-06-04');
insert into record(id,name,content,date) values('3','sqa','����2','2020-06-04');
insert into record(id,name,content,date) values('4','jzr','����3','2020-06-04');
insert into student(sid,sname,smajor,sclass,tcredit) values('2','zyd','�������ѧ�뼼��','�����B17-7','185');
insert into student(sid,sname,smajor,sclass,tcredit) values('3','sqa','�������ѧ�뼼��','�����B17-7','185');
insert into student(sid,sname,smajor,sclass,tcredit) values('4','jzr','�������ѧ�뼼��','�����B17-7','185');