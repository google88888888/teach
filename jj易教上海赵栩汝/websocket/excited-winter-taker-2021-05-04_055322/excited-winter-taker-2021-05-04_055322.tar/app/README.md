# Simple Socket.IO Chat

[Live Example](https://simple-socketio-chat.glitch.me/)

* Install dependencies with
```
npm install
```

* Start server with
```
node app.js
```

* Point browser to
```
localhost:3000
```
