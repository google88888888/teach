package mn.idax.data.query.service.impl;

import mn.idax.common.constant.Constants;
import mn.idax.common.constant.OrderModeEnum;
import mn.idax.common.constant.OrderSideEnum;
import mn.idax.common.constant.UserTypeEnum;
import mn.idax.common.entity.Order;
import mn.idax.common.entity.User;
import mn.idax.common.query.request.GetCurrentOrdersRequest;
import mn.idax.common.query.request.GetDirectedOrderRequest;
import mn.idax.common.query.request.GetOrdersByModeRequest;
import mn.idax.common.query.request.GetOrdersRequest;
import mn.idax.common.query.response.OrderResponse;
import mn.idax.common.query.response.QueryResponseItem;
import mn.idax.common.util.ArrayListEx;
import mn.idax.data.bean.Config;
import mn.idax.data.query.service.OrderQueryService;
import mn.idax.data.util.CacheUtil;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.*;

/**
 * @author liuxueshen
 *
 * 2018年12月7日
 */

@Service
public class OrderQueryServiceImpl implements OrderQueryService{

    private static final Logger logger = LoggerFactory.getLogger(OrderQueryServiceImpl.class);

    @Autowired
	private Config config;
    
    @Override
    public QueryResponseItem getOrderInfo(long guid, GetDirectedOrderRequest getDirectedOrderRequest) {
    	
        QueryResponseItem queryResponseItem = QueryResponseItem.createOrderResponse(guid, "success");
        Order order = CacheUtil.orderCurrentAllMap.get(getDirectedOrderRequest.getOrderId());       
        		
        if (order != null){
        	if(getDirectedOrderRequest.getUserId()==order.getUserId()) {
        		queryResponseItem.getOrderResponse().setData(mapperOrderResponse(order));
                return queryResponseItem;
        	}        	
        }
        
        ArrayListEx<Order> list = CacheUtil.orderAllMapByUserNonQuantized.get(getDirectedOrderRequest.getUserId());
        if(list!=null) {
        	for(int i=0;i<list.size();i++) {
        		order = list.get(i);
        		if(order!=null && order.getId() == getDirectedOrderRequest.getOrderId()) {
        			queryResponseItem.getOrderResponse().setData(mapperOrderResponse(order));
                    return queryResponseItem;
        		}
        	}
        }
        
        return queryResponseItem;
    }

    @Override
    public QueryResponseItem getCurrentOrder(long guid, GetCurrentOrdersRequest request) {
        QueryResponseItem queryResponseItem = QueryResponseItem.createTotalListResponse(guid, "success");
        ArrayListEx<Order> listEx = CacheUtil.orderCurrentMapByUser.get(request.getUserId());
        if(listEx==null || listEx.size()==0) {
            return queryResponseItem;
        }
        ArrayList<Order> orderList = getOrdersByChoice(request, listEx,false);
        if(orderList.size() == 0){
            return queryResponseItem;
        }
        if(request.getPageIndex() < 0){
            request.setPageIndex(0);
        }
        if(request.getPageSize() <=0) {
        	request.setPageSize(Constants.DEFAULT_PAGE_SIZE);
        }
        if(request.getPageSize() > config.getPageSize()) {
        	request.setPageSize(config.getPageSize());
        }

        queryResponseItem.getOrdersResponse().setTotal(orderList.size());
        Map<Long, OrderResponse> resultMap = new LinkedHashMap<>();
        try {
            int i = request.getPageIndex()  * request.getPageSize();
            Order order;
            while (resultMap.size() < request.getPageSize() && i < orderList.size()) {
                order = orderList.get(i);
                resultMap.put(order.getId(), mapperOrderResponse(order));
                i++;
            }
        }catch (Exception ex){
            logger.error("IEXCHANGE-COMMON-ERROR {}", ex);
        }
        queryResponseItem.getOrdersResponse().setData(new ArrayList<>(resultMap.values()));
        return queryResponseItem;
    }

    @Override
    public QueryResponseItem getCurrentOrderAdmin(long guid, GetCurrentOrdersRequest request) {
        QueryResponseItem queryResponseItem = QueryResponseItem.createTotalListResponse(guid, "success");
        ArrayListEx<Order> listEx = null;
        if(request.getOrderId() > 0){
            Order order = CacheUtil.orderCurrentAllMap.get(request.getOrderId());
            if(order == null){
                return queryResponseItem;
            }
            listEx = new ArrayListEx<>();
            listEx.add(order);
        } else if(request.getUserId() > 0){
            listEx = CacheUtil.orderCurrentMapByUser.get(request.getUserId());
        }else if(StringUtils.isNotBlank(request.getPairName())){
            listEx = CacheUtil.orderCurrentMapByPair.get(request.getPairName());
        }else {
            return queryResponseItem;
        }

        if(listEx==null || listEx.size()==0) {
            return queryResponseItem;
        }
        ArrayList<Order> orderList = getOrdersByChoice(request, listEx,false);
        if(orderList.size() == 0){
            return queryResponseItem;
        }
        if(request.getPageIndex() < 0){
            request.setPageIndex(0);
        }
        if(request.getPageSize() <=0) {
        	request.setPageSize(Constants.DEFAULT_PAGE_SIZE);
        }
        if(request.getPageSize() > config.getPageSize()) {
        	request.setPageSize(config.getPageSize());
        }

        queryResponseItem.getOrdersResponse().setTotal(orderList.size());
        Map<Long, OrderResponse> resultMap = new LinkedHashMap<Long, OrderResponse>();
        try {
            int i = request.getPageIndex()  * request.getPageSize();
            Order order;
            while (resultMap.size() < request.getPageSize() && i < orderList.size()) {
                order = orderList.get(i);
                resultMap.put(order.getId(), mapperOrderResponse(order));
                i++;
            }
        }catch (Exception ex){
            logger.error("IEXCHANGE-COMMON-ERROR {}", ex);
        }
        queryResponseItem.getOrdersResponse().setData(new ArrayList<>(resultMap.values()));
        return queryResponseItem;
    }

    @Override
    public QueryResponseItem getOrders(long guid, GetOrdersRequest request) {
    	
    	User user = CacheUtil.userMap.get(request.getUserId());    	
    	if (user == null) {
            return QueryResponseItem.createOrderListResponse(guid, "user.notFound");
        }
        
        //量化用户直接返回
        if (!UserTypeEnum.isSmallUser(user.getUserType())) {
            return QueryResponseItem.createOrderListResponse(guid, "user.quantize");
        }
        
        
        QueryResponseItem queryResponseItem = QueryResponseItem.createOrderListResponse(guid, "success");        
        
        ArrayListEx<Order> allOrder = CacheUtil.orderAllMapByUserNonQuantized.get(request.getUserId());
        
      
        if(allOrder==null || allOrder.size()==0) {
            return queryResponseItem;
        }
       
        long startTime =  DateUtils.addDays(new Date(),-1).getTime();
        
        try {
        	//加锁是因为后续还要做拼接
        	synchronized(allOrder) {
        		for(int i=allOrder.size()-1;i>=0;i--) {
            		Order order = allOrder.get(i);
            		if(order!=null && order.getCreateTime().getTime() >= startTime) {
            			queryResponseItem.getOrderListResponse().getData().add(order);
            		}        		
            	}  
        	}        	      	
        }catch (Exception ex){
            // 如果执行过程中orderList 被删除操作，当做正常流程处理
        	logger.warn("{}", ex);
        }

        return queryResponseItem;
    }

    private OrderResponse mapperOrderResponse(Order order) {
        OrderResponse orderResponse = new OrderResponse();
        orderResponse.setId(order.getId());
        orderResponse.setOrdertype(order.getOrderType());
        orderResponse.setOrderside(order.getOrderSide());
        orderResponse.setUserid(order.getUserId());
        orderResponse.setPairname(order.getPairName());
        orderResponse.setPrice(order.getPrice());
        orderResponse.setTotal(order.getTotal());
        orderResponse.setFilledqty(order.getFilledQty());
        orderResponse.setFrozen(order.getFrozen());
        orderResponse.setOrderstate(order.getOrderState());
        orderResponse.setFilledamount(order.getFilledAmount());
        orderResponse.setCreatetime(order.getCreateTime());
        orderResponse.setUpdatetime(order.getUpdateTime());
        orderResponse.setAmount(order.getAmount());
        
        orderResponse.setOrderProperty(order.getOrderProperty());
        orderResponse.setOrderMode(order.getOrderMode());
        orderResponse.setTriggerPrice(order.getTriggerPrice());
        orderResponse.setPriceGap(order.getPriceGap());
        
        return orderResponse;
    }

    private boolean stateInStates(int state,String[] states){
        for (String s:states) {
            if(Integer.parseInt(s) == state){
                return true;
            }
        }
        return false;
    }

    private  ArrayList<Order> getOrdersByChoice(GetCurrentOrdersRequest request, ArrayListEx<Order> orders,Boolean enable) {
        ArrayList<Order> orderArrayList = new ArrayList<>();
        Order currentOrder;
        long currentTime =  DateUtils.addDays(new Date(),-1).getTime();
        try {
            for (int i = orders.size()-1; i >= 0; i--) {
                currentOrder = orders.get(i);
                if(currentOrder == null){
                    continue;
                }
                if (request.getUserId() > 0){
                    if (request.getUserId() != currentOrder.getUserId()) {
                        continue;
                    }
                }
                if (request.getOrderSide() > 0) {
                    if (request.getOrderSide() != currentOrder.getOrderSide()) {
                        continue;
                    }
                }
                if (StringUtils.isNotEmpty(request.getPairName())) {
                    if (!currentOrder.getPairName().equals(request.getPairName()) &&
                            !currentOrder.getPairName().startsWith(request.getPairName()) &&
                            !currentOrder.getPairName().endsWith(request.getPairName())) {
                        continue;
                    }
                }
                if (StringUtils.isNotEmpty(request.getOrderState())) {
                    if (!stateInStates(currentOrder.getOrderState(), request.getOrderState().split(","))) {
                        continue;
                    }
                }
                if (request.getStartTime() != null) {
                    if (currentOrder.getCreateTime().getTime() - request.getStartTime().getTime() < 0) {
                        continue;
                    }
                }
                if (request.getEndTime() != null) {
                    if (request.getEndTime().getTime() - currentOrder.getCreateTime().getTime() < 0) {
                        continue;
                    }
                }
                if (request.getOrderId() > 0) {
                    if (request.getOrderId() != currentOrder.getId()) {
                        continue;
                    }
                }
                if (request.getPrice() != null && request.getPrice().stripTrailingZeros().compareTo(BigDecimal.ZERO) > 0) {
                    if (!request.getPrice().stripTrailingZeros().equals(currentOrder.getPrice().stripTrailingZeros())) {
                        continue;
                    }
                }
                if(enable) {
                    if (currentOrder.getCreateTime().getTime() < currentTime) {
                        continue;
                    }
                }
                orderArrayList.add(currentOrder);
            }
        }catch (Exception ex){
            logger.error("IEXCHANGE-COMMON-ERROR {}", ex);
        }
        return orderArrayList;
    }

    
    @Override
    public QueryResponseItem getOrdersByMode(long guid, GetOrdersByModeRequest request) {
    	
    	QueryResponseItem queryResponseItem = QueryResponseItem.createTotalListResponse(guid, "success");
    	ArrayListEx<Order> orderList = null;
    	
    	if(request.getOrderMode() == OrderModeEnum.STOP_LOSS.getMode()) {
    		
    		if(request.getOrderSide() == OrderSideEnum.BUY.getSide()) {
    			orderList = CacheUtil.orderModeBuyStopLoss.get(request.getPairName());
    		}else {
    			orderList = CacheUtil.orderModeSellStopLoss.get(request.getPairName());
    		}
    		
    	}else if(request.getOrderMode() == OrderModeEnum.STOP_WIN.getMode()) {
    		
    		if(request.getOrderSide() == OrderSideEnum.BUY.getSide()) {
    			orderList = CacheUtil.orderModeBuyStopWin.get(request.getPairName());
    		}else {
    			orderList = CacheUtil.orderModeSellStopWin.get(request.getPairName());
    		}
    		
    	}else if(request.getOrderMode() == OrderModeEnum.TRAILING_STOP_LOSS.getMode()) {
    	
    		if(request.getOrderSide() == OrderSideEnum.BUY.getSide()) {
    			orderList = CacheUtil.orderModeBuyTrailingStopLoss.get(request.getPairName());
    		}else {
    			orderList = CacheUtil.orderModeSellTrailingStopLoss.get(request.getPairName());
    		}
    	}    	
    	
    	if(orderList==null || orderList.size()==0) {
    		return queryResponseItem;
    	}
    	
    	ArrayList<Order> orderFilterList = new ArrayList<Order>();
    	
    	try {
    		for (int i = 0; i < orderList.size()-1; i++) {
    			Order order = orderList.get(i);
    			if(order==null) {
    				continue;
    			}
    			
    			if(request.getUserId() > 0) {    	    		
    	    		if(order.getUserId() == request.getUserId()) {
    	    			orderFilterList.add(orderList.get(i));
    	    		}
    	    	}else {
    	    		orderFilterList.add(order);
    	    	}
        	}
    	}catch (Exception ex){
            logger.error("IEXCHANGE-COMMON-ERROR {}", ex);
        }
    	
    	queryResponseItem.getOrdersResponse().setTotal(orderFilterList.size());
    	
    	if(orderFilterList.size()==0) {
    		return queryResponseItem;
    	}
    	
    	if(request.getPageIndex() < 0) {
    		request.setPageIndex(0);
    	}
    	if(request.getPageSize() <=0) {
        	request.setPageSize(Constants.DEFAULT_PAGE_SIZE);
        }
    	if(request.getPageSize() > config.getPageSize()) {
        	request.setPageSize(config.getPageSize());
        }
    	
        Map<Long, OrderResponse> resultMap = new LinkedHashMap<Long, OrderResponse>();
        int i = request.getPageIndex() * request.getPageSize();
        Order order;
        while (resultMap.size() < request.getPageSize() && i < orderFilterList.size()) {
            order = orderFilterList.get(i);
            resultMap.put(order.getId(), mapperOrderResponse(order));
            i++;
        }        
        
        queryResponseItem.getOrdersResponse().setData(new ArrayList<>(resultMap.values()));
        return queryResponseItem;
    }
}
