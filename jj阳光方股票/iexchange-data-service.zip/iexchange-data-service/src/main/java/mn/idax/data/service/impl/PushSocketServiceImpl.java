package mn.idax.data.service.impl;

import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentLinkedQueue;

import mn.idax.common.util.LogUtil;

import io.protostuff.LinkedBuffer;
import mn.idax.common.bean.DepthMessage;
import mn.idax.common.bean.DepthMessages;
import mn.idax.common.bean.SyncMessage;
import mn.idax.common.bean.SyncMessageList;
import mn.idax.common.constant.AppStateEnum;
import mn.idax.common.constant.OrderSideEnum;
import mn.idax.common.constant.SocketOperationEnum;
import mn.idax.common.entity.Pair;
import mn.idax.common.request.SocketRequest;
import mn.idax.common.util.CommonUtil;
import mn.idax.data.service.PushSocketService;
import mn.idax.data.util.CacheUtil;


/**
 * @author zhouou 214108525@qq.com
 *
 * 2019年1月1日
 */
public class PushSocketServiceImpl implements PushSocketService{


	private static final int BATCH_SIZE = 100000;
	
	private LinkedBuffer syncMessageListBuffer = LinkedBuffer.allocate(100 * 1024 * 1024);		
		
	/**缓存， 使用前先清空**/ 
	private ByteBuffer byteBuffer = ByteBuffer.allocate(4);
	
	private ConcurrentLinkedQueue<SyncMessage> queue;
	
	public PushSocketServiceImpl(ConcurrentLinkedQueue<SyncMessage> queue) {
		this.queue = queue;
	}
	
	
	private List<SyncMessage> syncMessageList = new ArrayList<SyncMessage>(BATCH_SIZE);
	
	@Override
	public void doProcess(Socket socket, InputStream inputStream, OutputStream outputStream) throws Exception {
		
		long start = System.currentTimeMillis();
		long count = 0;
		
		byte[] buffer = new byte[1024 * 1024];
		int readCount = 0;		
		
		while(AppStateEnum.RUNNING.equals(CacheUtil.dataServiceState) && (readCount = inputStream.read(buffer))!=-1) {				
			
			SocketRequest socketRequest = CommonUtil.decodeSocketRequest(buffer,0, readCount);
			
			byte[] content = null;
			
			if(socketRequest!=null) {
				
				syncMessageList.clear();
				
				if(SocketOperationEnum.PULL_PUSH_ALL.getOperation() == socketRequest.getOperation()) {
					
					for(Pair pair: CacheUtil.pairMap.values()) {
						queue.offer(SyncMessage.createSyncMessage(pair));
	                }
							
					
					for(Entry<String, Map<Integer,List<DepthMessage>>> entry: CacheUtil.buyDepthMapSnapshot.entrySet()) {
						
						DepthMessages depthMessages = new DepthMessages();
						depthMessages.setPairName(entry.getKey());
						depthMessages.setOrderSide(OrderSideEnum.BUY.getSide());
						depthMessages.setDepthList(entry.getValue().get(8));
						queue.offer(SyncMessage.createSyncMessage(depthMessages));					
					}
					
					for(Entry<String, Map<Integer,List<DepthMessage>>> entry: CacheUtil.sellDepthMapSnapshot.entrySet()) {
						
						DepthMessages depthMessages = new DepthMessages();
						depthMessages.setPairName(entry.getKey());
						depthMessages.setOrderSide(OrderSideEnum.SELL.getSide());
						depthMessages.setDepthList(entry.getValue().get(8));
						queue.offer(SyncMessage.createSyncMessage(depthMessages));						
					}
				}else {
					
					if(socketRequest.getBuyDepthPairNames()!=null) {
						
						for(String item: socketRequest.getBuyDepthPairNames()) {
							
							Map<Integer,List<DepthMessage>> map = CacheUtil.buyDepthMapSnapshot.get(item);
							
							if(map!=null) {
								DepthMessages depthMessages = new DepthMessages();
								depthMessages.setPairName(item);
								depthMessages.setOrderSide(OrderSideEnum.BUY.getSide());
								depthMessages.setDepthList(map.get(8));
								queue.offer(SyncMessage.createSyncMessage(depthMessages));	
							}
						}
							
					}
					
					if(socketRequest.getSellDepthPairNames()!=null) {
						
						for(String item: socketRequest.getSellDepthPairNames()) {
							
							Map<Integer,List<DepthMessage>> map = CacheUtil.sellDepthMapSnapshot.get(item);
							
							if(map!=null) {
								DepthMessages depthMessages = new DepthMessages();
								depthMessages.setPairName(item);
								depthMessages.setOrderSide(OrderSideEnum.SELL.getSide());
								depthMessages.setDepthList(map.get(8));
								queue.offer(SyncMessage.createSyncMessage(depthMessages));	
							}							
						}
					}
				}
				
				
				
				long itemStart = System.currentTimeMillis();	
				
				SyncMessage syncMessage = null;
				int i = 0;
				while((syncMessage = queue.poll()) != null) {
					
					syncMessageList.add(syncMessage);
					
					i++;
					if(i >= BATCH_SIZE) {
						break;
					}
				}					
												
				if(syncMessageList.size()>0) {
					
					SyncMessageList syncMessageListObj = new SyncMessageList();
					syncMessageListObj.setSyncMessageList(syncMessageList);
					content = CommonUtil.encodeSyncMessageList(syncMessageListObj, syncMessageListBuffer);

					count = count + syncMessageList.size();							
					
					long now = System.currentTimeMillis();
					LogUtil.logInfo("PushSocketServiceImpl-doProcess",0, String.format("speed %d size %d cost %d",count / ((now-start)/1000 + 1), content.length/1024, now-itemStart));
				}
			}
			
			byteBuffer.clear();
			
			if(content!=null) {
									
				outputStream.write(byteBuffer.putInt(content.length).array());
				outputStream.write(content);
			}else {
				outputStream.write(byteBuffer.putInt(0).array());
			}
			
			outputStream.flush();
			
		}	
		
	}

}
