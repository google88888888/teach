package mn.idax.data.bean;

/**
 * @author zhouou 214108525@qq.com
 *
 * 2019年5月27日
 */
public class RiskControlProperty {

	private int totalCount = 150;
	private float ufr = 0.99f;
	
	private int totalPropertyCount = 100;
	private float ifer = 0.99f;	
	
	private int cancelCount = 100;
	private int cancelTimeGap = 2500;
	private float gcr = 0.99f;	
	
	private int period = 600000;
	private int forbiddenDuration = 300000;
	
	private int forbiddenCountPerDay = 10;

	
	
	public int getTotalCount() {
		return totalCount;
	}

	public void setTotalCount(int totalCount) {
		this.totalCount = totalCount;
	}

	public float getUfr() {
		return ufr;
	}

	public void setUfr(float ufr) {
		this.ufr = ufr;
	}

	public int getTotalPropertyCount() {
		return totalPropertyCount;
	}

	public void setTotalPropertyCount(int totalPropertyCount) {
		this.totalPropertyCount = totalPropertyCount;
	}

	public float getIfer() {
		return ifer;
	}

	public void setIfer(float ifer) {
		this.ifer = ifer;
	}

	public int getCancelCount() {
		return cancelCount;
	}

	public void setCancelCount(int cancelCount) {
		this.cancelCount = cancelCount;
	}

	
	public int getCancelTimeGap() {
		return cancelTimeGap;
	}

	public void setCancelTimeGap(int cancelTimeGap) {
		this.cancelTimeGap = cancelTimeGap;
	}

	public float getGcr() {
		return gcr;
	}

	public void setGcr(float gcr) {
		this.gcr = gcr;
	}

	public int getPeriod() {
		return period;
	}

	public void setPeriod(int period) {
		this.period = period;
	}

	public int getForbiddenDuration() {
		return forbiddenDuration;
	}

	public void setForbiddenDuration(int forbiddenDuration) {
		this.forbiddenDuration = forbiddenDuration;
	}

	public int getForbiddenCountPerDay() {
		return forbiddenCountPerDay;
	}

	public void setForbiddenCountPerDay(int forbiddenCountPerDay) {
		this.forbiddenCountPerDay = forbiddenCountPerDay;
	}
	
}
