package mn.idax.data.db.service;

import java.sql.Timestamp;

import mn.idax.data.service.SyncService;

/**
 * @ClassName TradeService
 * @Description 
 * @Author duanlsh
 * @Date 2018/12/12 16:07
 * @Version 1.0
 */
public interface TradeService {

	/**
	 * 启动加载24小时内的交易列表
	 * @param from
	 */
	void loadTradeList(Timestamp from, SyncService syncService);
}
