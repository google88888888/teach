package mn.idax.data.query.service.impl;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import mn.idax.common.bean.DepthMessage;
import mn.idax.common.query.response.DepthResponse;
import mn.idax.common.util.MessageUtil;
import mn.idax.data.bean.Config;
import mn.idax.data.query.service.DepthQueryService;
import mn.idax.data.util.CacheUtil;

/**
 * @author zhouou 214108525@qq.com
 *
 * 2018年12月18日
 */

@Service
public class DepthQueryServiceImpl implements DepthQueryService{
	
	@Autowired
	private Config config;

	@Override
	public DepthResponse getDepth(String pairName, int size, int digits) {
		
		DepthResponse depthResponse = new DepthResponse();
		
		if(pairName==null) {
			MessageUtil.getMessage(depthResponse, "pairName.null");
			
			return depthResponse;
		}
		
		pairName = pairName.toUpperCase();
		
		if(size<=0 || size > config.getDepthSnapshotMaxSize()) {
			size = config.getDepthSnapshotMaxSize();
		}
		
		
		depthResponse.setPairName(pairName);
		
		List<DepthMessage> buyDepthList = null;		
		Map<Integer,List<DepthMessage>> map = CacheUtil.buyDepthMapSnapshot.get(pairName); 
		if(map!=null) {
			buyDepthList = map.get(digits);
		}
		
		List<DepthMessage> sellDepthList = null;		
		map = CacheUtil.sellDepthMapSnapshot.get(pairName);
		if(map!=null) {
			sellDepthList = map.get(digits);
		}
		
		if(size < config.getDepthSnapshotMaxSize()) {
			
			if(buyDepthList!=null) {
				buyDepthList = buyDepthList.subList(0, Math.min(size, buyDepthList.size()));
			}
			
			if(sellDepthList!=null) {
				sellDepthList = sellDepthList.subList(0, Math.min(size, sellDepthList.size()));
			}
		}
		
		depthResponse.setBuyDepthList(buyDepthList);
		depthResponse.setSellDepthList(sellDepthList);
		
		return depthResponse;
		
	}
}
