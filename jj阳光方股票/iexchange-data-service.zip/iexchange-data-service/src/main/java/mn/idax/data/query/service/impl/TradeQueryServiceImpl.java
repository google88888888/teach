package mn.idax.data.query.service.impl;

import mn.idax.common.constant.UserTypeEnum;
import mn.idax.common.entity.Trade;
import mn.idax.common.entity.User;
import mn.idax.common.query.request.GetFinishTradesRequest;
import mn.idax.common.query.response.QueryResponseItem;
import mn.idax.common.util.ArrayListEx;
import mn.idax.data.query.service.TradeQueryService;
import mn.idax.data.util.CacheUtil;

import java.util.Date;

import org.apache.commons.lang3.time.DateUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

/**
 * @ClassName TradeQueryServiceImpl
 * @Description 交易对象信息
 * @Author duanlsh
 * @Date 2018/12/11 10:59
 * @Version 1.0
 */
@Service
public class TradeQueryServiceImpl implements TradeQueryService {

	private static final Logger logger = LoggerFactory.getLogger(OrderQueryServiceImpl.class);
	
    @Override
    public QueryResponseItem geFinishTrades(long guid, GetFinishTradesRequest getFinishTradesRequest) {
        
        //查看用户是否为 量化用户
        User user = CacheUtil.userMap.get(getFinishTradesRequest.getUserId());
        
        if (user == null) {
            return QueryResponseItem.createTradesListResponse(guid, "user.notFound");
        }
        
        //量化用户直接返回
        if (!UserTypeEnum.isSmallUser(user.getUserType())) {
            return QueryResponseItem.createTradesListResponse(guid, "user.quantize");
        }
        
        QueryResponseItem queryResponseItem = QueryResponseItem.createTradesListResponse(guid, "success");

        ArrayListEx<Trade> tradeList = CacheUtil.tradeAllMapByUserNonQuantized.get(getFinishTradesRequest.getUserId());
        if (tradeList == null || tradeList.size() == 0) {
            return queryResponseItem;
        }

        long startTime =  DateUtils.addDays(new Date(),-1).getTime();
        try {
        	//加锁是因为后续还要做拼接
        	synchronized(tradeList) {
        		for(int i=tradeList.size()-1;i>=0;i--) {
            		Trade trade = tradeList.get(i);
            		if(trade!=null && trade.getCreateTime().getTime() >= startTime) {
            			queryResponseItem.getTradeListResponse().getData().add(trade);       			
            		}        		
            	}   
        	}        	     	
        }catch (Exception ex){
             // 如果执行过程中orderList 被删除操作，当做正常流程处理
        	logger.warn("{}", ex);
        }

        return queryResponseItem;

    }
}
