package mn.idax.data.db.service.impl;

import mn.idax.common.entity.Order;
import mn.idax.common.entity.Pair;
import mn.idax.common.util.LogUtil;
import mn.idax.data.db.service.OrderService;
import mn.idax.data.service.SyncService;
import mn.idax.data.util.CacheUtil;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;

/**
 * @author liuxueshen
 *
 * 2018年11月9日
 */

@Service
public class OrderServiceImpl implements OrderService {

	private static final Logger logger = LoggerFactory.getLogger(OrderServiceImpl.class);
	
	private static final int BATCH_SIZE = 500000;
	
	@Autowired
	private DataSource dataSource;
	
	@Override
	public void loadOrderList(Timestamp from, SyncService syncService){

		String sql = "select Id,OrderType,OrderSide,UserId,PairName,Price,Total,FilledQty,Frozen," +
					"OrderState,FilledAmount,CreateTime,UpdateTime,Amount,ClientId,OrderProperty,OrderMode,TriggerPrice,PriceGap from [Order] where CreateTime > ?" ;
		
		Connection connection = null;
		PreparedStatement statement = null;
		ResultSet resultSet;
 		
		long start = System.currentTimeMillis();
		
		int count = 0;
		try {
			connection = dataSource.getConnection();
			statement = connection.prepareStatement(sql);
			statement.setFetchSize(BATCH_SIZE);
			statement.setTimestamp(1, from);
			resultSet=statement.executeQuery();
			Order order ;
			
			while(resultSet.next()){				
				order = new Order();
				order.setId(resultSet.getLong(1));
				order.setOrderType(resultSet.getInt(2));
				order.setOrderSide(resultSet.getInt(3));
				order.setUserId(resultSet.getInt(4));
				order.setPairName(resultSet.getString(5));
				order.setPrice(resultSet.getBigDecimal(6));
				order.setTotal(resultSet.getBigDecimal(7));
				order.setFilledQty(resultSet.getBigDecimal(8));
				order.setFrozen(resultSet.getBigDecimal(9));
				order.setOrderState(resultSet.getInt(10));
				order.setFilledAmount(resultSet.getBigDecimal(11));
				order.setCreateTime(resultSet.getTimestamp(12));
				order.setUpdateTime(resultSet.getTimestamp(13));
				order.setAmount(resultSet.getBigDecimal(14));
				order.setClientId(resultSet.getInt(16));
				order.setOrderProperty(resultSet.getInt(16));
				order.setOrderMode(resultSet.getInt(17));
				order.setTriggerPrice(resultSet.getBigDecimal(18));
				order.setPriceGap(resultSet.getBigDecimal(19));
				
				syncService.processOrderNonQuantized(order);
				
				count ++;
				
				//每100万条清理数据
				if(count % 1000000 == 0) {
					syncService.doCleanOrder();
				}
			}

		}catch (SQLException ex) {
			logger.error("IEXCHANGE-DB-ERROR {}",ex);
		}finally {
			if (statement != null) {
				try {
					statement.close();
				} catch (SQLException ex) {
				}
			}

			if (connection != null) {
				try {
					connection.close();
				} catch (SQLException ex) {
				}
			}
		}
		LogUtil.logInfo("OrderServiceImpl-readOrderList",start, String.valueOf(count));

	}
	
	@Override
	public int getOrderModeCount() {
		
		String sql = "select count(id) from [order] where orderState=0;";
	
		Connection connection = null;
		PreparedStatement statement = null;
		ResultSet resultSet;
		
		long start = System.currentTimeMillis();
		
		try {
			connection = dataSource.getConnection();
			statement = connection.prepareStatement(sql);
			resultSet=statement.executeQuery();

			if(resultSet.next()) {
				return resultSet.getInt(1);
			}
	
		}catch (SQLException ex) {
			logger.error("IEXCHANGE-DB-ERROR {}",ex);
		}finally {
			if (statement != null) {
				try {
					statement.close();
				} catch (SQLException ex) {
				}
			}
	
			if (connection != null) {
				try {
					connection.close();
				} catch (SQLException ex) {
				}
			}
		}
		
		LogUtil.logInfo("OrderServiceImpl-getOrderModeCount",start, null);
		return 0;
	
	}
	
}
