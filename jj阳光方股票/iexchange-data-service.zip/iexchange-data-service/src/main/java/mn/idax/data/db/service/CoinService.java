package mn.idax.data.db.service;

import mn.idax.common.entity.Coin;

/**
 * @author zhouou 214108525@qq.com
 *
 * 2018年11月9日
 */
public interface CoinService {

	/**
	 * 获取 数字货币 列表数据
	 * @param coinId
	 * @return
	 */
	Coin readCoin(int coinId);
}
