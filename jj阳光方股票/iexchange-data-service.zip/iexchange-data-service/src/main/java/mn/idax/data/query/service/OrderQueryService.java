package mn.idax.data.query.service;

import mn.idax.common.query.request.GetDirectedOrderRequest;
import mn.idax.common.query.request.GetOrdersByModeRequest;
import mn.idax.common.query.request.GetCurrentOrdersRequest;
import mn.idax.common.query.request.GetOrdersRequest;
import mn.idax.common.query.response.QueryResponseItem;

/**
 * @author zhouou 214108525@qq.com
 *
 * 2018年12月7日
 */
public interface OrderQueryService {

    /**
     * 获取订单详情
     * @param guid
     * @param getDirectedOrderRequest
     * @return
     */
    QueryResponseItem getOrderInfo(long guid, GetDirectedOrderRequest getDirectedOrderRequest);

    /**
     * 获取当前委托列表
     * @param guid
     * @param request
     * @return
     */
    QueryResponseItem getCurrentOrder(long guid, GetCurrentOrdersRequest request);

    /**
     * 获取当前委托列表,后台专用
     * @param guid
     * @param request
     * @return
     */
    QueryResponseItem getCurrentOrderAdmin(long guid, GetCurrentOrdersRequest request);

    /**
     * 获取订单列表
     * @param guid
     * @param request
     * @return
     */
    QueryResponseItem getOrders(long guid, GetOrdersRequest request);
    
    
    /**
     * 根据委托类型获取订单列表
     * @param guid
     * @param request
     * @return
     */
    QueryResponseItem getOrdersByMode(long guid, GetOrdersByModeRequest request);
}
