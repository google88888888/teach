package mn.idax.data.db.service.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.sql.DataSource;

import mn.idax.common.util.LogUtil;
import mn.idax.data.db.service.CoinService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import mn.idax.common.entity.Coin;

/**
 * @author DELL
 *
 */
@Service
public class CoinServiceImpl implements CoinService{

	private static final Logger logger = LoggerFactory.getLogger(CoinServiceImpl.class);
	
	@Autowired
	private DataSource dataSource;
	
	@Override
	public Coin readCoin(int coinId) {
		
		
		long start = System.currentTimeMillis();
		
		
		//String sql = "select Id,Code,Name,CoverImage,RpcHost,RpcPort,RpcUser,RpcPassword,RpcTimeout,EncryptedWalletPassword,IsDepositEnabled,IsWithdrawEnabled,WithdrawFee,ContractAddress,LowWithdrawAmount,MaxWithdrawAmount,LowWithdrawFee,DepositMinConfirms,TxUrlFormat,LatestBlockNumber,CreateTime,UpdateTime,IsVisible,WalletProvider,FixedFee,Erc20DecimalPlace,WithdrawMax,TokenType,LatestAccountHistoryNumber,RpcPort2,WalletAccount,WalletAccount2,EncryptedClientPassword,EncryptedClientPassword2,MinCollector,IssuePrice,RPCHost2,TimingOpenTime,TimingOpenWithdrewTime from [Coin] where Code=?";
		
		String sql = "select Id,Code,Name,IsVisible from [Coin] where id=?";
		
		Connection connection = null;
		PreparedStatement statement = null;
		ResultSet resultSet=null;
		
		Coin coin = null;
		
		try {		
			
			connection = dataSource.getConnection();
			statement = connection.prepareStatement(sql);

			statement.setInt(1, coinId);
			
			resultSet=statement.executeQuery();
			if(resultSet.next()){
								
				coin = new Coin();
				coin.setId(resultSet.getInt(1));
				coin.setCode(resultSet.getString(2));
				coin.setName(resultSet.getString(3));				
				coin.setVisible(resultSet.getBoolean(4));			
				
			}			
			
		}catch (SQLException ex) {
			logger.error("IEXCHANGE-DB-ERROR {}",ex);
		}finally {
			if (statement != null) {
				try {
					statement.close();
				} catch (SQLException ex) {
				}
			}
			
			if (connection != null) {
				try {
					connection.close();
				} catch (SQLException ex) {
				}
			}
		}

		LogUtil.logInfo("CoinServiceImpl-readCoin",start, "readCoin total");

		return coin;
		
	}
}
