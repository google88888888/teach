package mn.idax.data.db.service;

import java.util.List;

import mn.idax.common.entity.Account;


/**
 * @author zhouou 214108525@qq.com
 *
 * 2018年10月31日
 */
public interface AccountService {	
	
 	/**
	 * 读取所有Account
	 * @return
	 */
	List<Account> compareAccount();	
	
}
