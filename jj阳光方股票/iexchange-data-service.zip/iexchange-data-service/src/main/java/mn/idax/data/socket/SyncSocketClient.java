package mn.idax.data.socket;

import io.protostuff.LinkedBuffer;
import mn.idax.common.bean.SyncMessageList;
import mn.idax.common.constant.AppStateEnum;
import mn.idax.common.constant.Constants;
import mn.idax.common.constant.SocketOperationEnum;
import mn.idax.common.request.SocketRequest;
import mn.idax.common.util.ByteBufferEx;
import mn.idax.common.util.CommonUtil;
import mn.idax.common.util.LogUtil;
import mn.idax.common.util.SimpleThreadFactory;
import mn.idax.data.bean.Config;
import mn.idax.data.service.SyncService;
import mn.idax.data.util.CacheUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.nio.ByteBuffer;

/**
 * @author zhouou 214108525@qq.com
 *
 * 2018年11月1日
 */
@Service
public class SyncSocketClient {
	
	private static final Logger logger = LoggerFactory.getLogger(SyncSocketClient.class);
	
	public static volatile long tid = 0;
	public static volatile long savedTid = 0;
	
	public static volatile boolean PULL_DATA_ALL = true;
		
	@Autowired
	private Config config;
	
	@Autowired
	private SyncService syncService;
			
	@Autowired
	private SimpleThreadFactory simpleThreadFactory;
	
	private Socket socket = null;	
	private InputStream inputStream = null;
	private OutputStream outputStream = null;
	
	private int socketErrorCount = 0;
	
	class Worker implements Runnable{	
		
		private byte[] buffer = new byte[1024 * 1024];
		private ByteBufferEx byteBuffer = new ByteBufferEx();
		private LinkedBuffer socketRequestBuffer = LinkedBuffer.allocate(64 * 1024);
		
		private void send(OutputStream outputStream, SocketRequest socketRequest) throws Exception{
						
			if(!PULL_DATA_ALL) {
				//表示已全量加载过
				socketRequest.setOperation(SocketOperationEnum.PULL_DATA.getOperation());
			}else {
				socketRequest.setOperation(SocketOperationEnum.PULL_DATA_ALL.getOperation());
			}
			
			socketRequest.setTid(tid);
			socketRequest.setSavedTid(savedTid);		
			outputStream.write(CommonUtil.encodeSocketRequest(socketRequest, socketRequestBuffer));
			
			outputStream.flush();
		}
		
		@Override
		public void run(){
			
			try{			
							
				while(AppStateEnum.LOADING.equals(CacheUtil.dataServiceState)) {
					Thread.sleep(1000);
					lastActive = System.currentTimeMillis();
				}
				
				lastActive = System.currentTimeMillis();
				
				socket = new Socket(config.getCoreSocketUrl(), config.getCoreSocketPort());	
				socket.setTcpNoDelay(true);
				
				//等待1s， 服务器开始接收数据后再开始
				Thread.sleep(1000);
				
				int readCount = 0;				
 				
				inputStream = socket.getInputStream();
				outputStream = socket.getOutputStream();
				
				LogUtil.logInfo("Worker-run", 0, "Start connect");
				
				SocketRequest socketRequest = new SocketRequest();
				socketRequest.setOperation(SocketOperationEnum.CONN_DATA.getOperation());
				socketRequest.setTid(tid);
				socketRequest.setSavedTid(savedTid);
				
				//连接同步Socket					
				outputStream.write(CommonUtil.encodeSocketRequest(socketRequest,socketRequestBuffer));
				outputStream.flush();
			
				if(AppStateEnum.RUNNING.equals(CacheUtil.dataServiceState) && (readCount = inputStream.read(buffer))!=-1) {
					if(readCount==Constants.LENGTH_BYTES && ByteBuffer.wrap(buffer, 0, Constants.LENGTH_BYTES).getInt() ==0) {
						//等待1s， 服务器开始接收数据后再开始
						Thread.sleep(1000);
					}else {
						throw new RuntimeException("Socket conn failed");
					}
				}
				
				send(outputStream, socketRequest);				
				
				
				int msgLength = 0;
				
				while(AppStateEnum.RUNNING.equals(CacheUtil.dataServiceState) && (readCount = inputStream.read(buffer))!=-1) {
					
					lastActive = System.currentTimeMillis();
					
					if(msgLength == 0) {
						
						msgLength =  ByteBuffer.wrap(buffer, 0, 4).getInt();						
						
						if(msgLength > 0) {
							byteBuffer.allocate(msgLength);
							byteBuffer.put(buffer, 4, readCount - 4);
						}else {
							//等10ms 重发请求
							Thread.sleep(10);
							
							send(outputStream, socketRequest);
						}
					}else {
						byteBuffer.put(buffer, 0, readCount);
					}
					
					if(msgLength < byteBuffer.size()) {
						throw new RuntimeException("msgLength < byteBuffer.size()");
					}else if(msgLength > 0 && msgLength == byteBuffer.size()) {
												
						SyncMessageList syncMessageList = CommonUtil.decodeSyncMessageList(byteBuffer.getBuffer(),0,msgLength);
						
						msgLength = 0;
						byteBuffer.clear();
						
						if(syncMessageList!=null && syncMessageList.getSyncMessageList()!=null && syncMessageList.getSyncMessageList().size()>0) {
							
							syncService.doProcess(syncMessageList);
							
							//只要有数据过来了就切换到 PULL_SYNC
							if(socketRequest.getOperation() == SocketOperationEnum.PULL_DATA_ALL.getOperation()) {
								
								PULL_DATA_ALL = false;
								
								LogUtil.logInfo("Worker-run", 0, "Finish PULL_DATA_ALL");
							}							
							
						}
						
						send(outputStream, socketRequest);
					 
					}					
					
				}
				
			}catch(Exception ex){
				socketErrorCount ++;
				if(socketErrorCount % 30 == 0) {
					logger.error("IEXCHANGE-SOCKET-ERROR {}", ex);
				}else {
					logger.error("{}", ex);
				}				
			}finally {
				try {
					if(inputStream!=null) {
						inputStream.close();	
					}
					
					if(outputStream!=null) {
						outputStream.close();
					}
					
					if(socket!= null) {
						socket.close();				
					}				
					
					if(AppStateEnum.RUNNING.equals(CacheUtil.dataServiceState)) {
						Thread.sleep(5000);
						
						Worker worker=new Worker();
						thread = simpleThreadFactory.newThread(worker, "SyncCoreSocket-client");
					
						thread.start();

						LogUtil.logInfo("SyncSocketClient-run",0, "Socket Data retry");
					}
				}catch(Exception e) {
				}
			}
		}
	}
	
	
	private Thread thread = null;
	private long lastActive = System.currentTimeMillis();
	
	public void checkAlive() {
		
		if(!AppStateEnum.RUNNING.equals(CacheUtil.dataServiceState)) {
			LogUtil.logInfo("SyncSocketClient-checkAlive", 0, "Service is not running");
			return;
		}
		
		LogUtil.logInfo("SyncSocketClient-checkAlive", 0, null);
		
		//网络1分钟没影响就抛异常并执行finally重启socket
		if(System.currentTimeMillis() - lastActive > Constants.SOCKET_CHECK_ALIVE) {
			
			logger.warn("SyncSocketClient-checkAlive close and retry");
			
			try {
				if(socket!= null) {
					socket.close();				
				}
				
				
			}catch(Exception e) {
			}	
		}
	}

	@PostConstruct
	public void init() {
		
		Worker worker=new Worker();
		
		thread = simpleThreadFactory.newThread(worker,"SyncCoreSocket-client");
	
		thread.start();		
		
	}
	
	
	@PreDestroy
	public void destroy() {		
		
		CacheUtil.dataServiceState = AppStateEnum.SHUTTING_DOWN;
		
		try {
			
			Thread.sleep(1000);
			
			if(thread!=null) {
				thread.interrupt();
			}
			
		}catch(Exception ex) {
			
		}finally {
			
			try {
				if(inputStream!=null) {
					inputStream.close();	
				}
				
				if(outputStream!=null) {
					outputStream.close();
				}
				
				if(socket!= null) {
					socket.close();				
				}	
			}catch(Exception e) {
			}	
		}
	}
}
