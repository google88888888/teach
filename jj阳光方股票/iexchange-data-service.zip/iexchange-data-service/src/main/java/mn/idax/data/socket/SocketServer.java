package mn.idax.data.socket;

import mn.idax.common.bean.SyncMessage;
import mn.idax.common.constant.AppStateEnum;
import mn.idax.common.constant.Constants;
import mn.idax.common.constant.SocketOperationEnum;
import mn.idax.common.request.SocketRequest;
import mn.idax.common.util.CommonUtil;
import mn.idax.common.util.LogUtil;
import mn.idax.common.util.SimpleThreadFactory;
import mn.idax.data.bean.Config;
import mn.idax.data.query.service.QuerySocketService;
import mn.idax.data.query.service.impl.QuerySocketServiceImpl;
import mn.idax.data.service.PushSocketService;
import mn.idax.data.service.impl.PushSocketServiceImpl;
import mn.idax.data.util.CacheUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.concurrent.ConcurrentLinkedQueue;


/**
 * @author zhouou 214108525@qq.com
 *
 * 2018年11月1日
 */
@Service
public class SocketServer {
	
	private static final Logger logger = LoggerFactory.getLogger(SocketServer.class);
		
	@Autowired
	private Config config;
	
	@Autowired
	private SimpleThreadFactory simpleThreadFactory;
	
	private ServerSocket listener = null; 	
			
	class SocketWorker implements Runnable{
		
		private Socket socket = null;			
		private InputStream inputStream = null;
		private OutputStream outputStream = null;
		
		private Thread thread;
		public void setThread(Thread thread) {
			this.thread = thread;
		}

		public SocketWorker(Socket socket) {
			this.socket = socket;
		}
		
		public void stop() {
			try {
				
				if(inputStream!=null) {
					inputStream.close();					
				}
				
				if(outputStream!=null) {
					outputStream.close();
				}
				
				if(socket!= null) {
					socket.close();				
				}
				
				thread.interrupt();
				
			}catch(Exception ex) {
				logger.error("{}", ex);
			}	
		}
		
		
		private SocketRequest socketRequest;
		
		@Override
		public void run(){ 				
			
			try{
				
				inputStream = socket.getInputStream();
				outputStream = socket.getOutputStream();
				
				byte[] buffer = new byte[64 * 1024];
				int readCount = 0;			
				
				if(!AppStateEnum.SHUTTING_DOWN.equals(CacheUtil.dataServiceState) && (readCount = inputStream.read(buffer))!=-1) {
					
					socketRequest = CommonUtil.decodeSocketRequest(buffer,0, readCount);
					
					if(socketRequest!=null) {
						
						if(SocketOperationEnum.CONN_QUERY.getOperation() == socketRequest.getOperation()) {							
							
							socket.setTcpNoDelay(true);
							
							thread.setName("Socket Query " + System.currentTimeMillis());
							
							outputStream.write(Constants.EMPTY_MESSAGE);
							outputStream.flush();
							
							LogUtil.logInfo("SocketWorker-run", 0, "Query socket connected!");
							
							QuerySocketService querySocketService = new QuerySocketServiceImpl(socketRequest.getServerId());
							querySocketService.doProcess(socket, inputStream, outputStream);		
														
						}else if(SocketOperationEnum.CONN_PUSH.getOperation() == socketRequest.getOperation()) {							
							
							thread.setName("Socket Push " + System.currentTimeMillis());
							
							outputStream.write(Constants.EMPTY_MESSAGE);
							outputStream.flush();

							LogUtil.logInfo("SocketServer-run",0, "Push socket connected!");

							ConcurrentLinkedQueue<SyncMessage> queue = new ConcurrentLinkedQueue<SyncMessage>();
							
							CacheUtil.pushQueueMap.put(socketRequest.getServerId(), queue);
							
							PushSocketService pushSocketService = new PushSocketServiceImpl(queue);
							pushSocketService.doProcess(socket, inputStream, outputStream);		
														
						}
					}
				}
				
			}catch(Exception ex){
				logger.error("{}", ex);
				
				try {
					
					if(inputStream!=null) {
						inputStream.close();					
					}
					
					if(outputStream!=null) {
						outputStream.close();
					}
					
					if(socket!= null) {
						socket.close();				
					}
					
				}catch(Exception e) {
					
				}	
			}finally {
				//一定要清理防止数据只进不出
				if(socketRequest!=null && SocketOperationEnum.CONN_PUSH.getOperation() == socketRequest.getOperation()) {
					CacheUtil.pushQueueMap.remove(socketRequest.getServerId());
				}
				
			}
		}
	}
	
	class Server implements Runnable{			
		@Override
		public void run(){ 				
			
			try{				
				listener = new ServerSocket(config.getDataSocketPort());
				
				//一启动就接受file service 连接
				while(!AppStateEnum.SHUTTING_DOWN.equals(CacheUtil.dataServiceState)){
					Socket socket = listener.accept();
					socket.setTcpNoDelay(true);
					
					SocketWorker socketWorker = new SocketWorker(socket);

					
					Thread thread = simpleThreadFactory.newThread(socketWorker, "Socket-Client-Worker");				
					socketWorker.setThread(thread);
					thread.start();	
				}		
				
			}catch(Exception ex){
				logger.error("{}", ex);
			}finally {
				try {					
					if(listener!=null) {
						listener.close();				
					}
					
					if(AppStateEnum.RUNNING.equals(CacheUtil.dataServiceState)) {		
						Thread.sleep(1000);
						
						Server server = new Server();
						serverThread = simpleThreadFactory.newThread(server, "Socket-Server");
					
						serverThread.start();					
					}
					
				}catch(Exception e) {
					
				}	
			}
		}
	}
	
	

	private Thread serverThread = null;
	
	@PostConstruct
	public void init() {
		
		Server server = new Server();
		
		serverThread = simpleThreadFactory.newThread(server, "Socket-Server");		
		serverThread.start();			
	}
	
	
	@PreDestroy
	public void destroy() {		
		
		CacheUtil.dataServiceState = AppStateEnum.SHUTTING_DOWN;
		
		try {
			
			Thread.sleep(1000);
			
			if(serverThread!=null) {
				serverThread.interrupt();
			}
			
		}catch(Exception ex) {
			
		}finally {
			try {				
				
				if(listener!=null) {
					listener.close();					
				}
			}catch(Exception e) {
			}	
			
		}
	}
}
