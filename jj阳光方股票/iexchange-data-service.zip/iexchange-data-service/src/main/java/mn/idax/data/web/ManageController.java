package mn.idax.data.web;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.TypeReference;

import mn.idax.common.bean.DepthMessage;
import mn.idax.common.bean.ServerStatus;
import mn.idax.common.constant.AppStateEnum;
import mn.idax.common.constant.Constants;
import mn.idax.common.constant.OrderStateEnum;
import mn.idax.common.constant.UserTypeEnum;
import mn.idax.common.entity.Account;
import mn.idax.common.entity.Coin;
import mn.idax.common.entity.Order;
import mn.idax.common.entity.Pair;
import mn.idax.common.entity.Trade;
import mn.idax.common.query.request.QueryRequestItem;
import mn.idax.common.query.response.QueryResponseItem;
import mn.idax.common.response.ListResponse;
import mn.idax.common.util.ArrayListEx;
import mn.idax.common.util.LogUtil;
import mn.idax.common.util.MessageUtil;
import mn.idax.data.bean.AsyncRequest;
import mn.idax.data.bean.Config;
import mn.idax.data.db.service.AccountService;
import mn.idax.data.db.service.OrderService;
import mn.idax.data.util.CacheUtil;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.HttpEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.utils.URIBuilder;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Objects;
import java.util.Set;

/**
 * @author zhouou 214108525@qq.com
 *
 * 2018年11月26日
 */

@RestController("manageController")
public class ManageController {

	private final static Logger logger = LoggerFactory.getLogger(ManageController.class);

	private final static String SERVER_STATUS = "/getServerStatus";
	private final static String SERVER_DETAIL_STATUS = "/getServerDetailStatus";
	private final static String SHUTDOWN = "/shutdown";
	private final static String RENAME_COIN = "/renameCoinInner";

	
	@Autowired
	private Config config;	
	
	@Autowired
	private AccountService accountService;
	
	@Autowired
	private OrderService orderService;
	
	@RequestMapping(value="/getServerStatus", produces="application/json", method=RequestMethod.GET)
	public ListResponse<ServerStatus> getServerStatus() {
		
		
		ListResponse<ServerStatus> listResponse = new ListResponse<ServerStatus>();
		
		List<ServerStatus> serverStatusList = new ArrayList<ServerStatus>();
		listResponse.setData(serverStatusList);
		
		
		ServerStatus serverStatus = new ServerStatus();
		serverStatus.setServerId(config.getServerId());
		serverStatus.setServerName(config.getAppName());
		serverStatus.setProperty("state");
		serverStatus.setValue(CacheUtil.dataServiceState.getDescription());		
		serverStatusList.add(serverStatus);		
				
		return listResponse;
	}
	
	@RequestMapping(value="/getServerDetailStatus", produces="application/json", method=RequestMethod.GET)
	public ListResponse<ServerStatus> getServerDetailStatus() {
		
		
		ListResponse<ServerStatus> listResponse = new ListResponse<ServerStatus>();
		
		List<ServerStatus> serverStatusList = new ArrayList<ServerStatus>();
		listResponse.setData(serverStatusList);
		
		
		ServerStatus serverStatus = new ServerStatus();
		serverStatus.setServerId(config.getServerId());
		serverStatus.setServerName(config.getAppName());
		serverStatus.setProperty("state");
		serverStatus.setValue(CacheUtil.dataServiceState.getDescription());		
		serverStatusList.add(serverStatus);
		
		
		serverStatus = new ServerStatus();
		serverStatus.setServerId(config.getServerId());
		serverStatus.setServerName(config.getAppName());
		serverStatus.setProperty("coinMap");
		serverStatus.setValue(String.valueOf(CacheUtil.coinMap.size()));		
		serverStatusList.add(serverStatus);
		
		serverStatus = new ServerStatus();
		serverStatus.setServerId(config.getServerId());
		serverStatus.setServerName(config.getAppName());
		serverStatus.setProperty("userMap");
		serverStatus.setValue(String.valueOf(CacheUtil.userMap.size()));		
		serverStatusList.add(serverStatus);
		
		serverStatus = new ServerStatus();
		serverStatus.setServerId(config.getServerId());
		serverStatus.setServerName(config.getAppName());
		serverStatus.setProperty("pairMap");
		serverStatus.setValue(String.valueOf(CacheUtil.pairMap.size()));		
		serverStatusList.add(serverStatus);
		
		long count = 0;
		for(Map<Integer, Account> byUserAccountMap: CacheUtil.accountMap.values()) {
			count = count + byUserAccountMap.size();
		}
		
		serverStatus = new ServerStatus();
		serverStatus.setServerId(config.getServerId());
		serverStatus.setServerName(config.getAppName());
		serverStatus.setProperty("accountMap");
		serverStatus.setValue(String.valueOf(count));		
		serverStatusList.add(serverStatus);
		
		
		count = 0;
		for(Entry<Integer, ArrayListEx<Order>> entry: CacheUtil.orderCurrentMapByUser.entrySet()) {
			count = count + entry.getValue().size();
		}
		serverStatus = new ServerStatus();
		serverStatus.setServerId(config.getServerId());
		serverStatus.setServerName(config.getAppName());
		serverStatus.setProperty("orderBookSizeByUser");
		serverStatus.setValue(String.valueOf(count));		
		serverStatusList.add(serverStatus);
		
		
		count = 0;
		for(Entry<String, ArrayListEx<Order>> entry: CacheUtil.orderCurrentMapByPair.entrySet()) {
			count = count + entry.getValue().size();
		}
		serverStatus = new ServerStatus();
		serverStatus.setServerId(config.getServerId());
		serverStatus.setServerName(config.getAppName());
		serverStatus.setProperty("orderBookSizeByPair");
		serverStatus.setValue(String.valueOf(count));		
		serverStatusList.add(serverStatus);
		
		
		count = 0;
		for(Entry<String, ArrayListEx<Order>> entry: CacheUtil.specialBuyOrderBook.entrySet()) {
			count = count + entry.getValue().size();
		}
		for(Entry<String, ArrayListEx<Order>> entry: CacheUtil.specialSellOrderBook.entrySet()) {
			count = count + entry.getValue().size();
		}
		serverStatus = new ServerStatus();
		serverStatus.setServerId(config.getServerId());
		serverStatus.setServerName(config.getAppName());
		serverStatus.setProperty("specialOrderBookSize");
		serverStatus.setValue(String.valueOf(count));		
		serverStatusList.add(serverStatus);
		
		
		
		for(Entry<String, ArrayListEx<Order>> entry: CacheUtil.orderCurrentMapByPair.entrySet()) {
			
			//统计止赢止损数量
			ArrayListEx<Order> list1 = CacheUtil.orderModeBuyStopLoss.get(entry.getKey());
			ArrayListEx<Order> list2 = CacheUtil.orderModeBuyStopWin.get(entry.getKey());
			ArrayListEx<Order> list3 = CacheUtil.orderModeSellStopLoss.get(entry.getKey());
			ArrayListEx<Order> list4 = CacheUtil.orderModeSellStopWin.get(entry.getKey());
			ArrayListEx<Order> list5 = CacheUtil.orderModeBuyTrailingStopLoss.get(entry.getKey());
			ArrayListEx<Order> list6 = CacheUtil.orderModeSellTrailingStopLoss.get(entry.getKey());
			
			int stopCount = 0;
			if(list1!=null) {
				stopCount = stopCount + list1.size();
			}
			if(list2!=null) {
				stopCount = stopCount + list2.size();
			}
			if(list3!=null) {
				stopCount = stopCount + list3.size();
			}
			if(list4!=null) {
				stopCount = stopCount + list4.size();
			}
			if(list5!=null) {
				stopCount = stopCount + list5.size();
			}
			if(list6!=null) {
				stopCount = stopCount + list6.size();
			}
			
			serverStatus = new ServerStatus();
			serverStatus.setServerId(config.getServerId());
			serverStatus.setServerName(config.getAppName());
			serverStatus.setProperty(String.format("orderBookSize_%s", entry.getKey()));
			serverStatus.setValue(String.valueOf(entry.getValue().size() - stopCount));		
			serverStatusList.add(serverStatus);
			
		}
		
		
		int stopCount = 0;
		for(ArrayListEx<Order> item: CacheUtil.orderModeBuyStopLoss.values()) {
			stopCount = stopCount + item.size();
		}
		for(ArrayListEx<Order> item: CacheUtil.orderModeBuyStopWin.values()) {
			stopCount = stopCount + item.size();
		}
		for(ArrayListEx<Order> item: CacheUtil.orderModeSellStopLoss.values()) {
			stopCount = stopCount + item.size();
		}
		for(ArrayListEx<Order> item: CacheUtil.orderModeSellStopWin.values()) {
			stopCount = stopCount + item.size();
		}
		for(ArrayListEx<Order> item: CacheUtil.orderModeBuyTrailingStopLoss.values()) {
			stopCount = stopCount + item.size();
		}
		for(ArrayListEx<Order> item: CacheUtil.orderModeSellTrailingStopLoss.values()) {
			stopCount = stopCount + item.size();
		}
		
		
		serverStatus = new ServerStatus();
		serverStatus.setServerId(config.getServerId());
		serverStatus.setServerName(config.getAppName());
		serverStatus.setProperty("orderBookSize");
		serverStatus.setValue(String.valueOf(CacheUtil.orderCurrentAllMap.size() - stopCount));		
		serverStatusList.add(serverStatus);
		
		
		count = 0;
		for(Entry<Integer, ArrayListEx<Order>> entry: CacheUtil.orderAllMapByUserNonQuantized.entrySet()) {
			count = count + entry.getValue().size();
		}
		serverStatus = new ServerStatus();
		serverStatus.setServerId(config.getServerId());
		serverStatus.setServerName(config.getAppName());
		serverStatus.setProperty("orderAllMapByUserNonQuantized");
		serverStatus.setValue(String.valueOf(count));		
		serverStatusList.add(serverStatus);
		
		
		count = 0;
		for(Entry<Integer, ArrayListEx<Trade>> entry: CacheUtil.tradeAllMapByUserNonQuantized.entrySet()) {
			count = count + entry.getValue().size();
		}
		serverStatus = new ServerStatus();
		serverStatus.setServerId(config.getServerId());
		serverStatus.setServerName(config.getAppName());
		serverStatus.setProperty("tradeAllMapByUserNonQuantized");
		serverStatus.setValue(String.valueOf(count));		
		serverStatusList.add(serverStatus);
		
				
		count = 0;
		for(Entry<String, ArrayListEx<DepthMessage>> entry: CacheUtil.buyDepthMap.entrySet()) {
			if(entry.getValue().size()>0) {
				serverStatus = new ServerStatus();
				serverStatus.setServerId(config.getServerId());
				serverStatus.setServerName(config.getAppName());
				serverStatus.setProperty(String.format("buyDepthSize_%s", entry.getKey()));
				serverStatus.setValue(String.valueOf(entry.getValue().size()));		
				serverStatusList.add(serverStatus);	
				
				count = count + entry.getValue().size();
			}				
		}
		
		serverStatus = new ServerStatus();
		serverStatus.setServerId(config.getServerId());
		serverStatus.setServerName(config.getAppName());
		serverStatus.setProperty("buyDepthSize");
		serverStatus.setValue(String.valueOf(count));		
		serverStatusList.add(serverStatus);	
		
		
		count = 0;
		
		for(Entry<String, ArrayListEx<DepthMessage>> entry: CacheUtil.sellDepthMap.entrySet()) {	
			if(entry.getValue().size()>0) {
				serverStatus = new ServerStatus();
				serverStatus.setServerId(config.getServerId());
				serverStatus.setServerName(config.getAppName());
				serverStatus.setProperty(String.format("sellDepthSize_%s", entry.getKey()));
				serverStatus.setValue(String.valueOf(entry.getValue().size()));		
				serverStatusList.add(serverStatus);		
				
				count = count + entry.getValue().size();
			}				
		}
		
		serverStatus = new ServerStatus();
		serverStatus.setServerId(config.getServerId());
		serverStatus.setServerName(config.getAppName());
		serverStatus.setProperty("sellDepthSize");
		serverStatus.setValue(String.valueOf(count));		
		serverStatusList.add(serverStatus);		
		
		
		serverStatus = new ServerStatus();
		serverStatus.setServerId(config.getServerId());
		serverStatus.setServerName(config.getAppName());
		serverStatus.setProperty("forwardSocketResponseMap");
		serverStatus.setValue(String.valueOf(CacheUtil.forwardSocketResponseMap.size()));		
		serverStatusList.add(serverStatus);
		
		for(String key: CacheUtil.forwardSocketResponseMap.keySet()) {
			serverStatus = new ServerStatus();
			serverStatus.setServerId(config.getServerId());
			serverStatus.setServerName(config.getAppName());
			serverStatus.setProperty("forwardSocketResponseMap");
			serverStatus.setValue(key);		
			serverStatusList.add(serverStatus);
		}
		
		serverStatus = new ServerStatus();
		serverStatus.setServerId(config.getServerId());
		serverStatus.setServerName(config.getAppName());
		serverStatus.setProperty("pushQueueMap");
		serverStatus.setValue(String.valueOf(CacheUtil.pushQueueMap.size()));		
		serverStatusList.add(serverStatus);
		
		
		count = 0;
		for(Entry<String, ArrayListEx<Order>> entry: CacheUtil.orderModeBuyStopLoss.entrySet()) {
			count = count + entry.getValue().size();
		}
		for(Entry<String, ArrayListEx<Order>> entry: CacheUtil.orderModeBuyStopWin.entrySet()) {
			count = count + entry.getValue().size();
		}
		for(Entry<String, ArrayListEx<Order>> entry: CacheUtil.orderModeSellStopLoss.entrySet()) {
			count = count + entry.getValue().size();
		}
		for(Entry<String, ArrayListEx<Order>> entry: CacheUtil.orderModeSellStopWin.entrySet()) {
			count = count + entry.getValue().size();
		}
		for(Entry<String, ArrayListEx<Order>> entry: CacheUtil.orderModeBuyTrailingStopLoss.entrySet()) {
			count = count + entry.getValue().size();
		}
		for(Entry<String, ArrayListEx<Order>> entry: CacheUtil.orderModeSellTrailingStopLoss.entrySet()) {
			count = count + entry.getValue().size();
		}
		
		serverStatus = new ServerStatus();
		serverStatus.setServerId(config.getServerId());
		serverStatus.setServerName(config.getAppName());
		serverStatus.setProperty("orderModeSize");
		serverStatus.setValue(String.valueOf(count));		
		serverStatusList.add(serverStatus);
		
		return listResponse;
	}
	
	@RequestMapping(value="/compareOrderMode", produces="application/json", method=RequestMethod.GET)
	public ListResponse<ServerStatus> compareOrderMode() {
		
		ListResponse<ServerStatus> listResponse = new ListResponse<>();
		listResponse.setData(new ArrayList<>());
		
		int count = 0;
		for(Entry<String, ArrayListEx<Order>> entry: CacheUtil.orderModeBuyStopLoss.entrySet()) {
			for(int i=0;i<entry.getValue().size();i++) {
				if(entry.getValue().get(i).getUserType() != UserTypeEnum.QUANTIZED.getType()) {
					count ++ ;
				}
			}
		}
		for(Entry<String, ArrayListEx<Order>> entry: CacheUtil.orderModeBuyStopWin.entrySet()) {
			for(int i=0;i<entry.getValue().size();i++) {
				if(entry.getValue().get(i).getUserType() != UserTypeEnum.QUANTIZED.getType()) {
					count ++ ;
				}
			}
		}
		for(Entry<String, ArrayListEx<Order>> entry: CacheUtil.orderModeSellStopLoss.entrySet()) {
			for(int i=0;i<entry.getValue().size();i++) {
				if(entry.getValue().get(i).getUserType() != UserTypeEnum.QUANTIZED.getType()) {
					count ++ ;
				}
			}
		}
		for(Entry<String, ArrayListEx<Order>> entry: CacheUtil.orderModeSellStopWin.entrySet()) {
			for(int i=0;i<entry.getValue().size();i++) {
				if(entry.getValue().get(i).getUserType() != UserTypeEnum.QUANTIZED.getType()) {
					count ++ ;
				}
			}
		}
		for(Entry<String, ArrayListEx<Order>> entry: CacheUtil.orderModeBuyTrailingStopLoss.entrySet()) {
			for(int i=0;i<entry.getValue().size();i++) {
				if(entry.getValue().get(i).getUserType() != UserTypeEnum.QUANTIZED.getType()) {
					count ++ ;
				}
			}
		}
		for(Entry<String, ArrayListEx<Order>> entry: CacheUtil.orderModeSellTrailingStopLoss.entrySet()) {
			for(int i=0;i<entry.getValue().size();i++) {
				if(entry.getValue().get(i).getUserType() != UserTypeEnum.QUANTIZED.getType()) {
					count ++ ;
				}
			}
		}
		
		ServerStatus serverStatus = new ServerStatus();
		serverStatus.setServerId(config.getServerId());
		serverStatus.setServerName(config.getAppName());
		serverStatus.setProperty("orderModeSize-non-quantized-memory");
		serverStatus.setValue(String.valueOf(count));		
		listResponse.getData().add(serverStatus);
		
		serverStatus = new ServerStatus();
		serverStatus.setServerId(config.getServerId());
		serverStatus.setServerName(config.getAppName());
		serverStatus.setProperty("orderModeSize-db");
		serverStatus.setValue(String.valueOf(orderService.getOrderModeCount()));		
		listResponse.getData().add(serverStatus);
		
		return listResponse;
	}
	
	
	@RequestMapping(value="/shutdown", produces="application/json", method=RequestMethod.GET)
	public ListResponse<ServerStatus> shutdown() throws Exception{
		
		long start = System.currentTimeMillis();
		
		//开启线程处理积压请求
		if(CacheUtil.dataServiceState != AppStateEnum.SHUTTING_DOWN) {
								
			//清理所有积压请求
			for(AsyncRequest item: CacheUtil.requestMap.values()) {

				Set<Long> guidSet = new HashSet<Long>();
				for(QueryRequestItem request: item.getRequest().getQueryRequestItemList()) {
					guidSet.add(request.getGuid());
				}
				
				for(QueryResponseItem response: item.getQueryResponseItemList()) {
					guidSet.remove(response.getGuid());
				}
				
				//补全所有缺失的响应
				for(long guid: guidSet) {
					 //清空一个批次的未处理信息
					CacheUtil.requestMap.remove(guid);
					
					QueryResponseItem queryResponseItem = QueryResponseItem.createResponseBase(guid, "request.expired");
					item.getQueryResponseItemList().add(queryResponseItem);
					//中转socket连入的，立即返回
					if(item.getSocketResultQueue()!=null) {
						item.getSocketResultQueue().offer(queryResponseItem);
					}
					
				}				
			}			
		}
		
		Thread.sleep(3000);
		
		CacheUtil.dataServiceState = AppStateEnum.SHUTTING_DOWN;
		
		ListResponse<ServerStatus> listResponse = new ListResponse<ServerStatus>();
		
		List<ServerStatus> serverStatusList = new ArrayList<ServerStatus>();
		listResponse.setData(serverStatusList);
		
		
		ServerStatus serverStatus = new ServerStatus();
		serverStatus.setServerId(config.getServerId());
		serverStatus.setServerName(config.getAppName());
		serverStatus.setProperty("state");
		serverStatus.setValue(CacheUtil.dataServiceState.getDescription());		
		serverStatusList.add(serverStatus);
		
		LogUtil.logInfo("ManageController-shutdown", start, "Shut down finished");
		
		LogUtil.logInfo("AppState", 0, "SHUTTING_DOWN");
		
		return listResponse;
	}
	
	
	private ListResponse<ServerStatus> httpGet(String url, String serviceName, Map<String, String> map){
		
		CloseableHttpClient httpClient = null;
		CloseableHttpResponse httpResponse = null;
		
		ListResponse<ServerStatus> listResponse = new ListResponse<>();
		listResponse.setData(new ArrayList<>());
		
		try {
			
			httpClient = HttpClients.createDefault();
			URIBuilder uriBuilder = new URIBuilder(new StringBuilder(url).append(serviceName).toString());
			if(map!=null) {
				for(Entry<String,String> entry: map.entrySet()) {
					uriBuilder.addParameter(entry.getKey(), entry.getValue());
				}
			}
			
 			HttpGet httpGet = new HttpGet(uriBuilder.build());
			httpResponse = httpClient.execute(httpGet);
			HttpEntity entity = httpResponse.getEntity();
			String responseBody = EntityUtils.toString(entity, "UTF-8");

			ListResponse<ServerStatus> serverStatuses = JSON.parseObject(responseBody, new TypeReference<ListResponse<ServerStatus>>(){});
			if(serverStatuses!=null && serverStatuses.getData()!=null) {
				listResponse.getData().addAll(serverStatuses.getData());
			}
			
		}catch(Exception ex) {
			logger.error("httpGet error, url={}, exception->{}", url, ex.getMessage());
		}finally {
			if(Objects.nonNull(httpResponse)){
				try {
					httpResponse.close();
				} catch (IOException e) {
				}
			}
		}
		
		return listResponse;
	}
	
	@RequestMapping(value="/shutAllDown", produces="application/json", method=RequestMethod.GET)
	public ListResponse<ServerStatus> shutAllDown() {
		long start = System.currentTimeMillis();
		ListResponse<ServerStatus> listResponse = new ListResponse<>();
		listResponse.setData(new ArrayList<>());
		
		if(StringUtils.isNotBlank(config.getServerDetailStatusUrls())){

			String[] serverStatusUrls = config.getServerDetailStatusUrls().split(",");
			
			//核心ip放前面
			for (String url : serverStatusUrls){
				ListResponse<ServerStatus> response = httpGet(url.trim(), SHUTDOWN, null);
				
				listResponse.getData().addAll(response.getData());
			}
		}
        LogUtil.logInfo("ManageController-shutAllDown",start,String.format("shutAllDown size %d",listResponse.getData().size()));
		return listResponse;
	}
	
	
	@RequestMapping(value="/getAllServerStatus", produces="application/json", method=RequestMethod.GET)
	public ListResponse<ServerStatus> getAllServerStatus() {
		
		ListResponse<ServerStatus> listResponse = new ListResponse<>();
		listResponse.setData(new ArrayList<>());
		
		if(StringUtils.isNotBlank(config.getServerDetailStatusUrls())){
			
			String[] serverStatusUrls = config.getServerDetailStatusUrls().split(",");
			
			for (String url : serverStatusUrls){
				
				ListResponse<ServerStatus> response = httpGet(url.trim(), SERVER_STATUS, null);
				listResponse.getData().addAll(response.getData());				
			}		
		}

		return listResponse;
	}
	
	
	@RequestMapping(value="/getAllServerDetailStatus", produces="application/json", method=RequestMethod.GET)
	public ListResponse<ServerStatus> getAllServerDetailStatus() {
		
		ListResponse<ServerStatus> listResponse = new ListResponse<>();
		listResponse.setData(new ArrayList<>());
		
		if(StringUtils.isNotBlank(config.getServerDetailStatusUrls())){
			
			String[] serverStatusUrls = config.getServerDetailStatusUrls().split(",");
			
			for (String url : serverStatusUrls){
				
				ListResponse<ServerStatus> response = httpGet(url.trim(), SERVER_DETAIL_STATUS, null);
				listResponse.getData().addAll(response.getData());				
			}		
		}

		return listResponse;
	}
	
	
	@RequestMapping(value="/compareCoreAndData", produces="application/json", method=RequestMethod.GET)
	public ListResponse<ServerStatus> compareCoreAndData() {
		
		ListResponse<ServerStatus> listResponse = new ListResponse<>();
		listResponse.setData(new ArrayList<>());
		
		if(StringUtils.isNotBlank(config.getServerDetailStatusUrls())){
			
			String[] serverStatusUrls = config.getServerDetailStatusUrls().split(",");
			
			Map<String, ServerStatus> coreStatusMap = new HashMap<String, ServerStatus>(Constants.COLLECTION_DEFAULT_SIZE);
			Map<String, ServerStatus> dataStatusMap = new HashMap<String, ServerStatus>(Constants.COLLECTION_DEFAULT_SIZE);
			
			for (String url : serverStatusUrls){
				
				ListResponse<ServerStatus> response = httpGet(url.trim(), SERVER_DETAIL_STATUS, null);
				if(response.getData()!=null && response.getData().size()>0) {
					if(response.getData().get(0).getServerName().equals("iexchange-core-service")) {
						for(ServerStatus item: response.getData()) {
							coreStatusMap.put(item.getProperty(), item);
						}
					}else if(response.getData().get(0).getServerName().equals("iexchange-data-service")) {
						for(ServerStatus item: response.getData()) {
							dataStatusMap.put(item.getProperty(), item);
						}
					}
				}				
			}	
			
			
			if(coreStatusMap.size()>0 && dataStatusMap.size()>0) {
				for(ServerStatus dataItem: dataStatusMap.values()) {
					ServerStatus coreItem = coreStatusMap.get(dataItem.getProperty());
					
					if(coreItem!=null) {
						if(!dataItem.getValue().equals(coreItem.getValue())) {
							
							ServerStatus serverStatus = new ServerStatus();
							serverStatus.setServerId(config.getServerId());
							serverStatus.setServerName(config.getAppName());
							serverStatus.setProperty(coreItem.getProperty());
							serverStatus.setValue("NOT_MATCH");		
							listResponse.getData().add(serverStatus);
							
						}else {
							
							ServerStatus serverStatus = new ServerStatus();
							serverStatus.setServerId(config.getServerId());
							serverStatus.setServerName(config.getAppName());
							serverStatus.setProperty(coreItem.getProperty());
							serverStatus.setValue("MATCH");		
							listResponse.getData().add(serverStatus);
							
						}
					}
				}
			}
		}

		return listResponse;
	}
	
	
	@RequestMapping(value="/compareAccount", produces="application/json", method=RequestMethod.GET)
	public ListResponse<Account> compareAccount() {

		List<Account> accountList = accountService.compareAccount();
		
		ListResponse<Account> listResponse = new ListResponse<Account>();
		
		MessageUtil.getMessage(listResponse, "success");
		
		listResponse.setData(accountList);
		
		return listResponse;
	}
	
	
	@RequestMapping(value="/renameCoinInner", produces="application/json", method=RequestMethod.GET)
	public ListResponse<ServerStatus> renameCoinInner(@RequestParam("from") String from, @RequestParam("to") String to) {
				
		ListResponse<ServerStatus> listResponse = new ListResponse<>();
		listResponse.setData(new ArrayList<>());
		
		ServerStatus serverStatus = new ServerStatus();
		serverStatus.setServerId(config.getServerId());
		serverStatus.setServerName(config.getAppName());
		serverStatus.setProperty("status");
		serverStatus.setValue(MessageUtil.getMessage("success").getMessage());
		
		listResponse.getData().add(serverStatus);
		
		
		if(from == null || to == null) {
			serverStatus.setValue(MessageUtil.getMessage("input.null").getMessage());
			return listResponse;
		}
		
		//修正coin
		Coin coin = null;
		for(Coin item: CacheUtil.coinMap.values()) {
			if(item.getCode().equals(from)) {
				coin = item;
				break;
			}
		}
		
		if(coin == null) {
			serverStatus.setValue(MessageUtil.getMessage("coin.notFound").getMessage());
			return listResponse;
		}
				
		coin.setCode(to);
		
		//修正pair
		Map<String, String> pairNameMap = new HashMap<String, String>(Constants.COLLECTION_DEFAULT_SIZE);
		
		for(Pair item: CacheUtil.pairMap.values()) {			
			String[] coins = item.getPairName().split("_");			
			if(coins[0].equals(from)) {
				pairNameMap.put(item.getPairName(), String.format("%s_%s", to, coins[1]));
			}
		}
		
		//没有重命名的交易对
		if(pairNameMap.size()==0) {
			return listResponse;
		}
		
		for(Entry<String, String> entry: pairNameMap.entrySet()) {
			Pair pair = CacheUtil.pairMap.remove(entry.getKey());
			pair.setPairName(entry.getValue());
			pair.setBaseCoinCode(to);
			CacheUtil.pairMap.put(pair.getPairName(), pair);
		}		
		
		
		
		//修正depth
		for(Entry<String, String> entry: pairNameMap.entrySet()) {
			
			ArrayListEx<DepthMessage> list = CacheUtil.buyDepthMap.remove(entry.getKey());
			
			if(list!=null) {
				for(int i=0;i<list.size();i++) {
					DepthMessage item = list.get(i);
					if(item!=null) {
						item.setPairName(entry.getValue());
					}
				}
							
				CacheUtil.buyDepthMap.put(entry.getValue(), list);	
			}
			
			
			
			list = CacheUtil.sellDepthMap.remove(entry.getKey());
			if(list!=null) {
				for(int i=0;i<list.size();i++) {
					DepthMessage item = list.get(i);
					if(item!=null) {
						item.setPairName(entry.getValue());
					}
				}
				
				CacheUtil.sellDepthMap.put(entry.getValue(), list);
			}
			
			
			
			Map<Integer, List<DepthMessage>> map = CacheUtil.buyDepthMapSnapshot.remove(entry.getKey());
			
			if(map!=null) {
				for(List<DepthMessage> itemList: map.values()) {
					for(DepthMessage item: itemList) {
						item.setPairName(entry.getValue());
					}				
				}
				
				CacheUtil.buyDepthMapSnapshot.put(entry.getValue(), map);
			}
			
			
			
			
			map = CacheUtil.sellDepthMapSnapshot.remove(entry.getKey());
			if(map!=null) {
				for(List<DepthMessage> itemList: map.values()) {
					for(DepthMessage item: itemList) {
						item.setPairName(entry.getValue());
					}				
				}
				
				CacheUtil.sellDepthMapSnapshot.put(entry.getValue(), map);
			}
			
		}
		
		//修正orderBook
		for(Entry<String, String> entry: pairNameMap.entrySet()) {
			
			ArrayListEx<Order> list = CacheUtil.orderCurrentMapByPair.remove(entry.getKey());
			if(list!=null) {
				for(int i=0;i<list.size();i++) {
					Order order = list.get(i);
					if(order!=null) {
						order.setPairName(entry.getValue());
					}
				}
							
				CacheUtil.orderCurrentMapByPair.put(entry.getValue(), list);	
			}					
		}	
		
		
		for(Entry<String, String> entry: pairNameMap.entrySet()) {
			
			ArrayListEx<Order> list = CacheUtil.specialBuyOrderBook.remove(entry.getKey());
			if(list!=null) {
				for(int i=0;i<list.size();i++) {
					Order order = list.get(i);
					if(order!=null) {
						order.setPairName(entry.getValue());
					}
				}
							
				CacheUtil.specialBuyOrderBook.put(entry.getValue(), list);	
			}					
		}	
		
		
		for(Entry<String, String> entry: pairNameMap.entrySet()) {
			
			ArrayListEx<Order> list = CacheUtil.specialSellOrderBook.remove(entry.getKey());
			if(list!=null) {
				for(int i=0;i<list.size();i++) {
					Order order = list.get(i);
					if(order!=null) {
						order.setPairName(entry.getValue());
					}
				}
							
				CacheUtil.specialSellOrderBook.put(entry.getValue(), list);	
			}					
		}	


		
		//修正24小时数据 Order
		for(ArrayListEx<Order> list: CacheUtil.orderAllMapByUserNonQuantized.values()) {
			for(int i=0;i<list.size();i++) {
				Order item = list.get(i);
				
				String newPairName = pairNameMap.get(item.getPairName());
				if(newPairName!=null) {
					item.setPairName(newPairName);
				}
			}
		}
		
		
		//修正24小时交易
		for(ArrayListEx<Trade> list: CacheUtil.tradeAllMapByUserNonQuantized.values()) {
			if(list!=null) {
				for(int i=0;i<list.size();i++) {
					Trade trade = list.get(i);
					if(trade!=null) {
						String newPairName = pairNameMap.get(trade.getPairName());
						if(newPairName!=null) {
							trade.setPairName(newPairName);
							if(trade.getBuyerFeeCoinCode().equals(from)) {
								trade.setBuyerFeeCoinCode(to);
							}	
							if(trade.getSellerFeeCoinCode().equals(from)) {
								trade.setSellerFeeCoinCode(to);
							}
						}
					}
				}
			}			
		}
		
		
		//修正止盈止损
		for(Entry<String, String> entry: pairNameMap.entrySet()) {
			
			ArrayListEx<Order> list = CacheUtil.orderModeBuyStopLoss.remove(entry.getKey());
			if(list!=null) {
				CacheUtil.orderModeBuyStopLoss.put(entry.getValue(), list);		
			}					
		}	
		
		for(Entry<String, String> entry: pairNameMap.entrySet()) {
			
			ArrayListEx<Order> list = CacheUtil.orderModeBuyStopWin.remove(entry.getKey());
			if(list!=null) {
				CacheUtil.orderModeBuyStopWin.put(entry.getValue(), list);		
			}
		}	
		
		


		for(Entry<String, String> entry: pairNameMap.entrySet()) {
			
			ArrayListEx<Order> list = CacheUtil.orderModeSellStopLoss.remove(entry.getKey());
			if(list!=null) {
				CacheUtil.orderModeSellStopLoss.put(entry.getValue(), list);		
			}
		}	
		
		for(Entry<String, String> entry: pairNameMap.entrySet()) {
			
			ArrayListEx<Order> list = CacheUtil.orderModeSellStopWin.remove(entry.getKey());
			if(list!=null) {
				CacheUtil.orderModeSellStopWin.put(entry.getValue(), list);	
			}
		}	
		
		
		
		
		
		for(Entry<String, String> entry: pairNameMap.entrySet()) {
			
			ArrayListEx<Order> list = CacheUtil.orderModeBuyTrailingStopLoss.remove(entry.getKey());
			if(list!=null) {
				CacheUtil.orderModeBuyTrailingStopLoss.put(entry.getValue(), list);		
			}
		}	
		
		for(Entry<String, String> entry: pairNameMap.entrySet()) {
			
			ArrayListEx<Order> list = CacheUtil.orderModeSellTrailingStopLoss.remove(entry.getKey());
			if(list!=null) {
				CacheUtil.orderModeSellTrailingStopLoss.put(entry.getValue(), list);			
			}
		}	
		
		
		return listResponse;
	}
	
	
	
	@RequestMapping(value="/renameCoin", produces="application/json", method=RequestMethod.GET)
	public ListResponse<ServerStatus> renameCoin(@RequestParam("from") String from, @RequestParam("to") String to) {

		ListResponse<ServerStatus> listResponse = new ListResponse<>();
		listResponse.setData(new ArrayList<>());
		
		Map<String, String> map = new HashMap<String, String>(Constants.COLLECTION_DEFAULT_SIZE);
		map.put("from", from);
		map.put("to", to);
		
		if(StringUtils.isNotBlank(config.getServerDetailStatusUrls())){

			String[] serverStatusUrls = config.getServerDetailStatusUrls().split(",");
			
			//核心ip放前面
			for (String url : serverStatusUrls){
				ListResponse<ServerStatus> response = httpGet(url.trim(), RENAME_COIN, map);
				
				listResponse.getData().addAll(response.getData());
			}
		}
		return listResponse;
	}
	
	
	@RequestMapping(value="/compareSpecialOrderBook", produces="application/json", method=RequestMethod.GET)
	public ListResponse<ServerStatus> compareSpecialOrderBook() {

		ListResponse<ServerStatus> listResponse = new ListResponse<>();
		listResponse.setData(new ArrayList<>());
		
		Map<String, Object> map = new HashMap<String, Object>(Constants.COLLECTION_DEFAULT_SIZE);
		
		ServerStatus serverStatus = new ServerStatus();
		serverStatus.setProperty("gap");
		listResponse.getData().add(serverStatus);
		
		for(Entry<String, ArrayListEx<Order>> entry: CacheUtil.specialBuyOrderBook.entrySet()) {
			for(int i=0;i<entry.getValue().size();i++) {
				Order order1 = entry.getValue().get(i);
				Order order2 = CacheUtil.orderCurrentAllMap.get(order1.getId());
				
				if(order2==null) {
					map.put(String.format("Miss-orderCurrentAllMap-%d", order1.getId()), order1);
				}else if(order1.getFilledQty().compareTo(order2.getFilledQty())!=0) {
					map.put(String.format("NotMatch-specialBuyOrderBook-%d", order1.getId()), order1);
				}
			}
		}
		
		for(Entry<String, ArrayListEx<Order>> entry: CacheUtil.specialSellOrderBook.entrySet()) {
			for(int i=0;i<entry.getValue().size();i++) {
				Order order1 = entry.getValue().get(i);
				Order order2 = CacheUtil.orderCurrentAllMap.get(order1.getId());
				
				if(order2==null) {
					map.put(String.format("Miss-orderCurrentAllMap-%d", order1.getId()), order1);
				}else if(order1.getFilledQty().compareTo(order2.getFilledQty())!=0) {
					map.put(String.format("NotMatch-specialSellOrderBook-%d", order1.getId()), order1);
				}
			}
		}
		
		
		for(Entry<Long, Order> entry: CacheUtil.orderCurrentAllMap.entrySet()) {
			
			if(entry.getValue().getOrderState() == OrderStateEnum.PENDING.getState()) {
				continue;
			}
			
			Order order1 = null;
			ArrayListEx<Order> list = CacheUtil.specialBuyOrderBook.get(entry.getValue().getPairName());
			if(list!=null && list.size()>0) {
				for(int i=0;i<list.size();i++) {
					if(list.get(i).getId() == entry.getValue().getId()) {
						order1 = list.get(i);
					}
				}
			}
			
			if(order1==null) {
				list = CacheUtil.specialSellOrderBook.get(entry.getValue().getPairName());
				if(list!=null && list.size()>0) {
					for(int i=0;i<list.size();i++) {
						if(list.get(i).getId() == entry.getValue().getId()) {
							order1 = list.get(i);
						}
					}
				}
			}
			
			if(order1==null) {
				map.put(String.format("Miss-specialOrderBook-%d", entry.getValue().getId()), entry.getValue());
			}else if(order1.getFilledQty().compareTo(entry.getValue().getFilledQty())!=0) {
				map.put(String.format("NotMatch-specialOrderBook-%d", order1.getId()), order1);
			}
		}
		
		serverStatus.setValue(JSON.toJSONString(map));
		
		return listResponse;
	}
}
