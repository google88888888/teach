package mn.idax.data.query.service.impl;

import mn.idax.data.query.service.OrderQueryService;
import mn.idax.data.query.service.QueryService;
import mn.idax.data.query.service.TradeQueryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import mn.idax.common.query.request.QueryRequestItem;
import mn.idax.common.query.response.QueryResponseItem;
import mn.idax.data.bean.AsyncRequest;
import mn.idax.data.query.service.AccountQueryService;
import mn.idax.data.query.service.DepthQueryService;
import mn.idax.data.util.CacheUtil;

/**
 * @author zhouou 214108525@qq.com
 *
 * 2018年12月7日
 */

@Service
public class QueryServiceImpl implements QueryService{
	
	private static final int BATCH_SIZE = 10000;
	
	
	@Autowired
	private AccountQueryService accountQueryService;
	
	@Autowired
	private OrderQueryService orderQueryService;
	
	@Autowired
	private TradeQueryService tradeQueryService;
		
	@Autowired
	private DepthQueryService depthQueryService;
	
	@Override
	public void doProcess() {
		
		AsyncRequest asyncRequest = null;
		
		int count=0;
		while((asyncRequest = CacheUtil.requestQueue.poll()) != null) {					
			
			for(QueryRequestItem request: asyncRequest.getRequest().getQueryRequestItemList()) {
				count++;
				
				if(request.getGetDepthRequest()!=null) {		
					
					QueryResponseItem queryResponseItem = new QueryResponseItem();
					queryResponseItem.setGuid(request.getGuid());
					int digits = request.getGetDepthRequest().getDigits();
					if(digits<=0 || digits>8) {
						digits = 8;
					}
					queryResponseItem.setDepthResponse(depthQueryService.getDepth(request.getGetDepthRequest().getPairName(), request.getGetDepthRequest().getSize(), digits));				
					CacheUtil.asyncResponse(queryResponseItem);	
					
				}else if(request.getGetUserAccountRequest()!=null) {
					
					QueryResponseItem queryResponseItem = accountQueryService.getUserAccount(request.getGuid(), request.getGetUserAccountRequest());					
					CacheUtil.asyncResponse(queryResponseItem);		
					
				}else if(request.getGetBalanceRequest()!=null) {
					
					QueryResponseItem queryResponseItem = accountQueryService.getBalance(request.getGuid(), request.getGetBalanceRequest());
					CacheUtil.asyncResponse(queryResponseItem);
					
				}else if(request.getGetCurrentOrdersRequest()!=null) {

					QueryResponseItem queryResponseItem = orderQueryService.getCurrentOrder(request.getGuid(), request.getGetCurrentOrdersRequest());
					CacheUtil.asyncResponse(queryResponseItem);

				}else if(request.getGetCurrentOrdersAdminRequest()!=null) {

					QueryResponseItem queryResponseItem = orderQueryService.getCurrentOrderAdmin(request.getGuid(), request.getGetCurrentOrdersAdminRequest());
					CacheUtil.asyncResponse(queryResponseItem);

				}else if(request.getGetOrdersRequest()!=null) {
					
					QueryResponseItem queryResponseItem = orderQueryService.getOrders(request.getGuid(), request.getGetOrdersRequest());
					CacheUtil.asyncResponse(queryResponseItem);
					
				}else if (request.getGetDirectedOrderRequest() != null){
					
					QueryResponseItem queryResponseItem = orderQueryService.getOrderInfo(request.getGuid(), request.getGetDirectedOrderRequest());
					CacheUtil.asyncResponse(queryResponseItem);
					
				}else if (request.getGetFinishTradesRequest() != null){
					
					QueryResponseItem queryResponseItem = tradeQueryService.geFinishTrades(request.getGuid(), request.getGetFinishTradesRequest());
					CacheUtil.asyncResponse(queryResponseItem);
					
				}else if (request.getGetOrdersByModeRequest() != null){
					
					QueryResponseItem queryResponseItem = orderQueryService.getOrdersByMode(request.getGuid(), request.getGetOrdersByModeRequest());
					CacheUtil.asyncResponse(queryResponseItem);
					
				}else if(request.getGetUserRequest() != null) {
					QueryResponseItem queryResponseItem = QueryResponseItem.createUserResponse(request.getGuid(), "success");
					queryResponseItem.getUserResponse().setData(CacheUtil.userMap.get(request.getGetUserRequest().getUserId()));					
					CacheUtil.asyncResponse(queryResponseItem);
				}else if(request.getGetSpecialDepthRequest() != null) {
					CacheUtil.specialDepthRequestQueue.offer(request.getGetSpecialDepthRequest());
				}
			}
						
			
			if(count >= BATCH_SIZE) {
				break;
			}
		}
		
	}
}
