package mn.idax.data.util;

import java.math.BigDecimal;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.alibaba.fastjson.JSON;

import mn.idax.common.bean.DepthMessage;
import mn.idax.common.util.ArrayListEx;

/**
 * @author zhouou 214108525@qq.com
 *
 * 2018年11月12日
 * 
 * 买  价高->价低    
 * 卖  价低->价高    
 * 
 */
public class DepthUtil {
	
	private static final Logger logger = LoggerFactory.getLogger(DepthUtil.class);
	
	private static int updateBuyDepthHalf(ArrayListEx<DepthMessage> list, DepthMessage depth, int index) {

        if (depth.getPrice().compareTo(list.get(index).getPrice()) == 0) {
        	list.set(index, depth);
            return index;
        }

        if (index > 0) {
            if (depth.getPrice().compareTo(list.get(index - 1).getPrice()) < 0 && depth.getPrice().compareTo(list.get(index).getPrice()) > 0) {
                list.add(index, depth);
                return index;
            }
        }

        if (index < list.size() - 1) {
            if (depth.getPrice().compareTo(list.get(index).getPrice()) < 0 && depth.getPrice().compareTo(list.get(index + 1).getPrice()) > 0) {
                list.add(index + 1, depth);
                return index + 1;
            }
        }

        return -1;
    }
	
	private static int updateBuyDepth(ArrayListEx<DepthMessage> list, DepthMessage depth) {
						
		//判断 0个或1个
        if (list.size() == 0) {
            list.add(depth);
            return 0;
        } else if (list.size() == 1) {
            if (depth.getPrice().compareTo(list.get(0).getPrice()) == 0) {
            	list.set(0, depth);
                return 0;
            } else if (depth.getPrice().compareTo(list.get(0).getPrice()) > 0) {
                list.add(0, depth);
                return 0;
            } else {
                list.add(depth);
                return list.size() - 1;
            }
        }

        //存在2条以上数据

        //判断是否头尾插入或修改
        if (depth.getPrice().compareTo(list.get(0).getPrice()) == 0) {
        	list.set(0, depth);
            return 0;
        }
        if (depth.getPrice().compareTo(list.get(0).getPrice()) > 0) {
            list.add(0, depth);
            return 0;
        }
        
        int lastIndex = list.size() - 1;
        if (depth.getPrice().compareTo(list.get(lastIndex).getPrice()) == 0) {
        	
            list.set(lastIndex, depth);
            return lastIndex;
        }
        if (depth.getPrice().compareTo(list.get(lastIndex).getPrice()) < 0) {
            list.add(depth);
            return list.size() - 1;
        }


        int index1 = 0, index2 = list.size() - 1;

        //二分法查找
        while (true) {
            int index = index1 + (index2 - index1) / 2;

            int updateBuyResult = updateBuyDepthHalf(list, depth, index);
          //已找到并修改
            if (updateBuyResult >= 0) {
                return updateBuyResult;
            } else if (depth.getPrice().compareTo(list.get(index).getPrice()) > 0) {
                index2 = index;
            } else {
                index1 = index;
            }
        }
	}
	
	
	public static void processBuyDepth(ArrayListEx<DepthMessage> list, DepthMessage depth) {
		int index = updateBuyDepth(list, depth);
		
		DepthMessage depthChange = list.get(index);
		if(depthChange.getQty().compareTo(BigDecimal.ZERO) <= 0) {
			if(depthChange.getQty().compareTo(BigDecimal.ZERO) < 0) {
				logger.error("IEXCHANGE-COMMON-ERROR Depth quantity is less than 0 {}", JSON.toJSONString(depthChange));
			}
			
			list.remove(index);
		}
	
	}
	
	
	
	
	


	private static int updateSellDepthHalf(ArrayListEx<DepthMessage> list, DepthMessage depth, int index) {

        if (depth.getPrice().compareTo(list.get(index).getPrice()) == 0) {
        	list.set(index, depth);
            return index;
        }

        if (index > 0) {
            if (depth.getPrice().compareTo(list.get(index - 1).getPrice()) > 0 && depth.getPrice().compareTo(list.get(index).getPrice()) < 0) {
                list.add(index, depth);
                return index;
            }
        }

        if (index < list.size() - 1) {
            if (depth.getPrice().compareTo(list.get(index).getPrice()) > 0 && depth.getPrice().compareTo(list.get(index + 1).getPrice()) < 0) {
                list.add(index + 1, depth);
                return index + 1;
            }
        }

        return -1;
    }
	
	private static int updateSellDepth(ArrayListEx<DepthMessage> list, DepthMessage depth) {
						
		//判断 0个或1个
        if (list.size() == 0) {
            list.add(depth);
            return 0;
        } else if (list.size() == 1) {
            if (depth.getPrice().compareTo(list.get(0).getPrice()) == 0) {
            	list.set(0, depth);
                return 0;
            } else if (depth.getPrice().compareTo(list.get(0).getPrice()) < 0) {
                list.add(0, depth);
                return 0;
            } else {
                list.add(depth);
                return list.size() - 1;
            }
        }

        //存在2条以上数据

        //判断是否头尾插入或修改
        if (depth.getPrice().compareTo(list.get(0).getPrice()) == 0) {
        	list.set(0, depth);
            return 0;
        }
        if (depth.getPrice().compareTo(list.get(0).getPrice()) < 0) {
            list.add(0, depth);
            return 0;
        }
        
        int lastIndex = list.size() - 1;
        if (depth.getPrice().compareTo(list.get(lastIndex).getPrice()) == 0) {
        	
            list.set(lastIndex, depth);
            return lastIndex;
        }
        if (depth.getPrice().compareTo(list.get(lastIndex).getPrice()) > 0) {
            list.add(depth);
            return list.size() - 1;
        }


        int index1 = 0, index2 = list.size() - 1;

        //二分法查找
        while (true) {
            int index = index1 + (index2 - index1) / 2;

            int updateSellResult = updateSellDepthHalf(list, depth, index);
          //已找到并修改
            if (updateSellResult >= 0) {
                return updateSellResult;
            } else if (depth.getPrice().compareTo(list.get(index).getPrice()) < 0) {
                index2 = index;
            } else {
                index1 = index;
            }
        }
	}
	
	
	public static void processSellDepth(ArrayListEx<DepthMessage> list, DepthMessage depth) {
		int index = updateSellDepth(list, depth);
		
		DepthMessage depthChange = list.get(index);
		if(depthChange.getQty().compareTo(BigDecimal.ZERO) <= 0) {
			if(depthChange.getQty().compareTo(BigDecimal.ZERO) < 0) {
				logger.error("IEXCHANGE-COMMON-ERROR Depth quantity is less than 0 {}", JSON.toJSONString(depthChange));
			}
			
			list.remove(index);
		}
		
	}
	
	
}
