package mn.idax.data.db.service.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import mn.idax.common.entity.Account;
import mn.idax.common.util.LogUtil;
import mn.idax.data.db.service.AccountService;
import mn.idax.data.util.CacheUtil;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


/**
 * @author zhouou 214108525@qq.com
 *
 * 2018年10月31日
 */
@Service
public class AccountServiceImpl implements AccountService{
	
	private static final Logger logger = LoggerFactory.getLogger(AccountServiceImpl.class);
	
	@Autowired
	private DataSource dataSource;
	
	@Override
	public List<Account> compareAccount(){		
		
		long start = System.currentTimeMillis();
		
		
		String sql = "select Id,UserId,CoinId,AvailableAmount,FrozenAmount,CreateTime,UpdateTime from [Account]";
		
		Connection connection = null;
		PreparedStatement statement = null;
		ResultSet resultSet=null;
		
		List<Account> accountList = new ArrayList<Account>(10000);;
		
		try {		
			
			connection = dataSource.getConnection();
			statement = connection.prepareStatement(sql);
			statement.setFetchSize(10000);
			resultSet=statement.executeQuery();
			while(resultSet.next()){
				
				Account account = new Account();
				account.setId(resultSet.getInt(1));
				account.setUserId(resultSet.getInt(2));
				account.setCoinId(resultSet.getInt(3));
				account.setAvailableAmount(resultSet.getBigDecimal(4));
				account.setFrozenAmount(resultSet.getBigDecimal(5));
				account.setCreateTime(resultSet.getTimestamp(6));
				account.setUpdateTime(resultSet.getTimestamp(7));
				
				Account exist = CacheUtil.accountMap.get(account.getUserId()).get(account.getCoinId());
				if(exist==null) {
					accountList.add(account);
					continue;
				}
				
				if(account.getAvailableAmount().compareTo(exist.getAvailableAmount())!=0 || account.getFrozenAmount().compareTo(exist.getFrozenAmount())!=0) {
					accountList.add(account);
					accountList.add(exist);
				}
				
				if(accountList.size()>1000) {
					return accountList;
				}
			}			
			
		}catch (SQLException ex) {
			logger.error("IEXCHANGE-DB-ERROR {}",ex);
		}finally {
			if (statement != null) {
				try {
					statement.close();
				} catch (SQLException ex) {
				}
			}
			
			if (connection != null) {
				try {
					connection.close();
				} catch (SQLException ex) {
				}
			}
		} 
		
		LogUtil.logInfo("AccountServiceImpl-readAccountList", start,null);
		
		return accountList;
		
	}

}
