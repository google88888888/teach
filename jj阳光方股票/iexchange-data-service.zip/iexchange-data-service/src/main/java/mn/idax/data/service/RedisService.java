package mn.idax.data.service;

import mn.idax.common.bean.RiskEvent;
import mn.idax.data.bean.RiskControlProperty;

/**
 * @author zhouou 214108525@qq.com
 *
 * 2019年5月27日
 */
public interface RedisService {
	
	/**发布风控消息
	 * @param event
	 */
	void publishRiskEvent(RiskEvent event);
	
	/**获取风控配置
	 * @return
	 */
	RiskControlProperty getRiskControlProperty();	

}
