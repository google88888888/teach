package mn.idax.data.web;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import mn.idax.common.entity.User;
import mn.idax.common.response.SingleResponse;
import mn.idax.common.util.MessageUtil;
import mn.idax.data.util.CacheUtil;

/**
 * @author zhouou 214108525@qq.com
 *
 * 2019年7月19日
 */
@RestController("userQueryController")
public class UserQueryController {
	
	@RequestMapping(value="/getUserById", produces="application/json", method=RequestMethod.GET)
	public SingleResponse<User> getBuyDepth(@RequestParam(value="userId")  int userId) {
		
		SingleResponse<User> response = new SingleResponse<User>();
		
		if(userId <= 0) {
			MessageUtil.getMessage(response, "input.null");
			
			return response;
		}
		
		User user = CacheUtil.userMap.get(userId);
		
		response.setData(user);		
		
		return response;
	}

}
