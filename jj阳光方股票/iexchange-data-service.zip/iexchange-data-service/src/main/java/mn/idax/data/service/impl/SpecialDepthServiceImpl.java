package mn.idax.data.service.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSON;

import mn.idax.common.bean.SpecialDepthMessage;
import mn.idax.common.constant.OrderSideEnum;
import mn.idax.common.constant.OrderStateEnum;
import mn.idax.common.constant.UserTypeEnum;
import mn.idax.common.entity.Order;
import mn.idax.common.query.request.GetSpecialDepthRequest;
import mn.idax.common.query.response.QueryResponseItem;
import mn.idax.common.query.response.SpecialDepthResponse;
import mn.idax.common.query.response.SpecialOrderResponse;
import mn.idax.common.util.ArrayListEx;
import mn.idax.common.util.MessageUtil;
import mn.idax.data.service.SpecialDepthService;
import mn.idax.data.util.CacheUtil;
import mn.idax.data.util.SpecialOrderBookUtil;

/**
 * @author zhouou 214108525@qq.com
 *
 * 2019年6月24日
 */
@Service
public class SpecialDepthServiceImpl implements SpecialDepthService{

	private static final Logger logger = LoggerFactory.getLogger(SpecialDepthServiceImpl.class);
	
	private Map<Long, Order> orderMap = new LinkedHashMap<Long, Order>();
	
	private static final int BATCH_SIZE = 10000;
	
	public void doProcessOrderBook() {
		
		int count = 0;
		orderMap.clear();
		
		//降频
		Order order;
		while((order = CacheUtil.orderSpecialQueue.poll())!=null) {			
			
			orderMap.put(order.getId(), order);
				
			count++;

			if (count >= BATCH_SIZE) {
				break;
			}
		}
		
		
		for(Order item:orderMap.values()) {
			
			if(item.getOrderSide() == OrderSideEnum.BUY.getSide()) {
				
				ArrayListEx<Order> list = CacheUtil.specialBuyOrderBook.get(item.getPairName());
				if(list==null) {
					list = new ArrayListEx<Order>();
					CacheUtil.specialBuyOrderBook.put(item.getPairName(), list);
				}
				
				if(item.getOrderState() == OrderStateEnum.NEW.getState() || item.getOrderState() == OrderStateEnum.PARTIALLY_FILLED.getState()) {		
					SpecialOrderBookUtil.processBuyOrderBook(list, item);
				}else if(item.getOrderState() != OrderStateEnum.PENDING.getState()){						
					SpecialOrderBookUtil.removeBuyOrderBook(list, item);
				}
				
			}else {
				
				ArrayListEx<Order> list = CacheUtil.specialSellOrderBook.get(item.getPairName());
				if(list==null) {
					list = new ArrayListEx<Order>();
					CacheUtil.specialSellOrderBook.put(item.getPairName(), list);
				}
				
				if(item.getOrderState() == OrderStateEnum.NEW.getState() || item.getOrderState() == OrderStateEnum.PARTIALLY_FILLED.getState()) {	
					SpecialOrderBookUtil.processSellOrderBook(list, item);	
				}else if(item.getOrderState() != OrderStateEnum.PENDING.getState()) {						
					SpecialOrderBookUtil.removeSellOrderBook(list, item);						
				}
			}	
		}
		
	}
	
	private SpecialOrderResponse mapperOrderResponse(Order order) {
		
		SpecialOrderResponse orderResponse = new SpecialOrderResponse();
        
        orderResponse.setId(order.getId());
        orderResponse.setOrdertype(order.getOrderType());
        orderResponse.setOrderside(order.getOrderSide());
        orderResponse.setUserid(order.getUserId());
        orderResponse.setPairname(order.getPairName());
        orderResponse.setPrice(order.getPrice());
        orderResponse.setTotal(order.getTotal());
        orderResponse.setFilledqty(order.getFilledQty());
        orderResponse.setFrozen(order.getFrozen());
        orderResponse.setOrderstate(order.getOrderState());
        orderResponse.setFilledamount(order.getFilledAmount());
        orderResponse.setCreatetime(order.getCreateTime());
        orderResponse.setUpdatetime(order.getUpdateTime());
        orderResponse.setUserType(order.getUserType());
        
        return orderResponse;
	}
	
	private static final int MAX_SIZE = 1000;
	
	private List<SpecialDepthMessage> aggregate(GetSpecialDepthRequest getSpecialDepthRequest,ArrayListEx<Order> list, boolean isCustomer){
		
		List<SpecialDepthMessage> specialDepthMessageList= new ArrayList<SpecialDepthMessage>();
		
		SpecialDepthMessage specialDepthMessage = null;
		
		for(int i=0;i<list.size();i++) {
			Order order = list.get(i);
			
			if(isCustomer && order.getUserType() == UserTypeEnum.QUANTIZED.getType()) {
				continue;
			}
			
			if(specialDepthMessageList.size()==0 || specialDepthMessageList.get(specialDepthMessageList.size()-1).getPrice().compareTo(order.getPrice())!=0) {
				if(specialDepthMessageList.size() >= getSpecialDepthRequest.getSize()) {
					return specialDepthMessageList;
				}else {
					specialDepthMessage = new SpecialDepthMessage();
					specialDepthMessage.setPrice(order.getPrice());
					specialDepthMessage.setQty(BigDecimal.ZERO);
					specialDepthMessageList.add(specialDepthMessage);
				}
			}else {
				specialDepthMessage = specialDepthMessageList.get(specialDepthMessageList.size()-1);
			}
			
			specialDepthMessage.setQty(specialDepthMessage.getQty().add(order.getTotal().subtract(order.getFilledQty())));
			
			//防止同一价格订单过多爆掉
			if(specialDepthMessage.getOrderList().size() < MAX_SIZE) {
				specialDepthMessage.getOrderList().add(mapperOrderResponse(order));			
			}
			
		}
	
		return specialDepthMessageList;
	}
	
	private SpecialDepthResponse getSpecialDepth(GetSpecialDepthRequest getSpecialDepthRequest) {
		
		SpecialDepthResponse specialDepthResponse = new SpecialDepthResponse();
		specialDepthResponse.setPairName(getSpecialDepthRequest.getPairName());
		specialDepthResponse.setCreateTime(new Date());
		specialDepthResponse.setGuid(getSpecialDepthRequest.getGuid());
		
		ArrayListEx<Order> list = CacheUtil.specialBuyOrderBook.get(getSpecialDepthRequest.getPairName());
		if(list!=null && list.size() > 0) {
			specialDepthResponse.setBuyDepthList(aggregate(getSpecialDepthRequest, list,getSpecialDepthRequest.getIsCustomer()));		
		}		
		
		list = CacheUtil.specialSellOrderBook.get(getSpecialDepthRequest.getPairName());
		if(list!=null && list.size() > 0) {
			specialDepthResponse.setSellDepthList(aggregate(getSpecialDepthRequest, list,getSpecialDepthRequest.getIsCustomer()));			
		}

		return specialDepthResponse;
	}
	
	public void doProcessRequest() {
		
		GetSpecialDepthRequest getSpecialDepthRequest;
		
		while((getSpecialDepthRequest = CacheUtil.specialDepthRequestQueue.poll())!=null) {	
			
	        QueryResponseItem response = new QueryResponseItem();
			response.setGuid(getSpecialDepthRequest.getGuid());
			
 			response.setSpecialDepthResponse(getSpecialDepth(getSpecialDepthRequest));
			MessageUtil.getMessage(response.getSpecialDepthResponse(), "success");
			
			CacheUtil.asyncResponse(response);			
		}
	}
}
