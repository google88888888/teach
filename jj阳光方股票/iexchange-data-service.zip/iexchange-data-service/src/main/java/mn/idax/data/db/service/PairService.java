package mn.idax.data.db.service;

import java.util.List;

import mn.idax.common.entity.Pair;

/**
 * @author zhouou 214108525@qq.com
 *
 * 2018年11月7日
 */
public interface PairService {


	/**
	 * 从DB中获取数字货币的交易对配置信息
	 * @return
	 */
	List<Pair> readPairList();

}
