package mn.idax.data.service;

import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;

/**
 * @author zhouou 214108525@qq.com
 *
 * 2018年12月12日
 */
public interface PushSocketService {


	/**
	 * 同步数据到 push
	 * @param socket
	 * @param inputStream
	 * @param outputStream
	 * @throws Exception
	 */
	void doProcess(Socket socket, InputStream inputStream, OutputStream outputStream) throws Exception;
	
}
