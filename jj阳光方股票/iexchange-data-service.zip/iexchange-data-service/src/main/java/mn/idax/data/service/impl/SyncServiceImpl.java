package mn.idax.data.service.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;

import org.apache.commons.lang3.time.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import mn.idax.common.bean.DepthMessage;
import mn.idax.common.bean.SyncMessage;
import mn.idax.common.bean.SyncMessageList;
import mn.idax.common.constant.AppStateEnum;
import mn.idax.common.constant.Constants;
import mn.idax.common.constant.OrderModeEnum;
import mn.idax.common.constant.OrderSideEnum;
import mn.idax.common.constant.OrderStateEnum;
import mn.idax.common.constant.OrderTypeEnum;
import mn.idax.common.constant.SocketStateEnum;
import mn.idax.common.constant.UserTypeEnum;
import mn.idax.common.entity.Account;
import mn.idax.common.entity.Order;
import mn.idax.common.entity.Pair;
import mn.idax.common.entity.Trade;
import mn.idax.common.util.ArrayListEx;
import mn.idax.common.util.LogUtil;
import mn.idax.data.bean.Config;
import mn.idax.data.service.SyncService;
import mn.idax.data.socket.SyncSocketClient;
import mn.idax.data.util.CacheUtil;
import mn.idax.data.util.DepthUtil;
import mn.idax.data.util.OrderBookByUserUtil;
import mn.idax.data.util.OrderModeUtil;
import mn.idax.data.util.TradeUtil;

/**
 * @author zhouou 214108525@qq.com
 *
 * 2018年11月16日
 */

@Service
public class SyncServiceImpl implements SyncService{

	@Autowired
	private Config config;
	
	@Autowired
	private InitService initService;
	
	private static final int BATCH_SIZE  = 100000;
	
	/**降频专用**/ 
	private Map<Integer, Account> accountPendingMap = new ConcurrentHashMap<Integer, Account>(10000);	
	
	
	
	/**降频专用**/
	private Map<String, Map<BigDecimal,DepthMessage>> buyDepthPendingMap = new ConcurrentHashMap<String, Map<BigDecimal,DepthMessage>>(10000);	
	
	/**降频专用**/
	private Map<String, Map<BigDecimal,DepthMessage>> sellDepthPendingMap = new ConcurrentHashMap<String, Map<BigDecimal,DepthMessage>>(10000);	
	
	
	private void reload(){
		
		long start = System.currentTimeMillis();
		
		LogUtil.logInfo("SyncServiceImpl-reload", 0, "Start Reload");	
		
		CacheUtil.dataServiceState = AppStateEnum.LOADING;		
		
		//清除所有的queue
		CacheUtil.accountQueue.clear();
		CacheUtil.orderByUserQueue.clear();
		CacheUtil.orderByPairQueue.clear();
		CacheUtil.orderHistoryQueue.clear();
		CacheUtil.buyDepthQueue.clear();
		CacheUtil.sellDepthQueue.clear();
		CacheUtil.tradeQueue.clear();	
		CacheUtil.orderSpecialQueue.clear();
		
		//防止定时线程没跑完影响结果
		try {
			Thread.sleep(5000);
		}catch(Exception ex) {
			
		}		
		
		//清除所有map
		CacheUtil.coinMap.clear();
		CacheUtil.userMap.clear();
		CacheUtil.pairMap.clear();
		CacheUtil.accountMap.clear();
		CacheUtil.orderCurrentMapByUser.clear();
		CacheUtil.orderCurrentMapByPair.clear();
		CacheUtil.orderCurrentAllMap.clear();
		CacheUtil.orderAllMapByUserNonQuantized.clear();
		CacheUtil.tradeAllMapByUserNonQuantized.clear();
		CacheUtil.buyDepthMap.clear();
		CacheUtil.buyDepthMapSnapshot.clear();
		CacheUtil.sellDepthMap.clear();
		CacheUtil.sellDepthMapSnapshot.clear();
		CacheUtil.specialBuyOrderBook.clear();
		CacheUtil.specialSellOrderBook.clear();
		
		CacheUtil.orderModeBuyStopLoss.clear();
		CacheUtil.orderModeBuyStopWin.clear();
		CacheUtil.orderModeSellStopLoss.clear();
		CacheUtil.orderModeSellStopWin.clear();
		CacheUtil.orderModeBuyTrailingStopLoss.clear();
		CacheUtil.orderModeSellTrailingStopLoss.clear();
		
		//加载订单数据到内存
		initService.loadOrder();		
		
		//加载交易数据到内存
		initService.loadTrade();
		
		//告诉socket进行全量拉取
		SyncSocketClient.PULL_DATA_ALL = true;
				
		CacheUtil.dataServiceState = AppStateEnum.RUNNING;
		
		LogUtil.logInfo("SyncServiceImpl-reload", start, "End Reload");
		
	}
	
	
	@Override
	public void doProcess(SyncMessageList syncMessageList) {
		
		if(syncMessageList!=null && syncMessageList.getSyncMessageList()!=null && syncMessageList.getSyncMessageList().size() > 0) {
			
			SyncMessage last = syncMessageList.getSyncMessageList().get(syncMessageList.getSyncMessageList().size() - 1);
			//从这个点开始读
			SyncSocketClient.tid = last.getTid() + 1; 
			//删除到这个点
			SyncSocketClient.savedTid = last.getTid();  
			
			SyncMessage syncMessage = null;
			
			for(SyncMessage item: syncMessageList.getSyncMessageList()) {
				if(item.getAccount()!=null) {
					CacheUtil.accountQueue.offer(item.getAccount());
				}else if(item.getOrder()!=null) {
										
					CacheUtil.orderByUserQueue.offer(item.getOrder());
					CacheUtil.orderByPairQueue.offer(item.getOrder());
					if(item.getOrder().getUserType() == UserTypeEnum.NORMAL.getType()) {
						CacheUtil.orderHistoryQueue.offer(item.getOrder());
						
						if(item.getOrder().getCreateTime().getTime() >= CacheUtil.riskStartTime) {
							CacheUtil.orderRiskQueue.offer(item.getOrder());
						}						
					}
					if(item.getOrder().getOrderMode() > OrderModeEnum.NORMAL.getMode()) {
						CacheUtil.orderModeQueue.offer(item.getOrder());
					}
					if(OrderTypeEnum.MARKET.getType()!=item.getOrder().getOrderType() && OrderStateEnum.PENDING.getState()!=item.getOrder().getOrderState()) {
						CacheUtil.orderSpecialQueue.offer(item.getOrder());
					}
				}else if(item.getDepthMessage()!=null) {
					if(OrderSideEnum.BUY.getSide() == item.getDepthMessage().getOrderSide()) {
						CacheUtil.buyDepthQueue.offer(item.getDepthMessage());
					}else {
						CacheUtil.sellDepthQueue.offer(item.getDepthMessage());
					}
					
				}else if(item.getCoin()!=null) {
					CacheUtil.coinMap.put(item.getCoin().getId(), item.getCoin());
				}else if(item.getUser()!=null) {
					CacheUtil.userMap.put(item.getUser().getId(), item.getUser());
				}else if(item.getPair()!=null) {
					CacheUtil.pairMap.put(item.getPair().getPairName(), item.getPair());
					//交易对变更通知推送系统
					if(CacheUtil.pushQueueMap.size() > 0) {
						syncMessage = SyncMessage.createSyncMessage(item.getPair());
						for(ConcurrentLinkedQueue<SyncMessage> queue :CacheUtil.pushQueueMap.values()) {
							queue.offer(syncMessage);
						}
					}
				}else if(item.getTrade()!=null) {
					
					CacheUtil.tradeQueue.offer(item.getTrade());
				}else if(item.getStatus() == SocketStateEnum.RELOAD.getState() && !SyncSocketClient.PULL_DATA_ALL) {			
					reload();
					
					//一旦收到核心重启，所有数据需要刷新，当前收到的消息包里其它消息也需要丢弃
					break;
				}
			}			
		}		
	}
	
	@Override
	public void syncAccount() {
		
		accountPendingMap.clear();		
		
		Account account;
		while((account = CacheUtil.accountQueue.poll())!=null) {

			accountPendingMap.put(account.getId(), account);
			
			if(accountPendingMap.size() >= BATCH_SIZE) {
				break;
			}
		}
		
		for(Account item: accountPendingMap.values()) {
			Map<Integer, Account> map = CacheUtil.accountMap.get(item.getUserId());
			
			if(map == null) {
				map = new ConcurrentHashMap<Integer, Account>(Constants.COLLECTION_DEFAULT_SIZE);
				CacheUtil.accountMap.put(item.getUserId(), map);
			}
			
			map.put(item.getCoinId(), item);
		}
		
	}
	
	@Override
	public void processOrderNonQuantized(Order order) {
		ArrayListEx<Order> list = CacheUtil.orderAllMapByUserNonQuantized.get(order.getUserId());
		
		if(list == null) {
			//ArrayListEx默认块是1万，给个值 10这样可以防止用户数很多的时候，内存爆满
			list = new ArrayListEx<Order>(Constants.COLLECTION_DEFAULT_SIZE);
			CacheUtil.orderAllMapByUserNonQuantized.put(order.getUserId(), list);
		}		
			
		synchronized(list) {
			OrderBookByUserUtil.processUpdateOrderBook(list, order);		
			
			//个人用户的list要非常小心，只扩张不回收会导致内存耗尽
			list.trimToSize();
		}
		
	}
	
	/**降频专用**/
	private Map<Long, Order> orderByUserPendingMap = new ConcurrentHashMap<Long, Order>(10000);	
	
	@Override
	public void syncByUserOrder() {
		orderByUserPendingMap.clear();		
		
		Order order;
		while((order = CacheUtil.orderByUserQueue.poll())!=null) {

			orderByUserPendingMap.put(order.getId(), order);
			
			if(orderByUserPendingMap.size() >= BATCH_SIZE) {
				break;
			}
		}
		
		
		
		for(Order item: orderByUserPendingMap.values()) {
			
			ArrayListEx<Order> orderList = CacheUtil.orderCurrentMapByUser.get(item.getUserId());
			
			if(orderList == null) {
				//ArrayListEx默认块是1万，给个值10这样可以防止用户数很多的时候，内存爆满
				orderList = new ArrayListEx<Order>(Constants.COLLECTION_DEFAULT_SIZE);
				CacheUtil.orderCurrentMapByUser.put(item.getUserId(), orderList);
			}
			
			if(OrderStateEnum.NEW.getState() == item.getOrderState() || OrderStateEnum.PARTIALLY_FILLED.getState() == item.getOrderState() || OrderStateEnum.PENDING.getState() == item.getOrderState()) {
				OrderBookByUserUtil.processUpdateOrderBook(orderList, item);	
			}else {
				OrderBookByUserUtil.removeOrderBook(orderList, item);
			}
			
			//个人用户的list要非常小心，只扩张不回收会导致内存耗尽
			orderList.trimToSize();
				
			
		}
	}
	
	
	/**降频专用**/
	private Map<Long, Order> orderHisotryPendingMap = new ConcurrentHashMap<Long, Order>(10000);	
	
	@Override
	public void syncHistoryOrder() {
		orderHisotryPendingMap.clear();		
		
		Order order;
		while((order = CacheUtil.orderHistoryQueue.poll())!=null) {

			orderHisotryPendingMap.put(order.getId(), order);
			
			if(orderHisotryPendingMap.size() >= BATCH_SIZE) {
				break;
			}
		}		
		
		for(Order item: orderHisotryPendingMap.values()) {
			
			processOrderNonQuantized(item);	
		}
	}
	
	
	/**降频专用**/
	private Map<Long, Order> orderByPairPendingMap = new ConcurrentHashMap<Long, Order>(10000);	
	
	@Override
	public void syncByPairOrder() {
		orderByPairPendingMap.clear();		
		
		Order order;
		while((order = CacheUtil.orderByPairQueue.poll())!=null) {

			orderByPairPendingMap.put(order.getId(), order);
			
			if(orderByPairPendingMap.size() >= BATCH_SIZE) {
				break;
			}
		}		
		
		SyncMessage syncMessage = null;
		
		for(Order item: orderByPairPendingMap.values()) {
			
			ArrayListEx<Order> orderList = CacheUtil.orderCurrentMapByPair.get(item.getPairName());
			
			if(orderList == null) {
				orderList = new ArrayListEx<Order>();
				CacheUtil.orderCurrentMapByPair.put(item.getPairName(), orderList);
			}
			
			if(OrderStateEnum.NEW.getState() == item.getOrderState() || OrderStateEnum.PARTIALLY_FILLED.getState() == item.getOrderState() || OrderStateEnum.PENDING.getState() == item.getOrderState()) {
				OrderBookByUserUtil.processUpdateOrderBook(orderList, item);	
				CacheUtil.orderCurrentAllMap.put(item.getId(), item);
			}else {
				OrderBookByUserUtil.removeOrderBook(orderList, item);
				CacheUtil.orderCurrentAllMap.remove(item.getId());
			}
				
			
			//通知push 服务的订单变更
			if(CacheUtil.pushQueueMap.size() > 0) {
				syncMessage = SyncMessage.createSyncMessage(item);
				for(ConcurrentLinkedQueue<SyncMessage> queue :CacheUtil.pushQueueMap.values()) {
					queue.offer(syncMessage);
				}
			}
		}
	}
	
	private List<DepthMessage> aggregateDepth(List<DepthMessage> list, int digits){
		
		List<DepthMessage> result = new ArrayList<DepthMessage>(100);
		
		DepthMessage first = list.get(0);
		DepthMessage depthMessage = new DepthMessage(first.getPairName(), first.getOrderSide(), first.getPrice().setScale(digits, BigDecimal.ROUND_DOWN), first.getQty());
		
		for(int i=1;i<list.size();i++) {
			DepthMessage item = list.get(i);
			
			BigDecimal price = item.getPrice().setScale(digits, BigDecimal.ROUND_DOWN);
			
			if(price.compareTo(depthMessage.getPrice()) == 0) {
				depthMessage.setQty(depthMessage.getQty().add(item.getQty()));
			}else {
				result.add(depthMessage);
				
				depthMessage = new DepthMessage(item.getPairName(), item.getOrderSide(), item.getPrice().setScale(digits, BigDecimal.ROUND_DOWN), item.getQty());				
			}			
		}
		
		result.add(depthMessage);
		
		return result;
	}
	
	/***
	 * 只有当前pairname有depth变量的时候，重新生成depth
	 */	
	@Override
	public void syncBuyDepth() {
		
		buyDepthPendingMap.clear();		
		
		DepthMessage depthMessage;
		int count = 0;
		while((depthMessage = CacheUtil.buyDepthQueue.poll())!=null) {
			
			Map<BigDecimal,DepthMessage> map = buyDepthPendingMap.get(depthMessage.getPairName());
			
			if(map==null) {
				map = new LinkedHashMap<BigDecimal,DepthMessage>();
				buyDepthPendingMap.put(depthMessage.getPairName(), map);
			}

			map.put(depthMessage.getPrice(), depthMessage);
			
			count ++;
			if(count >= BATCH_SIZE) {
				break;
			}
		}
		
		SyncMessage syncMessage = null;
		
		for(Entry<String, Map<BigDecimal,DepthMessage>> entry: buyDepthPendingMap.entrySet()) {
			
			ArrayListEx<DepthMessage> depthList = CacheUtil.buyDepthMap.get(entry.getKey());
			
			if(depthList == null) {
				depthList = new ArrayListEx<DepthMessage>();
				CacheUtil.buyDepthMap.put(entry.getKey(), depthList);
			}
			
			for(DepthMessage item: entry.getValue().values()) {
				DepthUtil.processBuyDepth(depthList, item);
				
				//维push 服务的订单变更
				if(CacheUtil.pushQueueMap.size() > 0) {
					syncMessage = SyncMessage.createSyncMessage(item);
					for(ConcurrentLinkedQueue<SyncMessage> queue :CacheUtil.pushQueueMap.values()) {
						queue.offer(syncMessage);
					}
				}
			}
			
			List<DepthMessage> depthListSnapshot = new ArrayList<DepthMessage>(1000);
			for(int i=0;i<Math.min(depthList.size(), config.getDepthSnapshotMaxSize()); i++) {
				depthListSnapshot.add(depthList.get(i));
			}
			
			//直接替换，如果有客户端指向 老的引用，那么返回的depth是上一期的depth,对业务上几乎无影响
			Map<Integer,List<DepthMessage>> map = CacheUtil.buyDepthMapSnapshot.get(entry.getKey());
					
			if(map==null) {
				map = new ConcurrentHashMap<Integer,List<DepthMessage>>(Constants.COLLECTION_DEFAULT_SIZE);
				CacheUtil.buyDepthMapSnapshot.put(entry.getKey(), map);	
			}
				
			if(depthListSnapshot.size() == 0) {
				for(int i=1;i<=Constants.DECIMAL_DEFAULT_SCALE;i++) {
					map.put(i, depthListSnapshot);
				}
				continue;
			}
			
			map.put(8, depthListSnapshot);
			
			for(int i=1;i<Constants.DECIMAL_DEFAULT_SCALE;i++) {
				map.put(i, aggregateDepth(depthListSnapshot, i));
			}			
		}
		
	}

	@Override
	public void syncSellDepth() {
		
		sellDepthPendingMap.clear();		
		
		DepthMessage depthMessage;
		int count = 0;
		while((depthMessage = CacheUtil.sellDepthQueue.poll())!=null) {
			
			Map<BigDecimal,DepthMessage> map = sellDepthPendingMap.get(depthMessage.getPairName());
			
			if(map==null) {
				map = new LinkedHashMap<BigDecimal,DepthMessage>();
				sellDepthPendingMap.put(depthMessage.getPairName(), map);

			}

			map.put(depthMessage.getPrice(), depthMessage);
			
			count ++;
			if(count >= BATCH_SIZE) {
				break;
			}
		}
		
		SyncMessage syncMessage = null;
		
		for(Entry<String, Map<BigDecimal,DepthMessage>> entry: sellDepthPendingMap.entrySet()) {
			
			ArrayListEx<DepthMessage> depthList = CacheUtil.sellDepthMap.get(entry.getKey());
			
			if(depthList == null) {
				depthList = new ArrayListEx<DepthMessage>();
				CacheUtil.sellDepthMap.put(entry.getKey(), depthList);
			}
			
			for(DepthMessage item: entry.getValue().values()) {
				DepthUtil.processSellDepth(depthList, item);
				
				//维push 服务的订单变更
				if(CacheUtil.pushQueueMap.size() > 0) {
					syncMessage = SyncMessage.createSyncMessage(item);
					for(ConcurrentLinkedQueue<SyncMessage> queue :CacheUtil.pushQueueMap.values()) {
						queue.offer(syncMessage);
					}
				}
			}
			
			List<DepthMessage> depthListSnapshot = new ArrayList<DepthMessage>(1000);
			for(int i=0;i<Math.min(depthList.size(), config.getDepthSnapshotMaxSize()); i++) {
				depthListSnapshot.add(depthList.get(i));
			}
			
			//直接替换，如果有客户端指向 老的引用，那么返回的depth是上一期的depth,对业务上几乎无影响			
			Map<Integer,List<DepthMessage>> map = CacheUtil.sellDepthMapSnapshot.get(entry.getKey());
			
			if(map==null) {
				map = new ConcurrentHashMap<Integer,List<DepthMessage>>(Constants.COLLECTION_DEFAULT_SIZE);
				CacheUtil.sellDepthMapSnapshot.put(entry.getKey(), map);	
			}
				
			if(depthListSnapshot.size() == 0) {
				for(int i=1;i<=Constants.DECIMAL_DEFAULT_SCALE;i++) {
					map.put(i, depthListSnapshot);
				}
				continue;
			}
			
			map.put(8, depthListSnapshot);
			
			for(int i=1;i<Constants.DECIMAL_DEFAULT_SCALE;i++) {
				map.put(i, aggregateDepth(depthListSnapshot, i));
			}	
		}
		
	}
	
	@Override
	public void processTradeNonQuantized(Trade trade) {
		
		//买卖是同一人，只存一条进去 
		if(UserTypeEnum.isSmallUser(trade.getBuyerUserType())) {
			//只存非量化帐户
			ArrayListEx<Trade> buyerTradeList = CacheUtil.tradeAllMapByUserNonQuantized.get(trade.getBuyerId());
			if(buyerTradeList==null) {
				//ArrayListEx默认块是1万，给个值 10这样可以防止用户数很多的时候，内存爆满
				buyerTradeList = new ArrayListEx<Trade>(Constants.COLLECTION_DEFAULT_SIZE);
				CacheUtil.tradeAllMapByUserNonQuantized.put(trade.getBuyerId(), buyerTradeList);
			}
			
			synchronized(buyerTradeList) {
				
				TradeUtil.processAddTrade(buyerTradeList, trade);
				
				//个人用户的list要非常小心，只扩张不回收会导致内存耗尽
				buyerTradeList.trimToSize();
			}

		}
		//只存非量化帐户
		if(trade.getBuyerId()!= trade.getSellerId() && UserTypeEnum.isSmallUser(trade.getSellerUserType())) {
			ArrayListEx<Trade> sellerTradeList = CacheUtil.tradeAllMapByUserNonQuantized.get(trade.getSellerId());
			if(sellerTradeList==null) {
				//ArrayListEx默认块是1万，给个值 10这样可以防止用户数很多的时候，内存爆满
				sellerTradeList = new ArrayListEx<Trade>(Constants.COLLECTION_DEFAULT_SIZE);
				CacheUtil.tradeAllMapByUserNonQuantized.put(trade.getSellerId(), sellerTradeList);
			}
			
			synchronized(sellerTradeList) {
				
				TradeUtil.processAddTrade(sellerTradeList, trade);
				
				//个人用户的list要非常小心，只扩张不回收会导致内存耗尽
				sellerTradeList.trimToSize();
			}
		}
	}
	
	@Override
	public void syncTrade() {
		
		Trade trade;
		int count = 0;
		while((trade = CacheUtil.tradeQueue.poll())!=null) {
						
			processTradeNonQuantized(trade);
			
			count++;
			if(count >= BATCH_SIZE) {
				break;
			}
		}
	}
	
	
	/**降频专用**/
	private Map<Long, Order> orderModePendingMap = new LinkedHashMap<Long, Order>(10000);	
	
	@Override
	public void syncOrderMode() {
		orderModePendingMap.clear();		
		
		Order order;
		while((order = CacheUtil.orderModeQueue.poll())!=null) {

			orderModePendingMap.put(order.getId(), order);
			
			if(orderModePendingMap.size() >= BATCH_SIZE) {
				break;
			}
		}	
		
		for(Order item: orderModePendingMap.values()) {
			
			if(item.getOrderMode() == OrderModeEnum.TRAILING_STOP_LOSS.getMode()) {
				
				if(item.getOrderSide() == OrderSideEnum.SELL.getSide()) {
					ArrayListEx<Order> orderList = CacheUtil.orderModeSellTrailingStopLoss.get(item.getPairName());
					
					if(orderList == null) {
						orderList = new ArrayListEx<Order>();
						CacheUtil.orderModeSellTrailingStopLoss.put(item.getPairName(), orderList);
					}
					
					if(item.getOrderState() == OrderStateEnum.PENDING.getState()) {
						OrderModeUtil.processUpOrderBook(orderList, item);
					}else {
						OrderModeUtil.removeUpOrderBook(orderList, item);
					}
				}else {
					ArrayListEx<Order> orderList = CacheUtil.orderModeBuyTrailingStopLoss.get(item.getPairName());
					
					if(orderList == null) {
						orderList = new ArrayListEx<Order>();
						CacheUtil.orderModeBuyTrailingStopLoss.put(item.getPairName(), orderList);
					}
					
					if(item.getOrderState() == OrderStateEnum.PENDING.getState()) {
						OrderModeUtil.processDownOrderBook(orderList, item);
					}else {
						OrderModeUtil.removeDownOrderBook(orderList, item);
					}
				}
			}
			
			
			else if(item.getOrderMode() == OrderModeEnum.STOP_LOSS.getMode()) {
				
				if(item.getOrderSide() == OrderSideEnum.BUY.getSide()) {
					ArrayListEx<Order> orderList = CacheUtil.orderModeBuyStopLoss.get(item.getPairName());
					
					if(orderList == null) {
						orderList = new ArrayListEx<Order>();
						CacheUtil.orderModeBuyStopLoss.put(item.getPairName(), orderList);
					}
					
					if(item.getOrderState() == OrderStateEnum.PENDING.getState()) {
						OrderModeUtil.processUpOrderBook(orderList, item);
					}else {
						OrderModeUtil.removeUpOrderBook(orderList, item);
					}
				}else {
					ArrayListEx<Order> orderList = CacheUtil.orderModeSellStopLoss.get(item.getPairName());
					
					if(orderList == null) {
						orderList = new ArrayListEx<Order>();
						CacheUtil.orderModeSellStopLoss.put(item.getPairName(), orderList);
					}
					
					if(item.getOrderState() == OrderStateEnum.PENDING.getState()) {						
						OrderModeUtil.processDownOrderBook(orderList, item);
					}else {
						OrderModeUtil.removeDownOrderBook(orderList, item);
					}
				}
				
			}
			
			
			else if(item.getOrderMode() == OrderModeEnum.STOP_WIN.getMode()) {
				
				if(item.getOrderSide() == OrderSideEnum.SELL.getSide()) {
					ArrayListEx<Order> orderList = CacheUtil.orderModeSellStopWin.get(item.getPairName());
					
					if(orderList == null) {
						orderList = new ArrayListEx<Order>();
						CacheUtil.orderModeSellStopWin.put(item.getPairName(), orderList);
					}
					
					if(item.getOrderState() == OrderStateEnum.PENDING.getState()) {
						OrderModeUtil.processUpOrderBook(orderList, item);
					}else {
						OrderModeUtil.removeUpOrderBook(orderList, item);
					}
				}else {
					ArrayListEx<Order> orderList = CacheUtil.orderModeBuyStopWin.get(item.getPairName());
					
					if(orderList == null) {
						orderList = new ArrayListEx<Order>();
						CacheUtil.orderModeBuyStopWin.put(item.getPairName(), orderList);
					}
					
					if(item.getOrderState() == OrderStateEnum.PENDING.getState()) {
						OrderModeUtil.processDownOrderBook(orderList, item);
					}else {
						OrderModeUtil.removeDownOrderBook(orderList, item);
					}
				}				
				
			}			
			
		}
	}

	@Override
	public void doCleanOrder() {
		
		Date date = DateUtils.addHours(new Date(), 0 - config.getHistoryHours());
		
		List<Integer> toBeRemovedList = new ArrayList<Integer>(100);
		
		for(ArrayListEx<Order> item: CacheUtil.orderAllMapByUserNonQuantized.values()) {
			
			toBeRemovedList.clear();
			
			synchronized(item) {
				
				for(int i=0;i<item.size();i++) {
					Order order = item.get(i);
					if(order.getCreateTime().compareTo(date) < 0) {
						toBeRemovedList.add(i);
					}else {
						break;
					}
				}
				
				if(toBeRemovedList.size() > 0) {
					for(int i=toBeRemovedList.size()-1;i>=0;i--) {
						item.remove(toBeRemovedList.get(i));
					}
				}
				
				if(item.size() > config.getHistorySize()) {
					for(int i=item.size() - config.getHistorySize() -1;i>=0;i--) {
						item.remove(i);
					}
				}
				
			}
		}		
		
	}
	
	
	@Override
	public void doCleanTrade() {
		
		Date date = DateUtils.addHours(new Date(), 0 - config.getHistoryHours());
		
		List<Integer> toBeRemovedList = new ArrayList<Integer>(100);
		
				
		for(ArrayListEx<Trade> item: CacheUtil.tradeAllMapByUserNonQuantized.values()) {
			
			toBeRemovedList.clear();
			
			synchronized(item) {
				
				for(int i=0;i<item.size();i++) {
					Trade trade = item.get(i);
					if(trade.getCreateTime().compareTo(date) < 0) {
						toBeRemovedList.add(i);
					}else {
						break;
					}
				}
				
				if(toBeRemovedList.size() > 0) {
					for(int i=toBeRemovedList.size()-1;i>=0;i--) {
						item.remove(toBeRemovedList.get(i));
					}
				}				
				
				if(item.size() > config.getHistorySize()) {
					for(int i=item.size() - config.getHistorySize() -1;i>=0;i--) {
						item.remove(i);
					}
				}
			}
		}
	}
}
