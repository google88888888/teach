package mn.idax.data.query.service;

/**
 * @author zhouou 214108525@qq.com
 *
 * 2018年12月7日
 */
public interface QueryService {


	/**
	 *  请求对象封装成一个批次
	 */
	void doProcess();
	
}
