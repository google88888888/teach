package mn.idax.data.service;

/**
 * @author zhouou 214108525@qq.com
 *
 * 2019年5月24日
 */
public interface RiskService {
	
	/**处理风控逻辑
	 * 
	 */
	void doProcess();

}
