package mn.idax.data.util;

import mn.idax.common.entity.Trade;
import mn.idax.common.util.ArrayListEx;

/**
 * @author zhouou 214108525@qq.com
 *
 * 2018年11月12日
 * 
 * 买  价高->价低    同价 按时间排 序
 * 卖  价低->价高   同价 按时间排 序 
 * 
 */
public class TradeUtil {	
	
	
	private static boolean processHalf(ArrayListEx<Trade> list, Trade trade, int index) {
		
		if(list.get(index).getId() == trade.getId()) {
			list.set(index, trade);
			return true;
		}

        if (index > 0) {
            if (trade.getId() > list.get(index - 1).getId() && trade.getId() < list.get(index).getId()) {
                list.add(index, trade);
                return true;
            }
        }

        if (index < list.size() - 1) {
            if (trade.getId() > list.get(index).getId() && trade.getId() < list.get(index + 1).getId()) {
                list.add(index + 1, trade);
                return true;
            }
        }

        return false;
    }
	
	public static void processAddTrade(ArrayListEx<Trade> list, Trade trade) {
		
		
		//判断 0个或1个
        if (list.size() == 0) {
            list.add(trade);
            return;
        } else if (list.size() == 1) {
        	if(trade.getId() == list.get(0).getId()) {
        		list.set(0, trade);
        	}else if (trade.getId() >  list.get(0).getId()) {
            	list.add(trade);            	
            } else {
            	list.add(0, trade);
            }
            return;
        }

        //存在2条以上数据

        //判断是否头尾插入或修改
        if (trade.getId() == list.get(0).getId()) {
        	list.set(0, trade);   
        	return;
        }else if (trade.getId() < list.get(0).getId()) {
        	list.add(0, trade);   
        	return;
        }        
       
        if (trade.getId() == list.get(list.size() - 1).getId()) {
        	list.set(list.size() - 1, trade);   
        	return;
        }else if (trade.getId() > list.get(list.size() - 1).getId()) {
            list.add(trade);
            return;
        }


        int index1 = 0, index2 = list.size() - 1;

        //二分法查找
        while (true) {
            int index = index1 + (index2 - index1) / 2;

            boolean success = processHalf(list, trade, index);
          //已找到并修改
            if (success) {
                return;
            } else if (trade.getId() < list.get(index).getId()) {
                index2 = index;
            } else {
                index1 = index;
            }
        }
        
	}
	
}
