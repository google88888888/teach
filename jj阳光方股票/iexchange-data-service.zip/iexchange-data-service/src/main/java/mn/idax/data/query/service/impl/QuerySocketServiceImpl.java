package mn.idax.data.query.service.impl;

import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ConcurrentLinkedQueue;

import io.protostuff.LinkedBuffer;
import mn.idax.common.constant.AppStateEnum;
import mn.idax.common.request.SocketRequest;
import mn.idax.common.query.response.QueryResponse;
import mn.idax.common.query.response.QueryResponseItem;
import mn.idax.common.util.ArrayListBlock;
import mn.idax.common.util.ByteBufferEx;
import mn.idax.common.util.CommonUtil;
import mn.idax.data.query.service.QuerySocketService;
import mn.idax.data.util.CacheUtil;

/**
 * @author zhouou 214108525@qq.com
 *
 * 2018年12月6日
 */
public class QuerySocketServiceImpl implements QuerySocketService{

	
	private static final int BATCH_SIZE  = 10000;	
	
	
	private ConcurrentLinkedQueue<QueryResponseItem> socketResultQueue = null;
	private ArrayListBlock<QueryResponseItem> arrayListBlock = null;
	
	public QuerySocketServiceImpl(String serverId) {
		
		ConcurrentLinkedQueue<QueryResponseItem> socketResultQueue = CacheUtil.forwardSocketResponseMap.get(serverId);		
		if(socketResultQueue == null) {
			socketResultQueue  = new ConcurrentLinkedQueue<QueryResponseItem>();
		
			ConcurrentLinkedQueue<QueryResponseItem> exist = CacheUtil.forwardSocketResponseMap.putIfAbsent(serverId, socketResultQueue);
			if(exist!=null) {
				socketResultQueue = exist;
			}
		}
		
		this.socketResultQueue = socketResultQueue;
		
		
		
		ArrayListBlock<QueryResponseItem> arrayListBlock = CacheUtil.forwardSocketResponseListMap.get(serverId);		
		if(arrayListBlock == null) {
			arrayListBlock  = new ArrayListBlock<QueryResponseItem>();
		
			ArrayListBlock<QueryResponseItem> exist = CacheUtil.forwardSocketResponseListMap.putIfAbsent(serverId, arrayListBlock);
			if(exist!=null) {
				arrayListBlock = exist;
			}
		}
		
		this.arrayListBlock = arrayListBlock;
	}
	
	/**删除内存 等过期 数据**/
	private void trimCache(ConcurrentLinkedQueue<QueryResponseItem> socketResultQueue, long tid) {
		
		QueryResponseItem queryResponseItem = null;
		
		while((queryResponseItem = arrayListBlock.getBlockLastItem(0))!=null) {
			if(queryResponseItem.getTid() <= tid) {
				arrayListBlock.removeFirstBlock();
			}else {
				break;
			}			
		}
		
	}
	
	private void extractQueryResponseItem(ConcurrentLinkedQueue<QueryResponseItem> socketResultQueue, long tid) {
		
		QueryResponseItem queryResponseItem = null;
		int count = 0;
		while((queryResponseItem = socketResultQueue.poll()) != null) {
			
			queryResponseItem.setTid(CommonUtil.getGuid());
			
			arrayListBlock.add(queryResponseItem);
			count ++;
			
			if(count >= BATCH_SIZE) {
				break;
			}	
		}	

		for(int i=0;i<arrayListBlock.size();i++) {
			queryResponseItem = arrayListBlock.get(i);
			
			if(queryResponseItem.getTid() >= tid) {
				queryResponseItemList.add(queryResponseItem);
				
				if(queryResponseItemList.size() >= BATCH_SIZE) {
					break;
				}
			}	
		}
		
	}
	
	private byte[] buffer = new byte[64 * 1024];
	private ByteBufferEx byteBuffer = new ByteBufferEx();
	
	private ByteBuffer byteLenBuffer = ByteBuffer.allocate(4);
	private List<QueryResponseItem> queryResponseItemList = new ArrayList<QueryResponseItem>(BATCH_SIZE);
	private LinkedBuffer queryResponseBuffer = LinkedBuffer.allocate(100 * 1024 * 1024);
	
	private void send(SocketRequest socketRequest, OutputStream outputStream) throws Exception{
		
		byte[] content = null;
		
		if(socketRequest != null) {
			
			queryResponseItemList.clear();
			
			if(socketRequest.getQueryRequest()!=null && socketRequest.getQueryRequest().getQueryRequestItemList()!=null) {
				CacheUtil.addRequestSocket(socketRequest.getServerId(), socketRequest.getQueryRequest());
			}
			
			
			
			if(socketRequest.getSavedTid() >0 ) {
				trimCache(socketResultQueue, socketRequest.getSavedTid());
			}
			
			if(socketRequest.getTid() >=0) {
				extractQueryResponseItem(socketResultQueue, socketRequest.getTid());
			}
			
			if(queryResponseItemList.size()>0) {
				QueryResponse queryResponse = new QueryResponse();
				queryResponse.setQueryResponseItemList(queryResponseItemList);
				
				content  = CommonUtil.encodeQueryResponse(queryResponse, queryResponseBuffer);
				
			}
			
		}
		
		byteLenBuffer.clear();
		if(content!=null) {
			outputStream.write(byteLenBuffer.putInt(content.length).array());
			outputStream.write(content);
		}else {
			outputStream.write(byteLenBuffer.putInt(0).array());
		}
		
		outputStream.flush();	  
		
	}
	
	@Override
	public void doProcess(Socket socket, InputStream inputStream, OutputStream outputStream) throws Exception{
		
		int readCount = 0;
		int msgLength = 0;
						
		while(!AppStateEnum.SHUTTING_DOWN.equals(CacheUtil.dataServiceState) && (readCount = inputStream.read(buffer))!=-1) {
			
			if(msgLength == 0) {
				
				msgLength =  ByteBuffer.wrap(buffer, 0, 4).getInt();						
				
				if(msgLength > 0) {
					byteBuffer.allocate(msgLength);
					byteBuffer.put(buffer, 4, readCount - 4);
				}else {
					throw new RuntimeException("Request invalid");
				}
			}else {
				byteBuffer.put(buffer, 0, readCount);
			}
			
			if(msgLength < byteBuffer.size()) {				
				throw new RuntimeException("msgLength < byteBuffer.size()");
			}else if(msgLength > 0 && msgLength == byteBuffer.size()) {
				
				SocketRequest socketRequest = CommonUtil.decodeSocketRequest(byteBuffer.getBuffer(), 0, msgLength);
				
				msgLength = 0;
				byteBuffer.clear();
				
				send(socketRequest, outputStream);
			}					
			
		}
	}	
	
}
