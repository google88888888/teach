package mn.idax.data.service.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSON;

import mn.idax.common.bean.RiskEvent;
import mn.idax.data.bean.RiskControlProperty;
import mn.idax.data.service.RedisService;
import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPool;

/**
 * @author zhouou 214108525@qq.com
 *
 * 2019年5月27日
 */
@Service
public class RedisServiceImpl implements RedisService{

	private static final Logger logger = LoggerFactory.getLogger(RedisServiceImpl.class);

	@Autowired
	@Qualifier("jedisPool")
	private JedisPool jedisPool;
	
	
	private static final String EVENT_KEY = "Core:Risk:Event";
	
	private static final String CONFIG_KEY = "Core:Risk:Config";
	
	@Override
	public void publishRiskEvent(RiskEvent event) {
		
		Jedis jedis = null;
        try {
            jedis = jedisPool.getResource();
            
            if (jedis == null) {
                throw new RuntimeException("Redis connect failed!");
            }
            
            jedis.publish(EVENT_KEY, JSON.toJSONString(event));
            
        } catch (Exception ex) {
        	logger.error("IEXCHANGE-REDIS-ERROR {}", ex);
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        } 
	}
	
	@Override
	public RiskControlProperty getRiskControlProperty(){

		RiskControlProperty riskControlProperty = null;

		Jedis jedis = null;
		try {
			jedis = jedisPool.getResource();

			if(jedis==null) {
				throw new RuntimeException("Redis connect failed!");
			}


			String value = jedis.get(CONFIG_KEY);

			if(value!=null) {
				riskControlProperty = JSON.parseObject(value, RiskControlProperty.class);
			}

		}catch(Exception ex){
			logger.error("IEXCHANGE-REDIS-ERROR {}", ex);
		}finally {
			if(jedis!=null) {
				jedis.close();
			}
		}

		return riskControlProperty;

	}
	
}
