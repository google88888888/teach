package mn.idax.data.service;

import mn.idax.common.bean.SyncMessageList;
import mn.idax.common.entity.Order;
import mn.idax.common.entity.Trade;

/**
 * @author zhouou 214108525@qq.com
 *
 * 2018年11月16日
 */
public interface SyncService {

	/**
	 * 主处理方法
	 * @param syncMessageList
	 */
	void doProcess(SyncMessageList syncMessageList);

	/**
	 * 同步帐户
	 */
	void syncAccount();

	/**
	 * 同步按用户订单
	 */
	void syncByUserOrder();

	/**
	 * 同步按交易对订单
	 */
	void syncByPairOrder();

	/**
	 * 同步历史订单
	 */
	void syncHistoryOrder();

	/**
	 * 同步买Depth
	 */
	void syncBuyDepth();

	/**
	 * 同步卖Depth
	 */
	void syncSellDepth();

	/**
	 * 同步交易
	 */
	void syncTrade();

	/**
	 * 定时清理
	 */
	void doCleanOrder();
	
	/**
	 * 定时清理
	 */
	void doCleanTrade();

	/**
	 * 非量化24小时数据
	 * @param order
	 */
	void processOrderNonQuantized(Order order);

	/**
	 * 非量化24小时数据
	 * @param trade
	 */
	void processTradeNonQuantized(Trade trade);
	
	/**同步订单委托方式
	 * 
	 */
	void syncOrderMode();
}
