package mn.idax.data.service;

/**
 * @author zhouou 214108525@qq.com
 *
 *         2019年6月24日
 */
public interface SpecialDepthService {

	/**
	 * 处理真实用户深度
	 * 
	 */
	void doProcessOrderBook();

	/**
	 * 处理量化请求
	 * 
	 */
	void doProcessRequest();
}
