package mn.idax.data.util;

import mn.idax.common.bean.DepthMessage;
import mn.idax.common.bean.SyncMessage;
import mn.idax.common.constant.AppStateEnum;
import mn.idax.common.entity.*;
import mn.idax.common.query.request.GetSpecialDepthRequest;
import mn.idax.common.query.request.QueryRequest;
import mn.idax.common.query.request.QueryRequestItem;
import mn.idax.common.query.response.QueryResponseItem;
import mn.idax.common.util.ArrayListBlock;
import mn.idax.common.util.ArrayListEx;
import mn.idax.common.util.CommonUtil;
import mn.idax.data.bean.AsyncRequest;
import mn.idax.data.bean.Config;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;

/**
 * @author zhouou 214108525@qq.com
 * <p>
 * 2018年11月15日
 */
public class CacheUtil {

    private static final Logger logger = LoggerFactory.getLogger(CacheUtil.class);

    public static Config config = null;

    /**
     * 全局健康状态
     **/
    public static volatile AppStateEnum dataServiceState = AppStateEnum.LOADING;


    public static Map<Integer, Coin> coinMap = new ConcurrentHashMap<Integer, Coin>(100);
    public static Map<Integer, User> userMap = new ConcurrentHashMap<Integer, User>(10000);
    public static Map<String, Pair> pairMap = new ConcurrentHashMap<String, Pair>(100);

    public static ConcurrentLinkedQueue<Account> accountQueue = new ConcurrentLinkedQueue<Account>();
    /**
     * userId->(coinId->account)
     **/
    public static Map<Integer, Map<Integer, Account>> accountMap = new ConcurrentHashMap<Integer, Map<Integer, Account>>(10000);


    /**订单模式
     * 
     */
    public static ConcurrentLinkedQueue<Order> orderModeQueue = new ConcurrentLinkedQueue<Order>();
    
    public static ConcurrentLinkedQueue<Order> orderByUserQueue = new ConcurrentLinkedQueue<Order>();
    public static ConcurrentLinkedQueue<Order> orderByPairQueue = new ConcurrentLinkedQueue<Order>();
    public static ConcurrentLinkedQueue<Order> orderHistoryQueue = new ConcurrentLinkedQueue<Order>();
    public static ConcurrentLinkedQueue<Order> orderRiskQueue = new ConcurrentLinkedQueue<Order>();
    public static ConcurrentLinkedQueue<Order> orderSpecialQueue = new ConcurrentLinkedQueue<Order>();
    
    public static long riskStartTime = System.currentTimeMillis();

    /**
     * userId->(orderId->order) 所有未成交订单， 包括 量化和个人
     **/
    public static Map<Integer, ArrayListEx<Order>> orderCurrentMapByUser = new ConcurrentHashMap<Integer, ArrayListEx<Order>>(10000);
    public static Map<String, ArrayListEx<Order>> orderCurrentMapByPair = new ConcurrentHashMap<String, ArrayListEx<Order>>(100);
    public static Map<Long, Order> orderCurrentAllMap = new ConcurrentHashMap<Long, Order>(10000);
    
    
    
    public static Map<String, ArrayListEx<Order>> orderModeBuyStopLoss = new ConcurrentHashMap<String, ArrayListEx<Order>>(100);
    public static Map<String, ArrayListEx<Order>> orderModeBuyStopWin = new ConcurrentHashMap<String, ArrayListEx<Order>>(100);
    
    public static Map<String, ArrayListEx<Order>> orderModeSellStopLoss = new ConcurrentHashMap<String, ArrayListEx<Order>>(100);
    public static Map<String, ArrayListEx<Order>> orderModeSellStopWin = new ConcurrentHashMap<String, ArrayListEx<Order>>(100);

    public static Map<String, ArrayListEx<Order>> orderModeBuyTrailingStopLoss = new ConcurrentHashMap<String, ArrayListEx<Order>>(100);
    public static Map<String, ArrayListEx<Order>> orderModeSellTrailingStopLoss = new ConcurrentHashMap<String, ArrayListEx<Order>>(100);
    
    

    /**
     * 24小时数据 个人所有订单，包括 成交和未成交，不包括 量化
     **/
    public static Map<Integer, ArrayListEx<Order>> orderAllMapByUserNonQuantized = new ConcurrentHashMap<Integer, ArrayListEx<Order>>(10000);

    public static Map<String, ArrayListEx<Order>> specialBuyOrderBook = new ConcurrentHashMap<String, ArrayListEx<Order>>(100);
    public static Map<String, ArrayListEx<Order>> specialSellOrderBook = new ConcurrentHashMap<String, ArrayListEx<Order>>(100);
    
    /**
     * 24小时数据 个人所有交易，不包括量化
     **/
    public static Map<Integer, ArrayListEx<Trade>> tradeAllMapByUserNonQuantized = new ConcurrentHashMap<Integer, ArrayListEx<Trade>>(10000);

    public static ConcurrentLinkedQueue<DepthMessage> buyDepthQueue = new ConcurrentLinkedQueue<DepthMessage>();
    public static Map<String, ArrayListEx<DepthMessage>> buyDepthMap = new ConcurrentHashMap<String, ArrayListEx<DepthMessage>>(100);

    /**
     * 每次更新后， 生成 所有 pair , 1000条镜像
     **/
    public static Map<String, Map<Integer, List<DepthMessage>>> buyDepthMapSnapshot = new ConcurrentHashMap<String, Map<Integer, List<DepthMessage>>>(100);


    public static ConcurrentLinkedQueue<DepthMessage> sellDepthQueue = new ConcurrentLinkedQueue<DepthMessage>();
    public static Map<String, ArrayListEx<DepthMessage>> sellDepthMap = new ConcurrentHashMap<String, ArrayListEx<DepthMessage>>(100);

    /**
     * 每次更新后， 生成 所有 pair , 1000条镜像
     **/
    public static Map<String, Map<Integer, List<DepthMessage>>> sellDepthMapSnapshot = new ConcurrentHashMap<String, Map<Integer, List<DepthMessage>>>(100);


    /**
     * forward server id -> queue
     **/
    public static Map<String, ConcurrentLinkedQueue<QueryResponseItem>> forwardSocketResponseMap = new ConcurrentHashMap<String, ConcurrentLinkedQueue<QueryResponseItem>>();
    /**
     * 用来暂存储从queue出来的数据，因为queue 的iterator太慢了
     **/
    public static Map<String, ArrayListBlock<QueryResponseItem>> forwardSocketResponseListMap = new ConcurrentHashMap<String, ArrayListBlock<QueryResponseItem>>();


    public static ConcurrentLinkedQueue<Trade> tradeQueue = new ConcurrentLinkedQueue<Trade>();

    /**
     * 要推送的消息都放这里
     **/
    public static Map<String, ConcurrentLinkedQueue<SyncMessage>> pushQueueMap = new ConcurrentHashMap<String, ConcurrentLinkedQueue<SyncMessage>>();



    /**
     * 队列，按时间排序, 转移到 businessRequestMap 就删除
     **/
    public static ConcurrentLinkedQueue<AsyncRequest> requestQueue = new ConcurrentLinkedQueue<AsyncRequest>();
    
    public static ConcurrentLinkedQueue<GetSpecialDepthRequest> specialDepthRequestQueue = new ConcurrentLinkedQueue<GetSpecialDepthRequest>();
    
    /**
     * 如果 NioRequest里所有消息都已处理，NIO响应并删除 < 1千万
     **/
    public static Map<Long, AsyncRequest> requestMap = new ConcurrentHashMap<Long, AsyncRequest>(10000);


    private static List<QueryResponseItem> getErrorResponses(List<QueryRequestItem> requestList) {

        List<QueryResponseItem> list = new ArrayList<QueryResponseItem>(requestList.size());

        for (QueryRequestItem item : requestList) {
            list.add(item.generateErrorResponse(item.getGuid(), "system.busy"));
        }

        return list;
    }

    public static void addRequestSocket(String serverId, QueryRequest request) {

        if (request == null || request.getQueryRequestItemList() == null || request.getQueryRequestItemList().size() == 0) {
            return;
        }

        ConcurrentLinkedQueue<QueryResponseItem> socketResultQueue = forwardSocketResponseMap.get(serverId);
        if (socketResultQueue == null) {
            socketResultQueue = new ConcurrentLinkedQueue<QueryResponseItem>();

            ConcurrentLinkedQueue<QueryResponseItem> exist = forwardSocketResponseMap.putIfAbsent(serverId, socketResultQueue);

            if (exist != null) {
                socketResultQueue = exist;
            }
        }

        //限流
        if (!CacheUtil.dataServiceState.equals(AppStateEnum.RUNNING) || requestMap.size() >= config.getMaxQueryRequestSize()) {
            logger.warn("CacheUtil-addRequestSocket-data error:{},{},{}",CacheUtil.dataServiceState,requestMap.size(),config.getMaxQueryRequestSize());
            socketResultQueue.addAll(getErrorResponses(request.getQueryRequestItemList()));
            return;
        }


        AsyncRequest asyncRequest = new AsyncRequest();
        //processExpireNio专用
        asyncRequest.setId(CommonUtil.getGuid());
        asyncRequest.setSocketResultQueue(socketResultQueue);
        asyncRequest.setRequest(request);

        asyncRequest.setQueryResponseItemList(new ArrayList<QueryResponseItem>(request.getQueryRequestItemList().size()));

        asyncRequest.setCreateTime(System.currentTimeMillis());


        for (QueryRequestItem item : request.getQueryRequestItemList()) {
            if (item.getGuid() <= 0) {
            	QueryResponseItem queryResponseItem = item.generateErrorResponse(item.getGuid(),"guid.null");
				asyncRequest.getQueryResponseItemList().add(queryResponseItem);
				socketResultQueue.add(queryResponseItem);
				continue;
            }

            requestMap.put(item.getGuid(), asyncRequest);

        }

        requestQueue.offer(asyncRequest);

    }


    public static void asyncResponse(QueryResponseItem response) {

        AsyncRequest asyncRequest = requestMap.remove(response.getGuid());

        if (asyncRequest == null) {
            return;
        }

        synchronized (asyncRequest) {
            asyncRequest.getQueryResponseItemList().add(response);

            //中转socket连入的，立即返回
            if (asyncRequest.getSocketResultQueue() != null) {
                asyncRequest.getSocketResultQueue().offer(response);
            }
        }

    }
}
