package mn.idax.data.service.impl;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;


import org.apache.commons.lang3.time.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSON;

import mn.idax.common.bean.RiskEvent;
import mn.idax.common.constant.OrderModeEnum;
import mn.idax.common.constant.OrderPropertyEnum;
import mn.idax.common.constant.OrderStateEnum;
import mn.idax.common.entity.Order;
import mn.idax.common.util.LogUtil;
import mn.idax.data.bean.RiskControlProperty;
import mn.idax.data.service.RedisService;
import mn.idax.data.service.RiskService;
import mn.idax.data.util.CacheUtil;

/**
 * @author zhouou 214108525@qq.com
 *
 * 2019年5月24日
 */
@Service
public class RiskServiceImpl implements RiskService{
	
	
	@Autowired
	private RedisService redisService;
	
	private static final int FORBID_CREATE_ORDER = 1;
	//private static final int FORBID_CANCEL_ORDER = 2;
	
	private class Risk{
		
		private int totalCount;
		private int tradeCount;
		
		private int totalPropertyCount;
		private int expiredPropertyCount;
		
		private int cancelCount;
		private int invalidCancelCount;
		
		public int getTotalCount() {
			return totalCount;
		}
		public void setTotalCount(int totalCount) {
			this.totalCount = totalCount;
		}
		public int getTradeCount() {
			return tradeCount;
		}
		public void setTradeCount(int tradeCount) {
			this.tradeCount = tradeCount;
		}
		public int getTotalPropertyCount() {
			return totalPropertyCount;
		}
		public void setTotalPropertyCount(int totalPropertyCount) {
			this.totalPropertyCount = totalPropertyCount;
		}
		
		public int getExpiredPropertyCount() {
			return expiredPropertyCount;
		}
		public void setExpiredPropertyCount(int expiredPropertyCount) {
			this.expiredPropertyCount = expiredPropertyCount;
		}
		public int getCancelCount() {
			return cancelCount;
		}
		public void setCancelCount(int cancelCount) {
			this.cancelCount = cancelCount;
		}
		public int getInvalidCancelCount() {
			return invalidCancelCount;
		}
		public void setInvalidCancelCount(int invalidCancelCount) {
			this.invalidCancelCount = invalidCancelCount;
		}		
		
	}
	
	private class ForbiddenCount{
		
		private long startTime;
		private int count;
		
		public long getStartTime() {
			return startTime;
		}
		public void setStartTime(long startTime) {
			this.startTime = startTime;
		}
		public int getCount() {
			return count;
		}
		public void setCount(int count) {
			this.count = count;
		}
	}
	
	private Map<Integer, Risk> riskMap = new HashMap<Integer, Risk>(1000);
	
	private Map<Integer, ForbiddenCount> forbiddenCountMap = new HashMap<Integer, ForbiddenCount>(10);
	
	private RiskControlProperty riskControlProperty = new RiskControlProperty();
	
	
	private void forbidden(Entry<Integer, Risk> entry) {
		
		ForbiddenCount forbiddenCount = forbiddenCountMap.get(entry.getKey());
		if(forbiddenCount == null) {
			forbiddenCount = new ForbiddenCount();
			forbiddenCount.setStartTime(System.currentTimeMillis());	
			forbiddenCountMap.put(entry.getKey(), forbiddenCount);
		}
		
		forbiddenCount.setCount(forbiddenCount.getCount() + 1);
		
		
		RiskEvent event = new RiskEvent();
		event.setUserId(entry.getKey());
		event.setEmail(CacheUtil.userMap.get(entry.getKey()).getEmail());
		
		if(forbiddenCount.getCount() > riskControlProperty.getForbiddenCountPerDay()) {
			event.setDuration(DateUtils.MILLIS_PER_DAY);
			
			forbiddenCountMap.remove(entry.getKey());
		}else {
			event.setDuration(riskControlProperty.getForbiddenDuration());
		}
		
		event.setEvent(FORBID_CREATE_ORDER);
		redisService.publishRiskEvent(event);
		
		LogUtil.logInfo("RiskServiceImpl-forbidden", 0, JSON.toJSONString(event));
	}
	
	private void checkViolation() {		
		
		float gap = 0f;
		for(Entry<Integer, Risk> entry: riskMap.entrySet()) {
			
			if(entry.getValue().getTotalCount() >= riskControlProperty.getTotalCount()) {
				gap = entry.getValue().getTotalCount() - entry.getValue().getTradeCount();
				if(gap / entry.getValue().getTotalCount() > riskControlProperty.getUfr()) {
					
					forbidden(entry);
					
					LogUtil.logInfo("RiskServiceImpl-checkViolation-UFR", 0, entry.getKey() + JSON.toJSONString(entry.getValue()));
					
					continue;
				}
			}			
			
 				
			if(entry.getValue().getTotalPropertyCount() >= riskControlProperty.getTotalPropertyCount() && entry.getValue().getExpiredPropertyCount() / entry.getValue().getTotalPropertyCount() > riskControlProperty.getIfer()) {
				
				forbidden(entry);
				
				LogUtil.logInfo("RiskServiceImpl-checkViolation-IFER", 0, entry.getKey() + JSON.toJSONString(entry.getValue()));
				
				continue;
			}
		 
			
			if(entry.getValue().getCancelCount() >= riskControlProperty.getCancelCount() && entry.getValue().getInvalidCancelCount() / entry.getValue().getCancelCount() > riskControlProperty.getGcr()) {
				
				forbidden(entry);
				
				LogUtil.logInfo("RiskServiceImpl-checkViolation-GCR", 0, entry.getKey() + JSON.toJSONString(entry.getValue()));
				
				continue;
			}
		}
		
		riskMap.clear();
		
		//开始新周期
		CacheUtil.riskStartTime = System.currentTimeMillis();
	}
	
	
	/**24小时禁用次数 > 10次， 禁用 24小时， 此方法判断 24小时内如果违规不超过10次，清除
	 * 
	 */
	private void checkExpire() {
		
		Iterator<Entry<Integer, ForbiddenCount>> iterator = forbiddenCountMap.entrySet().iterator();
		
		while(iterator.hasNext()) {
			Entry<Integer, ForbiddenCount> entry = iterator.next();			
						
			if(System.currentTimeMillis() - entry.getValue().getStartTime() >= DateUtils.MILLIS_PER_DAY) {
				iterator.remove();		
				
				LogUtil.logInfo("RiskServiceImpl-checkExpire", 0, String.valueOf(entry.getKey()));
			}
		}
		
	}
	
	private long count = 0;
	
	@Override
	public void doProcess() {
		
		if(count % 20 == 0) {
			RiskControlProperty riskControlPropertyT = redisService.getRiskControlProperty();
    		if(riskControlPropertyT!=null) {
    			riskControlProperty = riskControlPropertyT;
    		}
		}		
		count ++;
		
		
		
		Order order;
		while((order = CacheUtil.orderRiskQueue.poll())!=null) {
			
			Risk risk = riskMap.get(order.getUserId());
			if(risk == null) {
				risk = new Risk();
				riskMap.put(order.getUserId(), risk);
			}
			
			if(order.getOrderState() == OrderStateEnum.PENDING.getState()){
				risk.setTotalCount(risk.getTotalCount() + 1);				
			}else if(order.getOrderState() == OrderStateEnum.NEW.getState()) {
				if(order.getOrderMode() == OrderModeEnum.NORMAL.getMode()) {
					risk.setTotalCount(risk.getTotalCount() + 1);	
					
					if(order.getOrderProperty() > OrderPropertyEnum.NORMAL.getProperty()) {
						risk.setTotalPropertyCount(risk.getTotalPropertyCount() + 1);
					}
				}				
			}else if(order.getOrderState() == OrderStateEnum.PARTIALLY_FILLED.getState() || order.getOrderState() == OrderStateEnum.FILLED.getState()){
				risk.setTradeCount(risk.getTradeCount() + 1);				
			}else if(order.getOrderState() == OrderStateEnum.CANCELLED.getState()) {
				
				if(order.getOrderProperty() == OrderPropertyEnum.NORMAL.getProperty()) {
					risk.setCancelCount(risk.getCancelCount() + 1);
					if(order.getFilledQty().compareTo(BigDecimal.ZERO) == 0 && order.getUpdateTime().getTime() - order.getCreateTime().getTime() <= riskControlProperty.getCancelTimeGap()) {
						risk.setInvalidCancelCount(risk.getInvalidCancelCount() + 1);
					}
				}else {					
					if(order.getFilledQty().compareTo(BigDecimal.ZERO) == 0) {
						risk.setExpiredPropertyCount(risk.getExpiredPropertyCount() + 1);
					}
				}				
			}
		}
	
		
		if(System.currentTimeMillis() - CacheUtil.riskStartTime >= riskControlProperty.getPeriod()) {
			
			checkViolation();
			
			checkExpire();
			
		}
		
	}

}
