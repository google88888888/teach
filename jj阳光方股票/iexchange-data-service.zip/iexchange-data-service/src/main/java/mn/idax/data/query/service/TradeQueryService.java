package mn.idax.data.query.service;

import mn.idax.common.query.request.GetFinishTradesRequest;
import mn.idax.common.query.response.QueryResponseItem;

/**
 * @ClassName TradeQueryService
 * @Description 交易信息
 * @Author duanlsh
 * @Date 2018/12/11 10:59
 * @Version 1.0
 */
public interface TradeQueryService {

    /**
     * 完成交易对象信息
     * @param guid
     * @param getFinishTradesRequest
     * @return
     */
    QueryResponseItem geFinishTrades(long guid, GetFinishTradesRequest getFinishTradesRequest);
}
