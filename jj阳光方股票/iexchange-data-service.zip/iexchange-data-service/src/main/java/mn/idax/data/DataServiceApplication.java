package mn.idax.data;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ImportResource;

/**
 * @author zhouou 214108525@qq.com
 *
 * 2019年1月1日
 */
@SpringBootApplication

@ImportResource(locations={"classpath:app-config.xml"})
public class DataServiceApplication {

	public static void main(String[] args) {		
		
		SpringApplication.run(DataServiceApplication.class, args);
	}
}
