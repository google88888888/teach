package mn.idax.data.db.service;

import java.sql.Timestamp;

import mn.idax.data.service.SyncService;

/**
 * @author liuxueshen
 *
 * 2018年11月9日
 */
public interface OrderService {


	/**
	 * 从DB中读取24小时以内的订单
	 * @param from
	 */
	void loadOrderList(Timestamp from, SyncService syncService);
	
	
	/**获取等待中的止赢止损
	 * @return
	 */
	int getOrderModeCount();
	
}
