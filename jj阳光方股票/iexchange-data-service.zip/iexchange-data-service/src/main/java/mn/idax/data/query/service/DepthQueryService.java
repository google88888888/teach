package mn.idax.data.query.service;

import mn.idax.common.query.response.DepthResponse;

/**
 * @author zhouou 214108525@qq.com
 *
 * 2018年12月18日
 */
public interface DepthQueryService {


	/**
	 * 获取 Depth的 的数据
	 * @param pairName
	 * @param size
	 * @param digits
	 * @return
	 */
	DepthResponse getDepth(String pairName, int size, int digits);

}
