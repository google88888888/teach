package mn.idax.data.bean;

import java.util.TimeZone;

/**
 * @author zhouou 214108525@qq.com
 *
 * 2018年11月1日
 */
public class Config {
	
	private String timezone;
	private String coreSocketUrl;
	private int coreSocketPort;
	private int interval;
	private int depthSnapshotMaxSize;
	private int pageSize;
	
	private int serverId;
	private String appName;
	
	private int dataSocketPort;
	
	private int maxQueryRequestSize;
	private int queryThreadsSize;
	
	private int nioExpireSeconds;
	private int historyHours;
	private String serverStatusUrls;
	private int historySize;
	
	public String getTimezone() {
		return timezone;
	}
	public void setTimezone(String timezone) {
		this.timezone = timezone;
		
		//一定要在这里初始化时区
		System.setProperty("user.timezone",timezone);
		TimeZone.setDefault(TimeZone.getTimeZone(timezone));
	}
	public String getCoreSocketUrl() {
		return coreSocketUrl;
	}
	public void setCoreSocketUrl(String coreSocketUrl) {
		this.coreSocketUrl = coreSocketUrl;
	}
	
	public int getCoreSocketPort() {
		return coreSocketPort;
	}
	public void setCoreSocketPort(int coreSocketPort) {
		this.coreSocketPort = coreSocketPort;
	}
	
	public int getInterval() {
		return interval;
	}
	public void setInterval(int interval) {
		this.interval = interval;
	}
	
	public int getDepthSnapshotMaxSize() {
		return depthSnapshotMaxSize;
	}
	public void setDepthSnapshotMaxSize(int depthSnapshotMaxSize) {
		this.depthSnapshotMaxSize = depthSnapshotMaxSize;
	}
	public int getPageSize() {
		return pageSize;
	}
	public void setPageSize(int pageSize) {
		this.pageSize = pageSize;
	}
	
	public int getServerId() {
		return serverId;
	}
	public void setServerId(int serverId) {
		this.serverId = serverId;
	}
	public String getAppName() {
		return appName;
	}
	public void setAppName(String appName) {
		this.appName = appName;
	}		

	public int getDataSocketPort() {
		return dataSocketPort;
	}
	public void setDataSocketPort(int dataSocketPort) {
		this.dataSocketPort = dataSocketPort;
	}
	public int getMaxQueryRequestSize() {
		return maxQueryRequestSize;
	}
	public void setMaxQueryRequestSize(int maxQueryRequestSize) {
		this.maxQueryRequestSize = maxQueryRequestSize;
	}
	public int getQueryThreadsSize() {
		return queryThreadsSize;
	}
	public void setQueryThreadsSize(int queryThreadsSize) {
		this.queryThreadsSize = queryThreadsSize;
	}
		
	public long getNioExpireSeconds() {
		return nioExpireSeconds;
	}
	public void setNioExpireSeconds(int nioExpireSeconds) {
		this.nioExpireSeconds = nioExpireSeconds;
	}
	
	public int getHistoryHours() {
		return historyHours;
	}
	public void setHistoryHours(int historyHours) {
		this.historyHours = historyHours;
	}

	public String getServerDetailStatusUrls() {
		return serverStatusUrls;
	}

	public void setServerStatusUrls(String serverStatusUrls) {
		this.serverStatusUrls = serverStatusUrls;
	}
	
	public int getHistorySize() {
		return historySize;
	}
	public void setHistorySize(int historySize) {
		this.historySize = historySize;
	}
}
