package mn.idax.data.db.service.impl;

import mn.idax.common.entity.Pair;
import mn.idax.common.entity.Trade;
import mn.idax.common.util.LogUtil;
import mn.idax.data.db.service.TradeService;
import mn.idax.data.service.SyncService;
import mn.idax.data.util.CacheUtil;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;

/**
 * @ClassName TradeServiceImpl
 * @Description 交易数据信息
 * @Author duanlsh
 * @Date 2018/12/12 15:04
 * @Version 1.0
 */
@Service
public class TradeServiceImpl implements TradeService {

    private static final Logger logger = LoggerFactory.getLogger(TradeServiceImpl.class);
   
    private static final int BATCH_SIZE = 500000;
	
	@Autowired
	private DataSource dataSource;
			
    @Override
    public void loadTradeList(Timestamp from, SyncService syncService){

        String sql = " select Id,OrderType,OrderSide,PairName,BuyOrderId,SellOrderId,BuyerId,SellerId,BuyerFee,BuyerFeeCoinCode,SellerFee,SellerFeeCoinCode,BuyerFeeRate,SellerFeeRate,IsBuyerMaker,FilledQty,Price,TradeState,CreateTime,UpdateTime,CNYPrice,BuyerPrice,SellerPrice,Tid " +
                "FROM [trade] WHERE CreateTime > ? ";
        
        Connection connection = null;
        PreparedStatement statement = null;
        ResultSet resultSet;
        
        int count = 0;
        
        try {
            connection = dataSource.getConnection();
            statement = connection.prepareStatement(sql);            
            statement.setFetchSize(BATCH_SIZE);
			
			statement.setTimestamp(1, from);
			
            resultSet = statement.executeQuery();
            Trade trade;
            long start = System.currentTimeMillis();
            
            while(resultSet.next()){
                trade = new Trade();
                trade.setId(resultSet.getLong(1));
                trade.setOrderType(resultSet.getInt(2));
                trade.setOrderSide(resultSet.getInt(3));
                trade.setPairName(resultSet.getString(4));
                trade.setBuyOrderId(resultSet.getLong(5));
                trade.setSellOrderId(resultSet.getLong(6));
                trade.setBuyerId(resultSet.getInt(7));
                trade.setSellerId(resultSet.getInt(8));
                trade.setBuyerFee(resultSet.getBigDecimal(9));
                trade.setBuyerFeeCoinCode(resultSet.getString(10));
                trade.setSellerFee(resultSet.getBigDecimal(11));
                trade.setSellerFeeCoinCode(resultSet.getString(12));
                trade.setBuyerFeeRate(resultSet.getBigDecimal(13));
                trade.setSellerFeeRate(resultSet.getBigDecimal(14));
                trade.setIsBuyerMaker(resultSet.getBoolean(15));
                trade.setFilledQty(resultSet.getBigDecimal(16));
                trade.setPrice(resultSet.getBigDecimal(17));
                trade.setTradeState(resultSet.getInt(18));
                trade.setCreateTime(resultSet.getTimestamp(19));
                trade.setUpdateTime(resultSet.getTimestamp(20));
                trade.setCnyPrice(resultSet.getBigDecimal(21));
                trade.setBuyerPrice(resultSet.getBigDecimal(22));
                trade.setSellerPrice(resultSet.getBigDecimal(23));
                trade.setTid(resultSet.getLong(24));
    			
    			syncService.processTradeNonQuantized(trade);
    			
    			count ++;
    			
    			
    			//每100万条清理数据
    			if(count % 1000000 == 0) {
					syncService.doCleanTrade();
				}
            }
            LogUtil.logInfo("TradeServiceImpl-readTradeList",start, String.format("### trade 本次加载数据量为：%d", count));
        }catch (SQLException ex) {
            logger.error("IEXCHANGE-DB-ERROR {}",ex);
        }finally {
            try {
                if (statement != null) {
                    statement.close();
                }

                if (connection != null) {
                    connection.close();
                }
            } catch (Exception e){
            }
        }
    }

}
