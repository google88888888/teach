package mn.idax.data.service.impl;

import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TimeZone;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.apache.commons.lang3.time.DateUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSON;

import mn.idax.common.constant.AppStateEnum;
import mn.idax.common.constant.Constants;
import mn.idax.common.entity.Pair;
import mn.idax.common.query.request.QueryRequestItem;
import mn.idax.common.query.response.QueryResponseItem;
import mn.idax.common.util.CommonUtil;
import mn.idax.common.util.LogUtil;
import mn.idax.common.util.MessageUtil;
import mn.idax.common.util.SimpleThreadFactory;
import mn.idax.data.bean.AsyncRequest;
import mn.idax.data.bean.Config;
import mn.idax.data.db.service.OrderService;
import mn.idax.data.db.service.PairService;
import mn.idax.data.db.service.TradeService;
import mn.idax.data.query.service.QueryService;
import mn.idax.data.service.SpecialDepthService;
import mn.idax.data.service.RiskService;
import mn.idax.data.service.SyncService;
import mn.idax.data.socket.SyncSocketClient;
import mn.idax.data.util.CacheUtil;

/**
 * @author zhouou 214108525@qq.com
 *
 * 2018年11月16日
 */

@Service
public class InitService {

	private static final Logger logger = LoggerFactory.getLogger(InitService.class);
	
	@Autowired
	private Config config;
	
	@Autowired
	private SyncService syncService;	
		
	@Autowired
	private QueryService queryService;
	
	
	@Autowired
	private OrderService orderService;
	
	
	@Autowired
	private TradeService tradeService;

	@Autowired
	private SimpleThreadFactory simpleThreadFactory;
	
	@Autowired
	private PairService pairService;
	
	@Autowired
	private SyncSocketClient syncSocketClient;
	
	@Autowired
	private RiskService riskService;
	
	@Autowired
	private SpecialDepthService specialDepthService;
	
	private void processExpireNio() {
		
		Map<Long, AsyncRequest> asyncRequestMap = new HashMap<Long,AsyncRequest>(Constants.COLLECTION_DEFAULT_SIZE);
		long now = System.currentTimeMillis();
		
		for(AsyncRequest item: CacheUtil.requestMap.values()) {
			if(now - item.getCreateTime() >= config.getNioExpireSeconds() * 1000) {
				asyncRequestMap.put(item.getId(), item);
			}
		}
		
		if(asyncRequestMap.size() > 0) {
			logger.warn("NIO expired {} ", asyncRequestMap.size());
			
			for(AsyncRequest item: asyncRequestMap.values()) {
				
				logger.warn("NIO expired requests {} respones {} request {} response {}", item.getRequest().getQueryRequestItemList().size(), item.getQueryResponseItemList().size(), 
						JSON.toJSONString(item.getRequest().getQueryRequestItemList()), JSON.toJSONString(item.getQueryResponseItemList()) );
				
				synchronized(item) {
					Set<Long> guidSet = new HashSet<Long>();
					for(QueryRequestItem request: item.getRequest().getQueryRequestItemList()) {
						guidSet.add(request.getGuid());
					}
					
					for(QueryResponseItem response: item.getQueryResponseItemList()) {
						guidSet.remove(response.getGuid());
					}
					
					//补全所有缺失的响应
					for(long guid: guidSet) {
						 //清空一个批次的未处理信息
						CacheUtil.requestMap.remove(guid);
						
						QueryResponseItem queryResponseItem = QueryResponseItem.createResponseBase(guid, "request.expired");
						item.getQueryResponseItemList().add(queryResponseItem);
						//中转socket连入的，立即返回
						if(item.getSocketResultQueue()!=null) {
							item.getSocketResultQueue().offer(queryResponseItem);
						}
						
					}
				}
						
			}
		}
	}
	
	public void loadCache() {
		List<Pair> pairList = pairService.readPairList();
		
		if(pairList!=null) {
			for(Pair item: pairList) {
				CacheUtil.pairMap.put(item.getPairName(), item);
			}
		}
	}

	public void loadTrade(){
		
		long start = System.currentTimeMillis();
		
		Date from = DateUtils.addHours(new Date(), 0 - config.getHistoryHours());
		
		tradeService.loadTradeList(new java.sql.Timestamp(from.getTime()), syncService);
		
		LogUtil.logInfo("InitService-loadTrade",start,"Trade DB =>> memory totalTime");
	}
	
	public void loadOrder(){
		
		long start = System.currentTimeMillis();
		
		Date from = DateUtils.addHours(new Date(), 0 - config.getHistoryHours());
		
		orderService.loadOrderList(new java.sql.Timestamp(from.getTime()), syncService);
		
		LogUtil.logInfo("InitService-loadOrder",start," Order DB =>> memory totalTime");
	}

	@PostConstruct
	public void init() {
		
		System.setProperty("user.timezone",config.getTimezone());
		TimeZone.setDefault(TimeZone.getTimeZone(config.getTimezone()));
		
		LogUtil.setServerName(config.getAppName());
		LogUtil.setServerId(config.getServerId());
		
		MessageUtil.loadMessages("message.properties");
		
		CommonUtil.serverId = config.getServerId();
		CacheUtil.config = config;
		
		long start = System.currentTimeMillis();
		
		LogUtil.logInfo("AppState", 0, "LOADING");
		
		//为了优化cache对string的引用
		loadCache();
		
		//加载订单数据到内存
		loadOrder();
		
		//加载交易数据到内存
		loadTrade();

		CacheUtil.dataServiceState = AppStateEnum.RUNNING;
		
		LogUtil.logInfo("AppState", 0, "RUNNING");

		LogUtil.logInfo("InitService-init",start, "Init load finished");

		
		ScheduledExecutorService scheduler = new ScheduledThreadPoolExecutor(5, simpleThreadFactory);
		
		scheduler.scheduleWithFixedDelay(new Runnable() {

            @Override
            public void run() {
            	
            	if(CacheUtil.dataServiceState != AppStateEnum.RUNNING) {
          		  	return;
          	  	}
            	
            	try {
            		syncService.syncAccount();
            	}catch(Exception ex) {
            		logger.error("IEXCHANGE-COMMON-ERROR {}", ex);
            	}
            	
            	
            }
            
        }, 0, config.getInterval(), TimeUnit.MILLISECONDS);
		
		
		
		scheduler.scheduleWithFixedDelay(new Runnable() {

            @Override
            public void run() {
            	
            	if(CacheUtil.dataServiceState != AppStateEnum.RUNNING) {
          		  	return;
          	  	}
            	
            	try {
            		syncService.syncByUserOrder();
            	}catch(Exception ex) {
            		logger.error("IEXCHANGE-COMMON-ERROR {}", ex);
            	}
            	
            	
            }
            
        }, 0, config.getInterval(), TimeUnit.MILLISECONDS);
		
		scheduler.scheduleWithFixedDelay(new Runnable() {

            @Override
            public void run() {
            	
            	if(CacheUtil.dataServiceState != AppStateEnum.RUNNING) {
          		  	return;
          	  	}
            	
            	try {
            		syncService.syncByPairOrder();
            	}catch(Exception ex) {
            		logger.error("IEXCHANGE-COMMON-ERROR {}", ex);
            	}
            	
            	
            }
            
        }, 0, config.getInterval(), TimeUnit.MILLISECONDS);
		
		scheduler.scheduleWithFixedDelay(new Runnable() {

            @Override
            public void run() {
            	
            	if(CacheUtil.dataServiceState != AppStateEnum.RUNNING) {
          		  	return;
          	  	}
            	
            	try {
            		syncService.syncHistoryOrder();
            	}catch(Exception ex) {
            		logger.error("IEXCHANGE-COMMON-ERROR {}", ex);
            	}
            	
            	
            }
            
        }, 0, config.getInterval(), TimeUnit.MILLISECONDS);
		
		
		scheduler.scheduleWithFixedDelay(new Runnable() {

            @Override
            public void run() {
            	
            	if(CacheUtil.dataServiceState != AppStateEnum.RUNNING) {
          		  	return;
          	  	}
            	
            	try {
            		syncService.syncOrderMode();
            	}catch(Exception ex) {
            		logger.error("IEXCHANGE-COMMON-ERROR {}", ex);
            	}
            	
            	
            }
            
        }, 0, config.getInterval(), TimeUnit.MILLISECONDS);
		
		
		scheduler.scheduleWithFixedDelay(new Runnable() {

            @Override
            public void run() {
            	
            	if(CacheUtil.dataServiceState != AppStateEnum.RUNNING) {
          		  	return;
          	  	}
            	
            	try {
            		syncService.syncBuyDepth();
            	}catch(Exception ex) {
            		logger.error("IEXCHANGE-COMMON-ERROR {}", ex);
            	}
            	
            	
            }
            
        }, 0, config.getInterval(), TimeUnit.MILLISECONDS);
		
		
		
		
		scheduler.scheduleWithFixedDelay(new Runnable() {

            @Override
            public void run() {
            	
            	if(CacheUtil.dataServiceState != AppStateEnum.RUNNING) {
          		  	return;
          	  	}
            	
            	try {
            		syncService.syncSellDepth();
            	}catch(Exception ex) {
            		logger.error("IEXCHANGE-COMMON-ERROR {}", ex);
            	}
            	
            	
            }
            
        }, 0, config.getInterval(), TimeUnit.MILLISECONDS);


		scheduler.scheduleWithFixedDelay(new Runnable() {

			@Override
			public void run() {

				if(CacheUtil.dataServiceState != AppStateEnum.RUNNING) {
          		  	return;
          	  	}
				
				try {
					syncService.syncTrade();
				}catch(Exception ex) {
					logger.error("IEXCHANGE-COMMON-ERROR {}", ex);
				}


			}

		}, 0, config.getInterval(), TimeUnit.MILLISECONDS);
		
		
		//启动错误消息 NIO推送
        scheduler.scheduleWithFixedDelay(new Runnable() {

              @Override
              public void run() {
              	
            	    if(CacheUtil.dataServiceState != AppStateEnum.RUNNING) {
            		  	return;
            	  	}
            	  
	            	try {
	            		  processExpireNio();
	              	}catch(Exception ex) {
	              		logger.error("IEXCHANGE-COMMON-ERROR {}", ex);
	              	}
            	  
              	
              }
              
          }, 0, config.getNioExpireSeconds(), TimeUnit.SECONDS);
        
        
        scheduler.scheduleWithFixedDelay(new Runnable() {
        	
            @Override
            public void run() {
            	
            	if(CacheUtil.dataServiceState != AppStateEnum.RUNNING) {
          		  	return;
          	  	}
            	
            	try {
            		syncService.doCleanOrder();
            		
            		syncService.doCleanTrade();
            	}catch(Exception ex) {
            		logger.error("IEXCHANGE-COMMON-ERROR {}", ex);
            	}
          	  
            	
            }
            
        }, 0, 1, TimeUnit.MINUTES);
        
        
        scheduler.scheduleWithFixedDelay(new Runnable() {
        	
            @Override
            public void run() {
            	            	
            	try {
            		//每5秒 检查socket存活
            		syncSocketClient.checkAlive();
            		          			
            		
            		riskService.doProcess();
            	}catch(Exception ex) {
            		logger.error("IEXCHANGE-COMMON-ERROR {}", ex);
            	}
            	
            }
            
        }, 5, 5, TimeUnit.SECONDS);
        
      
        scheduler.scheduleWithFixedDelay(new Runnable() {

			@Override
			public void run() {

				if(CacheUtil.dataServiceState != AppStateEnum.RUNNING) {
          		  	return;
          	  	}
				
				try {
					specialDepthService.doProcessOrderBook();
					
					specialDepthService.doProcessRequest();
				}catch(Exception ex) {
					logger.error("IEXCHANGE-COMMON-ERROR {}", ex);
				}


			}

		}, 100, 100, TimeUnit.MILLISECONDS);       
        
        
        
        ScheduledExecutorService queryScheduler = new ScheduledThreadPoolExecutor(config.getQueryThreadsSize(), simpleThreadFactory);
        //启动n个查询线程
		for(int i=0;i<config.getQueryThreadsSize();i++) {
			queryScheduler.scheduleWithFixedDelay(new Runnable() {
	
	            @Override
	            public void run() {
	            	
	            	if(CacheUtil.dataServiceState != AppStateEnum.RUNNING) {
	          		  	return;
	          	  	}
	            	
	            	try {
	            		queryService.doProcess();
	            	}catch(Exception ex) {
	            		logger.error("IEXCHANGE-COMMON-ERROR {}", ex);
	            	}
	            	
	            }
	            
	        }, 0, 1, TimeUnit.MILLISECONDS);
		}
		
	}

	@PreDestroy
	public void destroy() {
		CacheUtil.dataServiceState = AppStateEnum.SHUTTING_DOWN;
	}	
	
}
