package mn.idax.data.util;

import mn.idax.common.entity.Order;
import mn.idax.common.util.ArrayListEx;

/**
 * @author zhouou 214108525@qq.com
 *
 * 2018年11月12日
 * 
 * 买  价高->价低    同价 按时间排 序
 * 卖  价低->价高   同价 按时间排 序 
 * 
 */
public class SpecialOrderBookUtil {	
	
	private static void processSamePrice(ArrayListEx<Order> list, Order order, int index) {
		
		int lastIndex = 0;
		
		for(int i=index;i<list.size();i++) {
			lastIndex = i;
			if(list.get(i).getPrice().compareTo(order.getPrice())!=0) {				
				break;
			}
			if(list.get(i).getId() == order.getId()) {
				list.set(i, order);
				return;
			}
		}
		
		for(int i=index-1;i>=0;i--) {
			if(list.get(i).getPrice().compareTo(order.getPrice())!=0) {
				break;
			}
			if(list.get(i).getId() == order.getId()) {
				list.set(i, order);
				return;
			}
		}
		
		list.add(lastIndex, order);
	}

	private static boolean processBuyHalf(ArrayListEx<Order> list, Order order, int index) {

		if (order.getPrice().compareTo(list.get(index).getPrice()) == 0) {
			processSamePrice(list, order, index);
			return true;
		}
		
        if (index > 0) {
            if (order.getPrice().compareTo(list.get(index - 1).getPrice()) < 0 && order.getPrice().compareTo(list.get(index).getPrice()) > 0) {
                list.add(index, order);
                return true;
            }
        }

        if (index < list.size() - 1) {
            if (order.getPrice().compareTo(list.get(index).getPrice()) < 0 && order.getPrice().compareTo(list.get(index + 1).getPrice()) > 0) {
                list.add(index + 1, order);
                return true;
            }
        }

        return false;
    }
	
	public static void processBuyOrderBook(ArrayListEx<Order> list, Order order) {
				
		//判断 0个或1个
        if (list.size() == 0) {
            list.add(order);
            return;
        } else if (list.size() == 1) {
        	if(order.getId() == list.get(0).getId()) {
        		list.set(0, order);
        	}else if (order.getPrice().compareTo(list.get(0).getPrice()) > 0) {
            	list.add(0, order);            	
            } else {
            	list.add(order);
            }
            return;
        }

        //存在2条以上数据

        //判断是否头尾插入或修改
        if(order.getId() == list.get(0).getId()) {
    		list.set(0, order);
    		return;    		
        }
        if (order.getPrice().compareTo(list.get(0).getPrice()) > 0) {
        	list.add(0, order);   
        	return;
        }        
       
        if(order.getId() == list.get(list.size() - 1).getId()) {
    		list.set(list.size() - 1, order);
    		return;    		
        }
        if (order.getPrice().compareTo(list.get(list.size() - 1).getPrice()) < 0) {
            list.add(order);
            return;
        }else if (order.getPrice().compareTo(list.get(list.size() - 1).getPrice()) == 0) {
        	for(int i=list.size() - 1;i>=0;i--){
        		if(list.get(i).getId() == order.getId()) {
        			list.set(i, order);
        			return;
        		}
        		if(list.get(i).getPrice().compareTo(order.getPrice())!=0) {
        			break;
        		}
        	}
        	list.add(order);
        }


        int index1 = 0, index2 = list.size() - 1;

        //二分法查找
        while (true) {
            int index = index1 + (index2 - index1) / 2;

            boolean success = processBuyHalf(list, order, index);
          //已找到并修改
            if (success) {
                return;
            } else if (order.getPrice().compareTo(list.get(index).getPrice()) > 0) {
                index2 = index;
            } else {
                index1 = index;
            }
        }
        
	}
	
	private static boolean processSellHalf(ArrayListEx<Order> list, Order order, int index) {

		if (order.getPrice().compareTo(list.get(index).getPrice()) == 0) {
			processSamePrice(list, order, index);
			return true;
		}
		
        if (index > 0) {
            if (order.getPrice().compareTo(list.get(index - 1).getPrice()) > 0 && order.getPrice().compareTo(list.get(index).getPrice()) < 0) {
                list.add(index, order);
                return true;
            }
        }

        if (index < list.size() - 1) {
            if (order.getPrice().compareTo(list.get(index).getPrice()) > 0 && order.getPrice().compareTo(list.get(index + 1).getPrice()) < 0) {
                list.add(index + 1, order);
                return true;
            }
        }

        return false;
    }
	
	public static void processSellOrderBook(ArrayListEx<Order> list, Order order) {
				
		//判断 0个或1个
        if (list.size() == 0) {
            list.add(order);
            return;
        } else if (list.size() == 1) {
        	if(order.getId() == list.get(0).getId()) {
        		list.set(0, order);
        	}else if (order.getPrice().compareTo(list.get(0).getPrice()) < 0) {
            	list.add(0, order);            	
            } else {
            	list.add(order);
            }
            return;
        }

        //存在2条以上数据

        //判断是否头尾插入或修改
        if(order.getId() == list.get(0).getId()) {
    		list.set(0, order);
    		return;    		
        }
        if (order.getPrice().compareTo(list.get(0).getPrice()) < 0) {
        	list.add(0, order);   
        	return;
        }        
       
        if(order.getId() == list.get(list.size() - 1).getId()) {
    		list.set(list.size() - 1, order);
    		return;    		
        }
        if (order.getPrice().compareTo(list.get(list.size() - 1).getPrice()) > 0) {
            list.add(order);
            return;
        }else if (order.getPrice().compareTo(list.get(list.size() - 1).getPrice()) == 0) {
        	for(int i=list.size() - 1;i>=0;i--){
        		if(list.get(i).getId() == order.getId()) {
        			list.set(i, order);
        			return;
        		}
        		if(list.get(i).getPrice().compareTo(order.getPrice())!=0) {
        			break;
        		}
        	}
        	list.add(order);
        }


        int index1 = 0, index2 = list.size() - 1;

        //二分法查找
        while (true) {
            int index = index1 + (index2 - index1) / 2;

            boolean success = processSellHalf(list, order, index);
          //已找到并修改
            if (success) {
                return;
            } else if (order.getPrice().compareTo(list.get(index).getPrice()) < 0) {
                index2 = index;
            } else {
                index1 = index;
            }
        }
        
	}
	
	private static void processSamePriceRemove(ArrayListEx<Order> list, Order order, int index) {
		
		for(int i=index;i<list.size()-1;i++) {
			if(list.get(i).getPrice().compareTo(order.getPrice())!=0) {
				break;
			}
			if(list.get(i).getId() == order.getId()) {
				list.remove(i);
				return;
			}
		}
		
		for(int i=index-1;i>0;i--) {
			if(list.get(i).getPrice().compareTo(order.getPrice())!=0) {
				break;
			}
			if(list.get(i).getId() == order.getId()) {
				list.remove(i);
				return;
			}
		}
	}
	
	
	
	public static void removeBuyOrderBook(ArrayListEx<Order> list, Order order) {		
		
		//判断 0个或1个
        if (list.size() == 0) {
            return;
        } else if (list.size() == 1) {
            if (order.getId() == list.get(0).getId()) {
            	list.remove(0);            	
            } 
            return;
        }

        //存在2条以上数据

        //判断是否头尾插入或修改
        if (order.getId() == list.get(0).getId()) {
        	list.remove(0);
        	return;
        }        
       
        if (order.getId() == list.get(list.size() - 1).getId()) {
        	list.remove(list.size() - 1);
            return;
        }


        int index1 = 0, index2 = list.size() - 1;

        //二分法查找
        while (true) {
        	
        	if(index2 - index1 == 1) {
        		return;
        	}
        	
            int index = index1 + (index2 - index1) / 2;

            if (order.getPrice().compareTo(list.get(index).getPrice()) == 0) {
            	processSamePriceRemove(list, order, index);
            	return;
            } else if (order.getPrice().compareTo(list.get(index).getPrice()) > 0) {
                index2 = index;
            } else {
                index1 = index;
            }
        }
        
	}
	
	public static void removeSellOrderBook(ArrayListEx<Order> list, Order order) {		
		
		//判断 0个或1个
        if (list.size() == 0) {
            return;
        } else if (list.size() == 1) {
            if (order.getId() == list.get(0).getId()) {
            	list.remove(0);            	
            } 
            return;
        }

        //存在2条以上数据

        //判断是否头尾插入或修改
        if (order.getId() == list.get(0).getId()) {
        	list.remove(0);   
        	return;
        }        
       
        if (order.getId() == list.get(list.size() - 1).getId()) {
        	list.remove(list.size() - 1); 
            return;
        }


        int index1 = 0, index2 = list.size() - 1;

        //二分法查找
        while (true) {
        	
        	if(index2 - index1 == 1) {
        		return;
        	}
        	
            int index = index1 + (index2 - index1) / 2;

            if (order.getPrice().compareTo(list.get(index).getPrice()) == 0) {
            	processSamePriceRemove(list, order, index);
            	return;
            } else if (order.getPrice().compareTo(list.get(index).getPrice()) < 0) {
                index2 = index;
            } else {
                index1 = index;
            }
        }
        
	}

}
