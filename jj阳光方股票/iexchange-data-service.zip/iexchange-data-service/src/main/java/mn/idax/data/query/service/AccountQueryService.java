package mn.idax.data.query.service;

import mn.idax.common.query.request.GetBalanceRequest;
import mn.idax.common.query.request.GetUserAccountRequest;
import mn.idax.common.query.response.QueryResponseItem;

/**
 * @author zhouou 214108525@qq.com
 *
 * 2018年12月7日
 */
public interface AccountQueryService {

	/**
	 * 获取资金账户信息
	 * @param guid
	 * @param request
	 * @return
	 */
	QueryResponseItem getUserAccount(long guid, GetUserAccountRequest request);

	/**
	 * 查询资金账户
	 * @param guid
	 * @param request
	 * @return
	 */
	QueryResponseItem getBalance(long guid, GetBalanceRequest request);

}
