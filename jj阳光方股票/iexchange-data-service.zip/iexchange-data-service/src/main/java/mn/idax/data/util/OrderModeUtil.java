package mn.idax.data.util;

import mn.idax.common.entity.Order;
import mn.idax.common.util.ArrayListEx;

/**
 * @author zhouou 214108525@qq.com
 *
 * 2018年11月12日
 * 
 * 买  价高->价低    同价 按时间排 序
 * 卖  价低->价高   同价 按时间排 序 
 * 
 */
public class OrderModeUtil {	
	
	
	private static boolean processDownHalf(ArrayListEx<Order> list, Order order, int index) {

        if (index > 0) {
            if (order.getTriggerPrice().compareTo(list.get(index - 1).getTriggerPrice()) <= 0 && order.getTriggerPrice().compareTo(list.get(index).getTriggerPrice()) > 0) {
                list.add(index, order);
                return true;
            }
        }

        if (index < list.size() - 1) {
            if (order.getTriggerPrice().compareTo(list.get(index).getTriggerPrice()) <= 0 && order.getTriggerPrice().compareTo(list.get(index + 1).getTriggerPrice()) > 0) {
                list.add(index + 1, order);
                return true;
            }
        }

        return false;
    }
	
	public static void processDownOrderBook(ArrayListEx<Order> list, Order order) {
				
		//判断 0个或1个
        if (list.size() == 0) {
            list.add(order);
            return;
        } else if (list.size() == 1) {
            if (order.getTriggerPrice().compareTo(list.get(0).getTriggerPrice()) > 0) {
            	list.add(0, order);            	
            } else {
            	list.add(order);
            }
            return;
        }

        //存在2条以上数据

        //判断是否头尾插入或修改
        if (order.getTriggerPrice().compareTo(list.get(0).getTriggerPrice()) > 0) {
        	list.add(0, order);   
        	return;
        }        
       
        if (order.getTriggerPrice().compareTo(list.get(list.size() - 1).getTriggerPrice()) <= 0) {
            list.add(order);
            return;
        }


        int index1 = 0, index2 = list.size() - 1;

        //二分法查找
        while (true) {
            int index = index1 + (index2 - index1) / 2;

            boolean success = processDownHalf(list, order, index);
          //已找到并修改
            if (success) {
                return;
            } else if (order.getTriggerPrice().compareTo(list.get(index).getTriggerPrice()) > 0) {
                index2 = index;
            } else {
                index1 = index;
            }
        }
        
	}
	
	private static boolean processUpHalf(ArrayListEx<Order> list, Order order, int index) {

        if (index > 0) {
            if (order.getTriggerPrice().compareTo(list.get(index - 1).getTriggerPrice()) >= 0 && order.getTriggerPrice().compareTo(list.get(index).getTriggerPrice()) < 0) {
                list.add(index, order);
                return true;
            }
        }

        if (index < list.size() - 1) {
            if (order.getTriggerPrice().compareTo(list.get(index).getTriggerPrice()) >= 0 && order.getTriggerPrice().compareTo(list.get(index + 1).getTriggerPrice()) < 0) {
                list.add(index + 1, order);
                return true;
            }
        }

        return false;
    }
	
	public static void processUpOrderBook(ArrayListEx<Order> list, Order order) {
				
		//判断 0个或1个
        if (list.size() == 0) {
            list.add(order);
            return;
        } else if (list.size() == 1) {
            if (order.getTriggerPrice().compareTo(list.get(0).getTriggerPrice()) < 0) {
            	list.add(0, order);            	
            } else {
            	list.add(order);
            }
            return;
        }

        //存在2条以上数据

        //判断是否头尾插入或修改
        if (order.getTriggerPrice().compareTo(list.get(0).getTriggerPrice()) < 0) {
        	list.add(0, order);   
        	return;
        }        
       
        if (order.getTriggerPrice().compareTo(list.get(list.size() - 1).getTriggerPrice()) >= 0) {
            list.add(order);
            return;
        }


        int index1 = 0, index2 = list.size() - 1;

        //二分法查找
        while (true) {
            int index = index1 + (index2 - index1) / 2;

            boolean success = processUpHalf(list, order, index);
          //已找到并修改
            if (success) {
                return;
            } else if (order.getTriggerPrice().compareTo(list.get(index).getTriggerPrice()) < 0) {
                index2 = index;
            } else {
                index1 = index;
            }
        }
        
	}
	
	private static void processSamePrice(ArrayListEx<Order> list, Order order, int index) {
		
		for(int i=index;i<list.size()-1;i++) {
			if(list.get(i).getTriggerPrice().compareTo(order.getTriggerPrice())!=0) {
				break;
			}
			if(list.get(i).getId() == order.getId()) {
				list.remove(i);
				return;
			}
		}
		
		for(int i=index-1;i>0;i--) {
			if(list.get(i).getTriggerPrice().compareTo(order.getTriggerPrice())!=0) {
				break;
			}
			if(list.get(i).getId() == order.getId()) {
				list.remove(i);
				return;
			}
		}
	}
	
	
	
	public static void removeDownOrderBook(ArrayListEx<Order> list, Order order) {		
		
		//判断 0个或1个
        if (list.size() == 0) {
            return;
        } else if (list.size() == 1) {
            if (order.getId() == list.get(0).getId()) {
            	list.remove(0);            	
            } 
            return;
        }

        //存在2条以上数据

        //判断是否头尾插入或修改
        if (order.getId() == list.get(0).getId()) {
        	list.remove(0);
        	return;
        }        
       
        if (order.getId() == list.get(list.size() - 1).getId()) {
        	list.remove(list.size() - 1);
            return;
        }


        int index1 = 0, index2 = list.size() - 1;

        //二分法查找
        while (true) {
        	
        	if(index2 - index1 == 1) {
        		return;
        	}
        	
            int index = index1 + (index2 - index1) / 2;

            if (order.getTriggerPrice().compareTo(list.get(index).getTriggerPrice()) == 0) {
            	processSamePrice(list, order, index);
            	return;
            } else if (order.getTriggerPrice().compareTo(list.get(index).getTriggerPrice()) > 0) {
                index2 = index;
            } else {
                index1 = index;
            }
        }
        
	}
	
	public static void removeUpOrderBook(ArrayListEx<Order> list, Order order) {		
		
		//判断 0个或1个
        if (list.size() == 0) {
            return;
        } else if (list.size() == 1) {
            if (order.getId() == list.get(0).getId()) {
            	list.remove(0);            	
            } 
            return;
        }

        //存在2条以上数据

        //判断是否头尾插入或修改
        if (order.getId() == list.get(0).getId()) {
        	list.remove(0);   
        	return;
        }        
       
        if (order.getId() == list.get(list.size() - 1).getId()) {
        	list.remove(list.size() - 1); 
            return;
        }


        int index1 = 0, index2 = list.size() - 1;

        //二分法查找
        while (true) {
        	
        	if(index2 - index1 == 1) {
        		return;
        	}
        	
            int index = index1 + (index2 - index1) / 2;

            if (order.getTriggerPrice().compareTo(list.get(index).getTriggerPrice()) == 0) {
            	processSamePrice(list, order, index);
            	return;
            } else if (order.getTriggerPrice().compareTo(list.get(index).getTriggerPrice()) < 0) {
                index2 = index;
            } else {
                index1 = index;
            }
        }
        
	}

}

