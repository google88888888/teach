package mn.idax.data.util;

import mn.idax.common.entity.Order;
import mn.idax.common.util.ArrayListEx;

/**
 * @author zhouou 214108525@qq.com
 *
 * 2018年11月12日
 * 
 * 买  价高->价低    同价 按时间排 序
 * 卖  价低->价高   同价 按时间排 序 
 * 
 */
public class OrderBookByUserUtil {	
	
	
	private static boolean processHalf(ArrayListEx<Order> list, Order order, int index) {
		
		if(list.get(index).getId() == order.getId()) {
			list.set(index, order);
			return true;
		}

        if (index > 0) {
            if (order.getId() > list.get(index - 1).getId() && order.getId() < list.get(index).getId()) {
                list.add(index, order);
                return true;
            }
        }

        if (index < list.size() - 1) {
            if (order.getId() > list.get(index).getId() && order.getId() < list.get(index + 1).getId()) {
                list.add(index + 1, order);
                return true;
            }
        }

        return false;
    }
	
	public static void processUpdateOrderBook(ArrayListEx<Order> list, Order order) {
		
		
		//判断 0个或1个
        if (list.size() == 0) {
            list.add(order);
            return;
        } else if (list.size() == 1) {
        	if(order.getId() == list.get(0).getId()) {
        		list.set(0, order);
        	}else if (order.getId() >  list.get(0).getId()) {
            	list.add(order);            	
            } else {
            	list.add(0, order);
            }
            return;
        }

        //存在2条以上数据

        //判断是否头尾插入或修改
        if (order.getId() == list.get(0).getId()) {
        	list.set(0, order);   
        	return;
        }else if (order.getId() < list.get(0).getId()) {
        	list.add(0, order);   
        	return;
        }        
       
        if (order.getId() == list.get(list.size() - 1).getId()) {
        	list.set(list.size() - 1, order);   
        	return;
        }else if (order.getId() > list.get(list.size() - 1).getId()) {
            list.add(order);
            return;
        }


        int index1 = 0, index2 = list.size() - 1;

        //二分法查找
        while (true) {
            int index = index1 + (index2 - index1) / 2;

            boolean success = processHalf(list, order, index);
          //已找到并修改
            if (success) {
                return;
            } else if (order.getId() < list.get(index).getId()) {
                index2 = index;
            } else {
                index1 = index;
            }
        }
        
	}
	
	
	private static boolean removeHalf(ArrayListEx<Order> list, Order order, int index) {

        if (order.getId() == list.get(index).getId()) {
            list.remove(index);
            return true;
        }      

        return false;
    }
	
	public static void removeOrderBook(ArrayListEx<Order> list, Order order) {		
		
		//判断 0个或1个
        if (list.size() == 0) {
            return;
        } else if (list.size() == 1) {
            if (order.getId() == list.get(0).getId()) {
            	list.remove(0);            	
            } 
            return;
        }

        //存在2条以上数据

        //判断是否头尾插入或修改
        if (order.getId() == list.get(0).getId()) {
        	list.remove(0);
        	return;
        }        
       
        if (order.getId() == list.get(list.size() - 1).getId()) {
        	list.remove(list.size() - 1);
            return;
        }


        int index1 = 0, index2 = list.size() - 1;

        //二分法查找
        while (true) {
        	
        	//有可能找不到删除的对象
        	if(index2 - index1 == 1) {
        		return;
        	}
        	
            int index = index1 + (index2 - index1) / 2;

            boolean success = removeHalf(list, order, index);
          //已找到并修改
            if (success) {
                return;
            }  else if (order.getId() < list.get(index).getId()) {
                index2 = index;
            } else {
                index1 = index;
            }
        }
        
	}
	
	
	/*private static boolean findHalf(List<Order> list, long orderId, int index) {

        if (orderId == list.get(index).getId()) {
            return true;
        }      

        return false;
    }
	
	public static Order findOrder(List<Order> list, long orderId) {		
		
		//判断 0个或1个
        if (list.size() == 0) {
            return null;
        } else if (list.size() == 1) {
            if (orderId == list.get(0).getId()) {
            	return list.get(0);            	
            } 
        }

        //存在2条以上数据

        //判断是否头尾插入或修改
        if (orderId == list.get(0).getId()) {
        	return list.get(0);
        }        
       
        if (orderId == list.get(list.size() - 1).getId()) {
            return list.get(list.size() - 1);
        }


        int index1 = 0, index2 = list.size() - 1;

        //二分法查找
        while (true) {
        	
        	//有可能找不到删除的对象
        	if(index2 - index1 == 1) {
        		return null;
        	}
        	
            int index = index1 + (index2 - index1) / 2;

            boolean success = findHalf(list, orderId, index);
            if (success) {//已找到并修改
                return list.get(index);
            }  else if (orderId < list.get(index).getId()) {
                index2 = index;
            } else {
                index1 = index;
            }
        }
        
	}*/

}
