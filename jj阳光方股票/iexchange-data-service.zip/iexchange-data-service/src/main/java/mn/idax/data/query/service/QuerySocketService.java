package mn.idax.data.query.service;

import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;

/**
 * @author zhouou 214108525@qq.com
 *
 * 2018年12月6日
 */
public interface QuerySocketService {


	/**
	 * 处理 forward-api的 查询请求
	 * @param socket
	 * @param inputStream
	 * @param outputStream
	 * @throws Exception
	 */
	void doProcess(Socket socket, InputStream inputStream, OutputStream outputStream) throws Exception;
	
}
