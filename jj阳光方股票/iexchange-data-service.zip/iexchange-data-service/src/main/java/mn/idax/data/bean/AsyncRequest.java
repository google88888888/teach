package mn.idax.data.bean;

import java.util.List;
import java.util.concurrent.ConcurrentLinkedQueue;

import mn.idax.common.query.request.QueryRequest;
import mn.idax.common.query.response.QueryResponseItem;

/**
 * @author zhouou 214108525@qq.com
 *
 * 2018年11月8日
 */
public class AsyncRequest {
	
	/**用来去重使用**/
	private long id;
	
	private QueryRequest request;
	
	private ConcurrentLinkedQueue<QueryResponseItem> socketResultQueue;
	
	private List<QueryResponseItem> queryResponseItemList;
	
	
	private long createTime;
	
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	
	public QueryRequest getRequest() {
		return request;
	}
	public void setRequest(QueryRequest request) {
		this.request = request;
	}
	
	public ConcurrentLinkedQueue<QueryResponseItem> getSocketResultQueue() {
		return socketResultQueue;
	}
	public void setSocketResultQueue(ConcurrentLinkedQueue<QueryResponseItem> socketResultQueue) {
		this.socketResultQueue = socketResultQueue;
	}
	public List<QueryResponseItem> getQueryResponseItemList() {
		return queryResponseItemList;
	}

	public void setQueryResponseItemList(List<QueryResponseItem> queryResponseItemList) {
		this.queryResponseItemList = queryResponseItemList;
	}
	public long getCreateTime() {
		return createTime;
	}
	public void setCreateTime(long createTime) {
		this.createTime = createTime;
	}	
	
}
