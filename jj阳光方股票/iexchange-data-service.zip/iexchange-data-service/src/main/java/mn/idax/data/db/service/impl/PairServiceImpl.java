package mn.idax.data.db.service.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import mn.idax.common.util.LogUtil;
import mn.idax.data.db.service.PairService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import mn.idax.common.entity.Pair;


/**
 * @author zhouou 214108525@qq.com
 *
 * 2018年11月9日
 */
@Service
public class PairServiceImpl implements PairService{
	
private static final Logger logger = LoggerFactory.getLogger(PairServiceImpl.class);
	
	@Autowired
	private DataSource dataSource;
	
	private static final String COLUMNS = "Id,BaseCoinId,BaseCoinCode,QuoteCoinId,QuoteCoinCode,PairName,MaxAmount,MinAmount,PriceDecimalPlace,QtyDecimalPlace,PairState,CreateTime,UpdateTime,TimingShelfTime,OpeningPrice,MarketType,MakerFeeRate,TakerFeeRate";
	
	
	private Pair mapper(ResultSet resultSet) throws SQLException{
		
		Pair pair = new Pair();
		pair.setId(resultSet.getInt(1));
		pair.setBaseCoinId(resultSet.getInt(2));
		pair.setBaseCoinCode(resultSet.getString(3));
		pair.setQuoteCoinId(resultSet.getInt(4));
		pair.setQuoteCoinCode(resultSet.getString(5));
		pair.setPairName(resultSet.getString(6));		
		pair.setMaxAmount(resultSet.getBigDecimal(7));
		pair.setMinAmount(resultSet.getBigDecimal(8));
		pair.setPriceDecimalPlace(resultSet.getInt(9));
		pair.setQtyDecimalPlace(resultSet.getInt(10));
		pair.setPairState(resultSet.getInt(11));			
		pair.setCreateTime(resultSet.getTimestamp(12));
		pair.setUpdateTime(resultSet.getTimestamp(13));			
		pair.setTimingShelfTime(resultSet.getTimestamp(14));
		pair.setOpeningPrice(resultSet.getBigDecimal(15));
		pair.setMarketType(resultSet.getInt(16));
		pair.setMakerFeeRate(resultSet.getBigDecimal(17));
		pair.setTakerFeeRate(resultSet.getBigDecimal(18));
		
		return pair;
	}
	
	@Override
	public List<Pair> readPairList(){
		
		long start = System.currentTimeMillis();	
		
		String sql = "select " + COLUMNS + " from [Pair]";
		
		Connection connection = null;
		PreparedStatement statement = null;
		ResultSet resultSet=null;
		
		List<Pair> pairList = null;
		
		try {		
			
			connection = dataSource.getConnection();
			statement = connection.prepareStatement(sql);
			statement.setFetchSize(100);
			resultSet=statement.executeQuery();
			while(resultSet.next()){
				
				if(pairList==null) {
					pairList = new ArrayList<Pair>(10000);
				}
				
				Pair pair = mapper(resultSet);
				
				pairList.add(pair);
			}			
			
		}catch (SQLException ex) {
			logger.error("IEXCHANGE-DB-ERROR {}",ex);
		}finally {
			if (statement != null) {
				try {
					statement.close();
				} catch (SQLException ex) {
				}
			}
			
			if (connection != null) {
				try {
					connection.close();
				} catch (SQLException ex) {
				}
			}
		} 

		LogUtil.logInfo("PairServiceImpl-readPairList",start, null);
		return pairList;
		
	}
	
}
