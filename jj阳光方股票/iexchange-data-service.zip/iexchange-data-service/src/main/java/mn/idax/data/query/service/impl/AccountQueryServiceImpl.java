package mn.idax.data.query.service.impl;

import java.util.Map;

import mn.idax.common.query.request.GetBalanceRequest;
import mn.idax.common.query.response.BalanceResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import mn.idax.common.entity.Account;
import mn.idax.common.entity.Coin;
import mn.idax.common.query.request.GetUserAccountRequest;
import mn.idax.common.query.response.AccountResponse;
import mn.idax.common.query.response.QueryResponseItem;
import mn.idax.data.db.service.CoinService;
import mn.idax.data.query.service.AccountQueryService;
import mn.idax.data.util.CacheUtil;

/**
 * @author zhouou 214108525@qq.com
 *
 * 2018年12月7日
 */

@Service
public class AccountQueryServiceImpl implements AccountQueryService{
	
	@Autowired
	private CoinService coinService;

	private AccountResponse mapper(Account account) {
		
		AccountResponse accountResponse = new AccountResponse();
		accountResponse.setTotal(account.getAvailableAmount().add(account.getFrozenAmount()));
		accountResponse.setFree(account.getAvailableAmount());
		accountResponse.setFreezed(account.getFrozenAmount());
		Coin coin = CacheUtil.coinMap.get(account.getCoinId());
		
		if(coin == null) {
			coin = coinService.readCoin(account.getCoinId());
			if(coin!=null) {
				CacheUtil.coinMap.put(coin.getId(), coin);
			}
		}
		
		if(coin!=null) {
			accountResponse.setCoinCode(coin.getCode());
		}
		
		return accountResponse;
		
	}
	@Override
	public QueryResponseItem getUserAccount(long guid, GetUserAccountRequest request){
		
		QueryResponseItem queryResponseItem = QueryResponseItem.createAccountListResponse(guid, "success");
		
		Map<Integer, Account> map = CacheUtil.accountMap.get(request.getUserId());
		if(map==null || map.size()==0) {			
			return queryResponseItem;
		}
		
		if(request.getCoinId() > 0) {
			Account account = map.get(request.getCoinId());
			if(account !=null) {				
				queryResponseItem.getAccountListResponse().getData().add(mapper(account));
			}
		}else {
			for(Account item: map.values()) {
				queryResponseItem.getAccountListResponse().getData().add(mapper(item));
			}
		}
		
		return queryResponseItem;		
	}

	@Override
	public QueryResponseItem getBalance(long guid, GetBalanceRequest request) {
		QueryResponseItem queryResponseItem = QueryResponseItem.createBalanceListResponse(guid, "success");

		Map<Integer, Account> map = CacheUtil.accountMap.get(request.getUserId());
		if(map==null || map.size()==0) {
			return queryResponseItem;
		}

		if(request.getCoinId() > 0) {
			Account account = map.get(request.getCoinId());
			if(account !=null) {
				queryResponseItem.getBalanceResponse().getData().add(mapperBalanceResponse(account));
			}
		}else {
			for(Account item: map.values()) {
				queryResponseItem.getBalanceResponse().getData().add(mapperBalanceResponse(item));
			}
		}

		return queryResponseItem;

	}

	private BalanceResponse mapperBalanceResponse(Account account) {

		BalanceResponse balanceResponse = new BalanceResponse();
		balanceResponse.setAvailableamount(account.getAvailableAmount());
		balanceResponse.setFrozenamount(account.getFrozenAmount());
		balanceResponse.setCoinId(account.getCoinId());
		balanceResponse.setUserId(account.getUserId());
		balanceResponse.setId(account.getId());
		return balanceResponse;

	}
}
