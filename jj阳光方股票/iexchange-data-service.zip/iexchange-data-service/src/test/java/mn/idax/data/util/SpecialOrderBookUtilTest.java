package mn.idax.data.util;

import java.math.BigDecimal;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.TypeReference;

import mn.idax.common.constant.OrderSideEnum;
import mn.idax.common.constant.OrderStateEnum;
import mn.idax.common.constant.OrderTypeEnum;
import mn.idax.common.entity.Order;
import mn.idax.common.util.ArrayListEx;


/**
 * @author zhouou 214108525@qq.com
 *
 * 2019年7月3日
 */

public class SpecialOrderBookUtilTest {
	
	public static void main(String[] args) {
		String array = "[{\"amount\":0,\"clientId\":0,\"createTid\":0,\"createTime\":1563938163113,\"filledAmount\":0.01996400,\"filledQty\":0.062,\"frozen\":0.090,\"guid\":0,\"id\":3260656360000019471,\"orderMode\":0,\"orderProperty\":3,\"orderSide\":2,\"orderState\":2,\"orderType\":1,\"pairName\":\"AE_ETH\",\"price\":0.32200000,\"tid\":2606563610000156555,\"total\":0.152,\"triggerTradeId\":0,\"updateTime\":1563938165459,\"userId\":2279,\"userType\":2},{\"amount\":0,\"clientId\":0,\"createTid\":0,\"createTime\":1563939232664,\"filledAmount\":0,\"filledQty\":0,\"frozen\":0.178,\"guid\":0,\"id\":3260656530000330461,\"orderMode\":0,\"orderProperty\":0,\"orderSide\":2,\"orderState\":1,\"orderType\":1,\"pairName\":\"AE_ETH\",\"price\":0.32280000,\"tid\":2606565310001503170,\"total\":0.178,\"triggerTradeId\":0,\"updateTime\":1563939232664,\"userId\":2283,\"userType\":3},{\"amount\":0,\"clientId\":0,\"createTid\":0,\"createTime\":1563939233737,\"filledAmount\":0,\"filledQty\":0,\"frozen\":0.233,\"guid\":0,\"id\":3260656530000337037,\"orderMode\":0,\"orderProperty\":0,\"orderSide\":2,\"orderState\":1,\"orderType\":1,\"pairName\":\"AE_ETH\",\"price\":0.32280000,\"tid\":2606565310001533210,\"total\":0.233,\"triggerTradeId\":0,\"updateTime\":1563939233737,\"userId\":2279,\"userType\":2}] ";
		
		String item = "{\"amount\":0,\"clientId\":0,\"createTid\":0,\"createTime\":1563939232664,\"filledAmount\":0.05745840,\"filledQty\":0.178,\"frozen\":0.000,\"guid\":0,\"id\":3260656530000330461,\"orderMode\":0,\"orderProperty\":0,\"orderSide\":2,\"orderState\":9,\"orderType\":1,\"pairName\":\"AE_ETH\",\"price\":0.32280000,\"tid\":2606565310001544109,\"total\":0.178,\"triggerTradeId\":0,\"updateTime\":1563939234133,\"userId\":2283,\"userType\":3}";
		
		List<Order> list = JSON.parseObject(array, new TypeReference<List<Order>>(){});
		Order order = JSON.parseObject(item, Order.class);
		
		ArrayListEx<Order> listEx = new ArrayListEx<Order>();
		
		for(Order ord: list) {
			listEx.add(ord);
		}
		
		System.out.println(listEx.size());
		
		SpecialOrderBookUtil.processSellOrderBook(listEx, order);
		//SpecialOrderBookUtil.removeSellOrderBook(listEx, order);
		
		
		System.out.println(listEx.size());
		
		//sellOrderBookTest();
		//buyOrderBookTest();
	}

	
 	public static void sellOrderBookTest() {
		
		ArrayListEx<Order> listEx = new ArrayListEx<Order>();
		final int size = 2000000;
		
		Map<Long, Order> orderMap = new HashMap<Long,Order>(size);
		
		Random random = new Random();	
		
		int removeCount = 0;
		
		for(int i=0;i<size;i++) {
			
			Order order = new Order();
			
			Long id = Math.abs(random.nextLong());
 			while(orderMap.containsKey(id)) {
 				id = Math.abs(random.nextLong());
			}
			
			order.setId(id);
			order.setOrderType(OrderTypeEnum.LIMIT.getType());
			order.setOrderSide(OrderSideEnum.SELL.getSide());
			order.setUserId(10);
			order.setPairName("AE_BTC");
			order.setPrice(new BigDecimal(random.nextInt()).divide(new BigDecimal(10000000000L), 8, BigDecimal.ROUND_DOWN).abs());
			order.setTotal(new BigDecimal(100));
			order.setFilledQty(BigDecimal.ZERO);
			order.setFrozen(new BigDecimal(100));
			order.setOrderState(OrderStateEnum.NEW.getState());
			order.setFilledAmount(BigDecimal.ZERO);
			order.setCreateTime(new Date());
			order.setUpdateTime(new Date());
			order.setAmount(BigDecimal.ZERO);
			
			orderMap.put(id, order);
			
			SpecialOrderBookUtil.processSellOrderBook(listEx, order);
			
			
			if(i%3 == 0) {
				int rand = random.nextInt(listEx.size());
				SpecialOrderBookUtil.removeSellOrderBook(listEx, listEx.get(rand));
				
				removeCount ++;
			}
		}
		
		System.out.println(listEx.size() == size - removeCount );
		
		//System.out.println(JSON.toJSONString(listEx.get(0)));
		//System.out.println(JSON.toJSONString(listEx.get(listEx.size()-1)));
		
		for(Order item: orderMap.values()) {						
			SpecialOrderBookUtil.removeSellOrderBook(listEx, item);			
						
		}
		
		System.out.println(listEx.size() == 0 );
	}
 	
 	
 	public static void buyOrderBookTest() {
		
		ArrayListEx<Order> listEx = new ArrayListEx<Order>();
		final int size = 2000000;
		
		Map<Long, Order> orderMap = new HashMap<Long,Order>(size);
		
		Random random = new Random();	
		
		int removeCount = 0;
		
		for(int i=0;i<size;i++) {
			
			Order order = new Order();
			
			Long id = Math.abs(random.nextLong());
 			while(orderMap.containsKey(id)) {
 				id = Math.abs(random.nextLong());
			}
			
			order.setId(id);
			order.setOrderType(OrderTypeEnum.LIMIT.getType());
			order.setOrderSide(OrderSideEnum.BUY.getSide());
			order.setUserId(10);
			order.setPairName("AE_BTC");
			order.setPrice(new BigDecimal(random.nextInt()).divide(new BigDecimal(10000000000L), 8, BigDecimal.ROUND_DOWN).abs());
			order.setTotal(new BigDecimal(100));
			order.setFilledQty(BigDecimal.ZERO);
			order.setFrozen(new BigDecimal(100));
			order.setOrderState(OrderStateEnum.NEW.getState());
			order.setFilledAmount(BigDecimal.ZERO);
			order.setCreateTime(new Date());
			order.setUpdateTime(new Date());
			order.setAmount(BigDecimal.ZERO);
			
			orderMap.put(id, order);
			
			SpecialOrderBookUtil.processBuyOrderBook(listEx, order);
			
			
			if(i%3 == 0) {
				int rand = random.nextInt(listEx.size());
				SpecialOrderBookUtil.removeBuyOrderBook(listEx, listEx.get(rand));
				
				removeCount ++;
			}
		}
		
		System.out.println(listEx.size() == size - removeCount );
		
		//System.out.println(JSON.toJSONString(listEx.get(0)));
		//System.out.println(JSON.toJSONString(listEx.get(listEx.size()-1)));
		
		for(Order item: orderMap.values()) {						
			SpecialOrderBookUtil.removeBuyOrderBook(listEx, item);			
						
		}
		
		System.out.println(listEx.size() == 0 );
	}
}
