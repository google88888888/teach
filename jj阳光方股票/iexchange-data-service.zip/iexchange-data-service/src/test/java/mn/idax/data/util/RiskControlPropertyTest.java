package mn.idax.data.util;

import com.alibaba.fastjson.JSON;

import mn.idax.data.bean.RiskControlProperty;

/**
 * @author zhouou 214108525@qq.com
 *
 * 2019年5月27日
 */
public class RiskControlPropertyTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		RiskControlProperty riskControlProperty = new RiskControlProperty();
		
		System.out.println(JSON.toJSONString(riskControlProperty));

	}

}
