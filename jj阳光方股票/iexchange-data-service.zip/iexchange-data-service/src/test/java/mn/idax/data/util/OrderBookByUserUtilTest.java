package mn.idax.data.util;

import java.math.BigDecimal;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.alibaba.fastjson.JSON;

import org.junit.Assert;
import mn.idax.common.constant.OrderSideEnum;
import mn.idax.common.constant.OrderStateEnum;
import mn.idax.common.constant.OrderTypeEnum;
import mn.idax.common.entity.Order;
import mn.idax.common.util.ArrayListEx;

/**
 * @author zhouou 214108525@qq.com
 *
 * 2019年1月1日
 */
@RunWith(SpringRunner.class)
@SpringBootTest
public class OrderBookByUserUtilTest {
	
	@Test
	public void orderBookTest() {
		
		ArrayListEx<Order> listEx = new ArrayListEx<Order>();
		final int size = 100000;
		
		Map<Long, Order> orderMap = new HashMap<Long,Order>(size);
		
		Random random = new Random();	
		
		for(int i=0;i<size;i++) {
			
			Order order = new Order();
			
			Long id = Math.abs(random.nextLong());
 			while(orderMap.containsKey(id)) {
 				id = Math.abs(random.nextLong());
			}
			
			order.setId(id);
			order.setOrderType(OrderTypeEnum.LIMIT.getType());
			order.setOrderSide(OrderSideEnum.BUY.getSide());
			order.setUserId(10);
			order.setPairName("AE_BTC");
			order.setPrice(new BigDecimal(random.nextInt()).divide(new BigDecimal(10000000000L), 8, BigDecimal.ROUND_DOWN).abs());
			order.setTotal(new BigDecimal(100));
			order.setFilledQty(BigDecimal.ZERO);
			order.setFrozen(new BigDecimal(100));
			order.setOrderState(OrderStateEnum.NEW.getState());
			order.setFilledAmount(BigDecimal.ZERO);
			order.setCreateTime(new Date());
			order.setUpdateTime(new Date());
			order.setAmount(BigDecimal.ZERO);
			
			orderMap.put(id, order);
			
			OrderBookByUserUtil.processUpdateOrderBook(listEx, order);
		}
		
		Assert.assertTrue(listEx.size() == size );
		
		System.out.println(JSON.toJSONString(listEx.get(0)));
		System.out.println(JSON.toJSONString(listEx.get(listEx.size()-1)));
		
		for(Order item: orderMap.values()) {						
			OrderBookByUserUtil.removeOrderBook(listEx, item);			
						
		}
		
		Assert.assertTrue(listEx.size() == 0 );
	}
	
}
