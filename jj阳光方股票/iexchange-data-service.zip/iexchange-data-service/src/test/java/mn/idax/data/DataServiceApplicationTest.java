package mn.idax.data;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

/**
 * @author zhouou 214108525@qq.com
 *
 * 2019年1月1日
 */
@RunWith(SpringRunner.class)
@SpringBootTest
public class DataServiceApplicationTest {


    @Test
    public void contextLoadsTest() {
    }


}
