package mn.idax.data.util;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.alibaba.fastjson.JSON;

import mn.idax.common.bean.DepthMessage;
import mn.idax.common.constant.Constants;
import mn.idax.common.constant.OrderSideEnum;
import mn.idax.common.constant.OrderStateEnum;
import mn.idax.common.constant.OrderTypeEnum;
import mn.idax.common.entity.Order;
import mn.idax.common.util.ArrayListEx;
import mn.idax.common.util.CommonUtil;

/**
 * @author zhouou 214108525@qq.com
 *
 * 2019年1月1日
 */
@RunWith(SpringRunner.class)
@SpringBootTest
public class DepthUtilTest {

	@Test
	public void buyDepthTest() {
		
		ArrayListEx<DepthMessage> listEx = new ArrayListEx<DepthMessage>();
		final int size = 100000;
		
		List<Order> orderList = new ArrayList<Order>(size);
		
		Random random = new Random();	
		BigDecimal quantityTotal1 = BigDecimal.ZERO;
		Map<BigDecimal, BigDecimal> map = new HashMap<BigDecimal, BigDecimal>(Constants.COLLECTION_DEFAULT_SIZE);
		
		for(int i=0;i<size;i++) {
			
			Order order = new Order();
			order.setId(CommonUtil.getGuid());
			order.setOrderType(OrderTypeEnum.LIMIT.getType());
			order.setOrderSide(OrderSideEnum.BUY.getSide());
			order.setUserId(10);
			order.setPairName("AE_BTC");
			
			//生成不一样的价格
			BigDecimal price = new BigDecimal(random.nextInt()).divide(new BigDecimal(10000000000L), 7, BigDecimal.ROUND_DOWN).abs();
			while(map.containsKey(price)) {
				price = new BigDecimal(random.nextInt()).divide(new BigDecimal(10000000000L), 7, BigDecimal.ROUND_DOWN).abs();
			}
			map.put(price, price);
			
			order.setPrice(price);
			order.setTotal(new BigDecimal(random.nextInt()).divide(new BigDecimal(10000000000L), 7, BigDecimal.ROUND_DOWN).abs());
			order.setFilledQty(BigDecimal.ZERO);
			order.setFrozen(new BigDecimal(100));
			order.setOrderState(OrderStateEnum.NEW.getState());
			order.setFilledAmount(BigDecimal.ZERO);
			order.setCreateTime(new Date());
			order.setUpdateTime(new Date());
			order.setAmount(BigDecimal.ZERO);
			
			orderList.add(order);
			
			quantityTotal1 = quantityTotal1.add(order.getTotal());
			
			DepthUtil.processBuyDepth(listEx, new DepthMessage("AE_BTC", OrderSideEnum.BUY.getSide(), order.getPrice(), order.getTotal()));
		}
		
		System.out.println(JSON.toJSONString(listEx.get(0)));
		System.out.println(JSON.toJSONString(listEx.get(listEx.size()-1)));
		
		//重做一遍结果不变
		for(int i=0;i<size;i++) {
			Order order = orderList.get(i);
			DepthUtil.processBuyDepth(listEx, new DepthMessage("AE_BTC", OrderSideEnum.BUY.getSide(), order.getPrice(), order.getTotal()));
		}
		
		
		System.out.println(JSON.toJSONString(listEx.get(0)));
		System.out.println(JSON.toJSONString(listEx.get(listEx.size()-1)));
		
		BigDecimal quantityTotal2 = BigDecimal.ZERO;
		for(int i=0;i<listEx.size();i++) {
			quantityTotal2 = quantityTotal2.add(listEx.get(i).getQty());
		}
		
		Assert.assertTrue(quantityTotal1.compareTo(quantityTotal2) == 0 );
		
		
		for(int i=0;i<orderList.size();i++) {
			Order item = orderList.get(i);
			
			DepthUtil.processBuyDepth(listEx, new DepthMessage("AE_BTC", OrderSideEnum.BUY.getSide(),item.getPrice(), BigDecimal.ZERO));
					
		}
		
		Assert.assertTrue(listEx.size() == 0 );
	}
	
	
	@Test
	public void sellDepthTest() {
		
		ArrayListEx<DepthMessage> listEx = new ArrayListEx<DepthMessage>();
		final int size = 100000;
		
		List<Order> orderList = new ArrayList<Order>(size);
		
		Random random = new Random();	
		
		Map<BigDecimal, BigDecimal> map = new HashMap<BigDecimal, BigDecimal>(Constants.COLLECTION_DEFAULT_SIZE);
		
		for(int i=0;i<size;i++) {
			
			Order order = new Order();
			order.setId(CommonUtil.getGuid());
			order.setOrderType(OrderTypeEnum.LIMIT.getType());
			order.setOrderSide(OrderSideEnum.SELL.getSide());
			order.setUserId(10);
			order.setPairName("AE_BTC");			
			
			//生成不一样的价格
			BigDecimal price = new BigDecimal(random.nextInt()).divide(new BigDecimal(10000000000L), 7, BigDecimal.ROUND_DOWN).abs();
			while(map.containsKey(price)) {
				price = new BigDecimal(random.nextInt()).divide(new BigDecimal(10000000000L), 7, BigDecimal.ROUND_DOWN).abs();
			}
			map.put(price, price);
			
			order.setPrice(price);
			order.setTotal(new BigDecimal(random.nextInt()).divide(new BigDecimal(10000000000L), 8, BigDecimal.ROUND_DOWN).abs());
			order.setFilledQty(BigDecimal.ZERO);
			order.setFrozen(new BigDecimal(100));
			order.setOrderState(OrderStateEnum.NEW.getState());
			order.setFilledAmount(BigDecimal.ZERO);
			order.setCreateTime(new Date());
			order.setUpdateTime(new Date());
			order.setAmount(BigDecimal.ZERO);
			
			orderList.add(order);
			
			DepthUtil.processSellDepth(listEx, new DepthMessage("AE_BTC", OrderSideEnum.SELL.getSide(), order.getPrice(), order.getTotal()));
		}
		
		
		System.out.println(JSON.toJSONString(listEx.get(0)));
		System.out.println(JSON.toJSONString(listEx.get(listEx.size()-1)));
		
		
		//重做一遍结果不变
		for(int i=0;i<size;i++) {
			Order order = orderList.get(i);
			DepthUtil.processSellDepth(listEx, new DepthMessage("AE_BTC", OrderSideEnum.BUY.getSide(), order.getPrice(), order.getTotal()));
		}
		
		
		System.out.println(JSON.toJSONString(listEx.get(0)));
		System.out.println(JSON.toJSONString(listEx.get(listEx.size()-1)));
		
		for(int i=0;i<orderList.size();i++) {
			Order item = orderList.get(i);
						
			DepthUtil.processSellDepth(listEx, new DepthMessage("AE_BTC", OrderSideEnum.SELL.getSide(),item.getPrice(), BigDecimal.ZERO));	
			
		}
		
		Assert.assertTrue(listEx.size() == 0 );
	}
	
}
