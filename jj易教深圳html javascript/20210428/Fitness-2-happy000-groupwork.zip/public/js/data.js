const data = [
    {
        'date': 1617624000000,
        'value': 3.2,
    },
    {
        'date': 1617710400000,
        'value': 4.5,
    },
    {
        'date': 1617796800000,
        'value': 0,
    },
    {
        'date': 1617883200000,
        'value': 1.2,
    },
    {
        'date': 1617969600000,
        'value': 3.4,
    },
    {
        'date': 1618056000000,
        'value': 5.4,
    },
    {
        'date': 1618142400000,
        'value': 3,
    },
]

export default data;